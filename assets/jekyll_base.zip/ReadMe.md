# Jekyll base for all

___
## To do

<p align="center">
  <img src="assets/img/UnderConstruction.png" alt="Under Construction" width="250" style="margin:auto;transform: rotate(-30deg);">
</p>

Fork this and adapt.


___
## Introduction

### The system studied

To Write.



### RPUFOS

Retro Programmers United For Obscure Systems.\
The group's goal is to expand, as much as possible, the libraries of forgotten computers.\
Especially those that, for example, no one has heard of or that have a very limited software library.\
See below the list we made.

#### Origin of the Game Jam concept

Games Jam were launched by Olipix.\
See their YouTube video channel.\

- Discord
- You Tube
- itch.io



___