Attribute VB_Name = "Module1"
Option Explicit
' VB App_Path leek
Private Declare Function GetShortPathNameA Lib "kernel32.dll" (ByVal lpszLongPath As String, ByVal lpszShortPath As String, ByVal cchBuffer As Long) As Long
Private Declare Function GetLongPathNameA Lib "kernel32" (ByVal lpszShortPath As String, ByVal lpszLongPath As String, ByVal cchBuffer As Long) As Long
Public Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (lpvDest As Any, lpvSource As Any, ByVal cbCopy As Long)

Sub Main()
Dim BBuffer() As Byte
Dim nFile2 As Integer, cnt As Long
Dim Cas_Name As String * 6
Dim Cas_Name2 As String
Dim Cas_Header As String * 10

      Dim lname As String
      lname = Cut_Path_Name(Command$)
      If Left(lname, 1) = Chr(&H22) Then lname = Right(lname, Len(lname) - 1)
    
      On Error Resume Next
      lname = ""
        If InStr(1, Command$, Chr(34)) > 0 Then
         lname = Right(Trim(Command$), Len(Trim(Command$)) - 1)
         lname = Left(lname, Len(lname) - 1)
          Else
         lname = Trim(Command$)
          End If
    On Error Resume Next
    
If InStr(lname, "\") <> 0 Then ChDir Cut_Path_Name(Cut_Path_Name(lname) & "\")
If CurDir = "C:\" Then ChDir App.Path
      'CAS files.
      If InStr(1, UCase(Right(lname, 4)), ".CAS") > 0 Then
      
nFile2 = FreeFile
Open lname For Binary Access Read As #nFile2
ReDim BBuffer(LOF(nFile2) - 1)
        Get #nFile2, 1, BBuffer
Close #nFile2

cnt = 0
If BBuffer(cnt) = &HD3 Then
    Do While BBuffer(cnt) = &HD3
    cnt = cnt + 1
    Loop
    cnt = cnt + 6
    CopyMemory BBuffer(0), BBuffer(cnt), UBound(BBuffer) - cnt + 1
    ReDim Preserve BBuffer(UBound(BBuffer) - cnt)
End If

If BBuffer(0) = 0 Then
cnt = 0
    Do While BBuffer(cnt) = 0
    cnt = cnt + 1
    If cnt > UBound(BBuffer) Then Exit Do
    Loop
    If cnt < 10 Then
     CopyMemory BBuffer(0), BBuffer(cnt), UBound(BBuffer) - cnt
    ReDim Preserve BBuffer(UBound(BBuffer) - cnt)
    End If
End If

nFile2 = FreeFile
lname = Cut_attr(Cut_Name(lname)) & ".LST"
Open lname For Binary Access Write As #nFile2
        Put #nFile2, 1, BBuffer
Close #nFile2

 
      'LST files.
           ElseIf InStr(1, UCase(Right(lname, 4)), ".LST") > 0 Then
      nFile2 = FreeFile
      
        Open lname For Binary Access Read As #nFile2
        ReDim BBuffer(LOF(nFile2) - 1)
        Get #nFile2, 1, BBuffer
        Close #nFile2
        
        cnt = 0
    Do While BBuffer(cnt) = 0
            cnt = cnt + 1
    Loop
    If cnt > 0 Then
    CopyMemory BBuffer(0), BBuffer(cnt), UBound(BBuffer) - cnt
    ReDim Preserve BBuffer(UBound(BBuffer) - cnt)
    End If
    
      Cas_Name = GetCpCName(Cut_attr(Cut_Name(lname)))
      Cas_Name2 = ""
      For cnt = 1 To 6
      If Mid(Cas_Name, cnt, 1) = " " Then Cas_Name2 = Cas_Name2 + Chr(0) Else Cas_Name2 = Cas_Name2 + Mid(Cas_Name, cnt, 1)
      Next
      Cas_Name = Cas_Name2
      Cas_Header = Chr(&HD3) + Chr(&HD3) + Chr(&HD3) + Chr(&HD3) + Chr(&HD3) + Chr(&HD3) + Chr(&HD3) + Chr(&HD3) + Chr(&HD3) + Chr(&HD3)
     
      lname = Cut_attr(Cut_Name(lname)) & ".CAS"
      nFile2 = FreeFile
        Open lname For Binary Access Write As #nFile2
        Put nFile2, 1, Cas_Header
        Put nFile2, , Cas_Name
        Put nFile2, , BBuffer
        Close #nFile2
 End If
End Sub
' Get the path of a specified file name.( "c:\vb\tmp\file.txt" -> "c:\vb\tmp" )
Public Function Cut_Path_Name(Long_name_file As String) As String
On Error GoTo endfnc
Dim LastSlash, scan_path As Integer
Dim char_path As String * 1
If Long_name_file = "" Then Cut_Path_Name = "": Exit Function
    scan_path = Len(Long_name_file)
    
Do While scan_path <> 1
    char_path = Mid(Long_name_file, scan_path, 1)
    If InStr(char_path, "\") <> 0 Then LastSlash = scan_path: Exit Do
    scan_path = scan_path - 1
Loop
If LastSlash <= 1 Then GoTo endfnc
Cut_Path_Name = Left(Long_name_file, LastSlash - 1)
Exit Function
endfnc:
Cut_Path_Name = Long_name_file
End Function

' Retrive name in a long file name string ( "c:\vb\tmp\file.txt" -> "file.txt" )
Public Function Cut_Name(Ln_file As String) As String
Dim LastSlash, scan_path As Integer
Dim char_path As String * 1
Dim lng_file As String

If Trim(GetLongPathName(Ln_file)) <> "" Then
lng_file = GetLongPathName(Ln_file)
End If


'If Ln_file = "" Then Cut_Name = "": Exit Function
If InStr(Ln_file, "\") = 0 Then Cut_Name = Ln_file: Exit Function
   
    scan_path = Len(Ln_file)
    Do While InStr(1, Mid(Ln_file, scan_path, 1), "\", vbBinaryCompare) = 0
     scan_path = scan_path - 1
    Loop
 LastSlash = scan_path
Cut_Name = Trim(Right(Ln_file, Len(Ln_file) - LastSlash))

End Function
Public Function GetLongPathName(Shortpath As String) As String
   Dim s As String
   Dim i As Long
   Dim ret As Long
   
   i = 1024
   s = String(i, 0)
   ret = GetLongPathNameA(Shortpath, s, i)
   
   GetLongPathName = Left$(s, InStr(s, Chr$(0)) - 1)
End Function
Function GetCpCName(PCName As String) As String

'
' Convert ANSI CHAR CODES.
'

Dim TmpName As String
Dim cnt As Integer
Dim Ch As String * 1
TmpName = ""
If PCName = "" Then Exit Function
For cnt = 1 To Len(PCName)
Ch = Mid(PCName, cnt, 1)
Select Case Asc(Ch)
Case Is < &H20
TmpName = TmpName + "-"

Case &H7F To &HBF, &H5B To &H60
TmpName = TmpName + "-"

Case &HC0 To &HC6, &HE9 To &HE6
TmpName = TmpName + "A"

Case &HC7, &HE7
TmpName = TmpName + "C"

Case &HC8 To &HCB, &HE8 To &HEB
TmpName = TmpName + "E"

Case &HCC To &HCF, &HEC To &HEF
TmpName = TmpName + "I"

Case &HD0
TmpName = TmpName + "D"

Case &HD1
TmpName = TmpName + "N"

Case &HD2 To &HD6, &HF0, &HF2 To &HF6
TmpName = TmpName + "O"

Case &HD9 To &HDC, &HF9 To &HFC
TmpName = TmpName + "U"


Case &HDD, &HFD, &HFF
TmpName = TmpName + "Y"

Case Else
TmpName = TmpName + UCase(Ch)
End Select
Next
GetCpCName = TmpName
End Function

' Internal function cut attributes "disk.TXT" = "disk"
Public Function Cut_attr(char As String) As String
Dim cmp
For cmp = Len(char) To 1 Step -1
If Mid(char, cmp, 1) = "." Then Cut_attr = Mid(char, 1, cmp - 1): Exit For
If Mid(char, cmp, 1) = "\" Then Cut_attr = char: Exit For
Next cmp
End Function


