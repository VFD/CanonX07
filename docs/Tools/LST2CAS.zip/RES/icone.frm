VERSION 5.00
Begin VB.Form icone 
   BorderStyle     =   0  'None
   Caption         =   "icone"
   ClientHeight    =   0
   ClientLeft      =   9975
   ClientTop       =   2430
   ClientWidth     =   1725
   Enabled         =   0   'False
   Icon            =   "icone.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   0
   ScaleWidth      =   1725
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Visible         =   0   'False
   WindowState     =   1  'Minimized
End
Attribute VB_Name = "icone"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

