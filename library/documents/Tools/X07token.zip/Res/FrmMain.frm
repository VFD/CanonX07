VERSION 5.00
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "X-07 Token r1.6  by XavSnap. (Canon X-07 Basic)"
   ClientHeight    =   5685
   ClientLeft      =   2205
   ClientTop       =   2715
   ClientWidth     =   10815
   Icon            =   "FrmMain.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   5685
   ScaleWidth      =   10815
   StartUpPosition =   1  'CenterOwner
   Begin VB.PictureBox Picture4 
      BackColor       =   &H00000000&
      Height          =   1125
      Left            =   3390
      ScaleHeight     =   1065
      ScaleWidth      =   2400
      TabIndex        =   31
      Top             =   0
      Width           =   2460
      Begin VB.Line Line3 
         BorderColor     =   &H00808080&
         BorderWidth     =   2
         X1              =   165
         X2              =   2195
         Y1              =   480
         Y2              =   480
      End
      Begin VB.Line Line2 
         BorderColor     =   &H00C0C0C0&
         X1              =   180
         X2              =   2225
         Y1              =   495
         Y2              =   495
      End
      Begin VB.Label VER 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "-"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   810
         Left            =   0
         TabIndex        =   32
         Top             =   195
         Width           =   2415
      End
   End
   Begin VB.PictureBox BINfrm 
      Height          =   1350
      Left            =   30
      ScaleHeight     =   1290
      ScaleWidth      =   10740
      TabIndex        =   24
      Top             =   7350
      Width           =   10800
      Begin VB.TextBox BINname 
         Height          =   285
         Left            =   450
         TabIndex        =   28
         Top             =   855
         Width           =   10290
      End
      Begin VB.PictureBox Picture6 
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   90
         Picture         =   "FrmMain.frx":0342
         ScaleHeight     =   255
         ScaleWidth      =   255
         TabIndex        =   27
         Top             =   855
         Width           =   255
      End
      Begin VB.TextBox BTname 
         Height          =   285
         Left            =   435
         TabIndex        =   26
         Top             =   270
         Width           =   10305
      End
      Begin VB.PictureBox Picture5 
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   75
         Picture         =   "FrmMain.frx":08CC
         ScaleHeight     =   255
         ScaleWidth      =   255
         TabIndex        =   25
         Top             =   270
         Width           =   255
      End
      Begin VB.Label Label3 
         Caption         =   "Output Filename: (Converted file:  Binary file.) "
         Height          =   225
         Index           =   4
         Left            =   105
         TabIndex        =   30
         Top             =   570
         Width           =   4440
      End
      Begin VB.Label Label3 
         Caption         =   "Output Filename: (Converted file: Basic Text file=TXT) "
         Height          =   225
         Index           =   3
         Left            =   150
         TabIndex        =   29
         Top             =   30
         Width           =   4440
      End
   End
   Begin VB.ComboBox Computer 
      Height          =   315
      Left            =   11115
      TabIndex        =   16
      Text            =   "Combo1"
      Top             =   645
      Width           =   1965
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Command3"
      Height          =   300
      Left            =   90
      TabIndex        =   15
      Top             =   7545
      Visible         =   0   'False
      Width           =   1005
   End
   Begin VB.CommandButton EXIT 
      Caption         =   "EXIT"
      Height          =   345
      Left            =   9150
      TabIndex        =   14
      Top             =   5325
      Width           =   1620
   End
   Begin VB.CommandButton Command2 
      Caption         =   "ASCII tables."
      Height          =   285
      Left            =   1275
      TabIndex        =   13
      Top             =   7560
      Visible         =   0   'False
      Width           =   1365
   End
   Begin VB.PictureBox Picture3 
      Height          =   1095
      Left            =   15
      ScaleHeight     =   1035
      ScaleWidth      =   3345
      TabIndex        =   10
      Top             =   15
      Width           =   3405
      Begin VB.Line Line4 
         BorderColor     =   &H000000FF&
         Index           =   2
         X1              =   165
         X2              =   3120
         Y1              =   540
         Y2              =   540
      End
      Begin VB.Label LbOption 
         Alignment       =   2  'Center
         BackColor       =   &H00FF0000&
         Caption         =   "BIN"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000FFFF&
         Height          =   345
         Index           =   2
         Left            =   0
         TabIndex        =   23
         Top             =   300
         Width           =   3315
      End
      Begin VB.Line Line4 
         BorderColor     =   &H000000FF&
         Index           =   1
         X1              =   375
         X2              =   3000
         Y1              =   915
         Y2              =   915
      End
      Begin VB.Line Line4 
         BorderColor     =   &H000000FF&
         Index           =   0
         X1              =   915
         X2              =   2325
         Y1              =   210
         Y2              =   210
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00FFFFFF&
         Index           =   1
         X1              =   45
         X2              =   2895
         Y1              =   645
         Y2              =   645
      End
      Begin VB.Line Line1 
         Index           =   0
         X1              =   45
         X2              =   3210
         Y1              =   660
         Y2              =   660
      End
      Begin VB.Label LbOption 
         Alignment       =   2  'Center
         BackColor       =   &H00FF0000&
         Caption         =   "TAP"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000FFFF&
         Height          =   300
         Index           =   0
         Left            =   15
         TabIndex        =   12
         Top             =   -15
         Width           =   3315
      End
      Begin VB.Label LbOption 
         Alignment       =   2  'Center
         BackColor       =   &H00C00000&
         Caption         =   "TXT"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000C0C0&
         Height          =   375
         Index           =   1
         Left            =   15
         TabIndex        =   11
         Top             =   690
         Width           =   3315
      End
   End
   Begin VB.PictureBox BASfrm 
      Height          =   1350
      Left            =   0
      ScaleHeight     =   1290
      ScaleWidth      =   10740
      TabIndex        =   6
      Top             =   5970
      Width           =   10800
      Begin VB.PictureBox FromTAP 
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   75
         Picture         =   "FrmMain.frx":0E56
         ScaleHeight     =   255
         ScaleWidth      =   255
         TabIndex        =   21
         Top             =   270
         Width           =   255
      End
      Begin VB.TextBox TapName 
         Height          =   285
         Left            =   435
         TabIndex        =   20
         Top             =   270
         Width           =   10305
      End
      Begin VB.PictureBox toTXT 
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   90
         Picture         =   "FrmMain.frx":13E0
         ScaleHeight     =   255
         ScaleWidth      =   255
         TabIndex        =   8
         Top             =   855
         Width           =   255
      End
      Begin VB.TextBox TZXName 
         Height          =   285
         Left            =   450
         TabIndex        =   7
         Top             =   855
         Width           =   10290
      End
      Begin VB.Label Label3 
         Caption         =   "Output Filename: (Converted file: Virtual tape file=Cas) "
         Height          =   225
         Index           =   1
         Left            =   105
         TabIndex        =   22
         Top             =   30
         Width           =   4440
      End
      Begin VB.Label Label3 
         Caption         =   "Output Filename: (Converted file:  X-07 Basic file=TXT) "
         Height          =   225
         Index           =   2
         Left            =   105
         TabIndex        =   9
         Top             =   570
         Width           =   4440
      End
   End
   Begin VB.PictureBox SNAfrm 
      Height          =   1350
      Left            =   15
      ScaleHeight     =   1290
      ScaleWidth      =   10740
      TabIndex        =   2
      Top             =   1155
      Width           =   10800
      Begin VB.TextBox InputTXT 
         Height          =   285
         Left            =   435
         TabIndex        =   18
         Top             =   270
         Width           =   10305
      End
      Begin VB.PictureBox Picture1 
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   75
         Picture         =   "FrmMain.frx":196A
         ScaleHeight     =   255
         ScaleWidth      =   255
         TabIndex        =   17
         Top             =   270
         Width           =   255
      End
      Begin VB.TextBox OutputTXT 
         Height          =   285
         Left            =   450
         TabIndex        =   4
         Top             =   855
         Width           =   10290
      End
      Begin VB.PictureBox Picture2 
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   255
         Index           =   0
         Left            =   90
         Picture         =   "FrmMain.frx":1EF4
         ScaleHeight     =   255
         ScaleWidth      =   255
         TabIndex        =   3
         Top             =   855
         Width           =   255
      End
      Begin VB.Label Label2 
         Caption         =   "Input Filename: (Text file using X07 Basic characters codes)"
         Height          =   225
         Left            =   135
         TabIndex        =   19
         Top             =   30
         Width           =   4740
      End
      Begin VB.Label Label3 
         Caption         =   "Output Filename: (Converted file: Virtual tape file=Cas) "
         Height          =   225
         Index           =   0
         Left            =   105
         TabIndex        =   5
         Top             =   570
         Width           =   4440
      End
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Compil input text."
      Height          =   345
      Left            =   45
      TabIndex        =   1
      Top             =   5310
      Width           =   1800
   End
   Begin VB.TextBox Status 
      Height          =   2670
      Left            =   15
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   0
      Top             =   2535
      Width           =   10785
   End
   Begin VB.Image Image1 
      Height          =   1125
      Left            =   5595
      Picture         =   "FrmMain.frx":247E
      Top             =   0
      Width           =   5250
   End
   Begin VB.Shape Shape1 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      Height          =   1155
      Left            =   3465
      Top             =   -30
      Width           =   7290
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()

If SNAfrm.Visible Then
If Dir(InputTXT) = "" Then GoTo ERRhand

frmMain.MousePointer = 11
Open_TextFile InputTXT
frmMain.MousePointer = 0
End If

If BASfrm.Visible Then
If TZXName = "" Then GoTo ERRhand
If Dir(TapName) = "" Then GoTo ERRhand
frmMain.MousePointer = 11
Save_textfile TapName, TZXName
frmMain.MousePointer = 0
End If

If BINfrm.Visible Then
If Dir(BTname) = "" Then GoTo ERRhand

frmMain.MousePointer = 11
Open_TextFile BTname
frmMain.MousePointer = 0
End If
Exit Sub

ERRhand:
Status = "Names error !!!"
End Sub


Sub Open_TextFile(InputTXT As String)
Dim CurLine As String
Dim Cnt As Long
Dim dep
Dim CrDIR As String, LastPath As String

' *************************************
' **       TXT TO memory buffer      **
' *************************************

If Dir(InputTXT) = "" Or InputTXT = "" Then Exit Sub
If OutputTXT = "" And Not bBas Then Exit Sub

Dim GetFL As String, TapName  As String
Dim TAP_Header As TAP_Header
Dim TMPbuffer() As Byte
Dim Last As Long, K7addr As Long
Dim AddrMemOf As Long
Dim Cnt1, Cnt2

' INIT VARS
frmMain.Status = ""
lineCtr = 0
ErrIndex = 0
InputLine = 0
FrtLine = -1
InputLine = 0
ZxOffset = 0 ' Reset ZxBuffer Start AT 0
bREM = False
bSave = False
tLng = 1
CurLine = ""
ASM_cnt = 0

Disp_Err 0

DoEvents

'On Error GoTo error_Rpt

'Open File
hFile = FreeFile
Open InputTXT For Input As #hFile

ReDim ZXbuffer(0)


Last = 0
TAPcmp = &H554

ZxOffset = UBound(ZXbuffer) + 2
ReDim Preserve ZXbuffer(ZxOffset + 1)
AddrMemOf = 0
GoTo FreScan

ReScan:

AddrMemOf = ZxOffset - 2

FreScan:
If EOF(hFile) Then GoTo EndScan
Line Input #hFile, GetFL
InputLine = InputLine + 1
If GetFL = "" Or Left(Trim(GetFL), 2) = "##" Then GoTo ReScan
CurLine = CurLine + GetFL

If Right(Trim(CurLine), 1) = "\" Then
    For Cnt1 = Len(CurLine) To 1 Step -1
    If Mid$(CurLine, Cnt1, 1) = "\" Then CurLine = Left(CurLine, Cnt1 - 1): GoTo ReScan
    Next Cnt1
End If

Call DecodeLine(CurLine)

TAPcmp = TAPcmp + 1
ZXbuffer(AddrMemOf) = CByte(TAPcmp And 255)
ZXbuffer(AddrMemOf + 1) = CByte(TAPcmp \ 256)
TAPcmp = TAPcmp + 1

bASM = False
bREM = False
bSave = False
CurLine = ""

GoTo ReScan
EndScan:

ZXbuffer(ZxOffset - 1) = 0
ZXbuffer(ZxOffset - 2) = 0

'Last = (ZxOffset - Last) + &H502

Close #hFile

If ZxOffset > 20221 Then Disp_Err 10, Str(ZxOffset)

' Test Commands argument.
Dim PRGoffset As Long, PRGline As Long, PRGlSize As Long
PRGoffset = 0

Do
PRGline = Get16num(PRGoffset)
PRGoffset = PRGoffset + 2
PRGlSize = Get16numLi(PRGoffset)
PRGoffset = PRGoffset + 2


If PRGoffset < ZxOffset Then
        If ZXbuffer(PRGoffset) <> 234 And PRGoffset < ZxOffset Then

        For PRGoffset = PRGoffset To (PRGoffset + PRGlSize - 1)
        If PRGoffset <= UBound(ZXbuffer) Then
        If ZXbuffer(PRGoffset) = 222 Then
        End If
        End If
        Next

        Else
        PRGoffset = PRGoffset + PRGlSize
        End If
End If
Loop While PRGoffset < ZxOffset



' Lines errors
' equal.


For Cnt1 = 1 To lineCtr
    For Cnt2 = 1 To lineCtr
    If (Lines(Cnt1) = Lines(Cnt2)) And Cnt1 <> Cnt2 Then InputLine = Cnt1: Disp_Err 9, Str(Lines(Cnt1))
    Next Cnt2
Next Cnt1

' < than previous line.
For Cnt1 = 2 To lineCtr
       If Lines(Cnt1 - 1) > Lines(Cnt1) Then InputLine = Cnt1: Disp_Err 7, Str(Lines(Cnt1 - 1)) & "<<" & Str(Lines(Cnt1))
Next Cnt1

' Line Out of rang.
For Cnt1 = 1 To lineCtr
    If Lines(Cnt1) > 65535 Then InputLine = Cnt1: Disp_Err 8, Str(Lines(Cnt1))
Next Cnt1

'Add the cas footer
ZxOffset = ZxOffset + 9
ReDim Preserve ZXbuffer(ZxOffset)
'ZXbuffer(ZxOffset) = &HFD
'ZXbuffer(ZxOffset - 5) = 5


Dim tmp_buffer() As Byte
Dim TmpHeader(66) As Byte


' Basic Files header &  Binary Files header.
Dim Var_Off As Long



' ------  K  7    FILE -----


On Error GoTo RD_err
If Dir(OutputTXT) <> "" Then
Kill OutputTXT
End If


Dim lentag As Byte
Dim X07Header As String * 10
Dim X07HeaderLM As String * 10
Dim X07Name As String * 6

Dim b0 As Uint
Dim b1 As Byte, b2 As Byte
Dim TmpHeader2() As Byte
Dim CrLFtag As String * 2
CrLFtag = vbCrLf
Dim LmName As String
LmName = Cut_attr(OutputTXT)

If Not bBin Then
X07Header = Chr(&HD3) & Chr(&HD3) & Chr(&HD3) & Chr(&HD3) & Chr(&HD3) & Chr(&HD3) & Chr(&HD3) & Chr(&HD3) & Chr(&HD3) & Chr(&HD3)
X07HeaderLM = Chr(&H9C) & Chr(&H9C) & Chr(&H9C) & Chr(&H9C) & Chr(&H9C) & Chr(&H9C) & Chr(&H9C) & Chr(&H9C) & Chr(&H9C) & Chr(&H9C)

X07Name = Trim(Getx07rName(Cut_attr(Cut_Name(OutputTXT)))) & Chr(0) & Chr(0) & Chr(0) & Chr(0) & Chr(0) & Chr(0)

hFile = FreeFile
Open OutputTXT For Binary As #hFile

Put #hFile, 1, X07Header
Put #hFile, , X07Name
Put #hFile, , ZXbuffer

Close #hFile

' Put ASM in Swap file.
If ASM_cnt > 0 Then

    For Cnt = 0 To ASM_cnt - 1
    ReDim tmp_buffer(ASM_lng(Cnt) - 1)
    CopyMemory tmp_buffer(0), ASM_Buff(Asm_OFF(Cnt)), ASM_lng(Cnt)
    
   
If ASM_Name(Cnt) = "" Then
   X07Name = "LM" + Trim(Str$(Cnt)) + "      "
   Else
   X07Name = ASM_Name(Cnt)
End If
          Status = Status & vbCrLf & "ASM file '" & LmName & "[" & Trim(X07Name) & "].CAS'" & vbCrLf & "  at &h" & Hex16(ASM_Add(Cnt)) & "/" & ASM_Add(Cnt) & " (" & Trim(ASM_lng(Cnt)) & " Bytes)" & vbCrLf


hFile = FreeFile

   Open LmName & "[" & Trim(X07Name) & "].CAS" For Binary As #hFile
    Put #hFile, 1, X07HeaderLM
If ASM_Name(Cnt) = "" Then
    Put #hFile, , X07Name
    Put #hFile, , CrLFtag
    Else
    Put #hFile, , ASM_Name(Cnt)
    Put #hFile, , CrLFtag
End If
    Put #hFile, , tmp_buffer
   Close #hFile
   ASM_lng(Cnt) = 0
    Next
End If


Else

hFile = FreeFile
Open App.path & "\datas\Header.bin" For Binary As #hFile
ReDim TmpHeader2(LOF(hFile) - 1)
Get #hFile, 1, TmpHeader2
Close #hFile

b0 = Cuint(UBound(ZXbuffer) + 1363 - 9)

hFile = FreeFile
Open BINname For Binary As #hFile

Put #hFile, 1, TmpHeader2
Put #hFile, , ZXbuffer
Put #hFile, 803, b0
Put #hFile, , b0
Put #hFile, , b0
Close #hFile

End If

GoTo RD_OK
RD_err:
Status = Status & vbCrLf & "K7 file in use in an emulator ! (file locked!)" & vbCrLf
Err.Clear
GoTo error_Rpt
RD_OK:
If bBin Then
Status = Status & vbCrLf & "Integrated in " & "'" & BINname & "'" & vbCrLf
Else
Status = Status & vbCrLf & "Integrated in " & "'" & OutputTXT & "'" & vbCrLf
End If
Disp_Err 20, Format$(ZxOffset, "#####") & " Bytes"



Reset
Err.Clear
Exit Sub

error_Rpt:
Debug.Print Err.Description
Disp_Err 21
Reset
Err.Clear
Status = Status & vbCrLf & "Process aborted." & vbCrLf
End Sub
Function Get16num(PRGoffset As Long) As Long
'Line Number.
Get16num = CLng(ZXbuffer(PRGoffset)) * 256 + CLng(ZXbuffer(PRGoffset + 1))
End Function
Function Get16numLi(PRGoffset As Long) As Long
'Line lenght.
Get16numLi = CLng(ZXbuffer(PRGoffset)) * 256 + CLng(ZXbuffer(PRGoffset + 1))
End Function

Function GetVArAttr(VarStr As String) As String
GetVArAttr = Chr(&H20) + Chr(&HD) + Chr(&H0) + Chr(&H0)
GetVArAttr = GetVArAttr + VarStr
GetVArAttr = Left(GetVArAttr, Len(GetVArAttr) - 1)
GetVArAttr = GetVArAttr + Chr(Asc(Right(VarStr, 1)) + 128)
End Function

Private Sub Command2_Click()

If Dir(App.path & "\datas\asciipc.bmp") = "" Or Dir(App.path & "\datas\asciicpc.bmp") = "" Then
MsgBox "'asciipc.bmp' or 'asciicpc.bmp' not found in the 'DATAS' directory!", vbCritical, "File error:"
Else
'ASCII.Show
End If

End Sub



Private Sub EXIT_Click()
On Error Resume Next
'Unload ASCII
Unload frmMain
End Sub

Private Sub Form_Load()
LbOption_Click (0)

VER.Caption = "X07Token text converter." & vbCrLf & vbCrLf & "Release " & PVersion & "."
LbOption(0).Caption = "Create a 'CAS/LST' File."
SNAfrm.Move 15, 1155
SNAfrm.Visible = True
bBas = False

LbOption(1).Caption = "Create a 'TXT' file From a CAS/LST file."
BASfrm.Move 15, 1155
BASfrm.Visible = False

LbOption(2).Caption = "Create a'BIN'to patch 'PokEmul' @0000."
BINfrm.Move 15, 1155
BINfrm.Visible = False
End Sub

Private Sub FromTAP_Click()

Dim ODialog As New clsCDEx

Load Dialog_Frame
   With ODialog
   

         .Filename = TapName
         .DialogTitle = "Load a 'cas/lst' X-07 Virtual tape file as ..."
         .Filter = "cas or lst files (*.cas;*.lst)|*.cas;*.lst|Binary BAS files (*.bas)|*.BAS|All files (*.*)|*.*"
        
     .CancelError = True
     .SelDir = App.path & "\result"
     .InitDir = App.path & "\result"
     .hOwner = Dialog_Frame.hwnd

     .ShowOpen
 End With
Unload Dialog_Frame



  If ODialog.Filename = "" Then Set ODialog = Nothing: Exit Sub

TapName = ODialog.Filename
TZXName = App.path & "\text\" & Trim(Cut_Name(Cut_attr(ODialog.Filename)) & ".TXT")
Set ODialog = Nothing

Status.text = ""
End Sub

Private Sub LbOption_Click(Index As Integer)
bBin = False
Select Case Index
Case 0
BASfrm.Visible = False
SNAfrm.Visible = True
BINfrm.Visible = False
bBas = False
LbOption(0).ForeColor = &HFFFFFF
LbOption(0).BackColor = &H0
LbOption(1).ForeColor = &HB0B0B0
LbOption(1).BackColor = &H202020
LbOption(2).ForeColor = &HB0B0B0
LbOption(2).BackColor = &H202020
Line4(0).BorderColor = &HFF&
Line4(1).BorderColor = &HB0B0B0
Line4(2).BorderColor = &HB0B0B0
Case 1
BASfrm.Visible = True
SNAfrm.Visible = False
BINfrm.Visible = False
LbOption(2).ForeColor = &HB0B0B0
LbOption(2).BackColor = &H202020
LbOption(1).ForeColor = &HFFFFFF
LbOption(1).BackColor = &H0
LbOption(0).ForeColor = &HB0B0B0
LbOption(0).BackColor = &H202020
Line4(0).BorderColor = &HB0B0B0
Line4(1).BorderColor = &HFF&
Line4(2).BorderColor = &HB0B0B0
Case 2
BASfrm.Visible = False
SNAfrm.Visible = False
BINfrm.Visible = True

LbOption(2).ForeColor = &HFFFFFF
LbOption(2).BackColor = &H0
LbOption(1).ForeColor = &HB0B0B0
LbOption(1).BackColor = &H202020
LbOption(0).ForeColor = &HB0B0B0
LbOption(0).BackColor = &H202020

Line4(0).BorderColor = &HB0B0B0
Line4(1).BorderColor = &HB0B0B0
Line4(2).BorderColor = &HFF&
bBin = True
End Select
Status.text = ""
End Sub

Private Sub Picture1_Click()

Dim ODialog As New clsCDEx

 Load Dialog_Frame
   With ODialog
     .CancelError = True
     .DialogTitle = "Load a Text file..."
     .Filename = ""
     .InitDir = App.path & "\text"
     .hOwner = Dialog_Frame.hwnd
     .Filter = "Text files (*.TXT;*.BAS)|*.txt;*.bas|Text files (*.TXT)|*.txt|Basic files (*.BAS)|*.bas|All files (*.*)|*.*"
     .SelDir = App.path & "\text"
     .ShowOpen
 End With
Unload Dialog_Frame



  If ODialog.Filename = "" Then Set ODialog = Nothing: Exit Sub
InputTXT = ODialog.Filename
BTname = ODialog.Filename
OutputTXT = App.path & "\result\" & Trim(Cut_Name(Cut_attr(ODialog.Filename))) & ".CAS"
BINname = App.path & "\result\" & Trim(Cut_Name(Cut_attr(ODialog.Filename))) & ".BIN"
frmMain.Status = ""
Set ODialog = Nothing
End Sub

Private Sub Picture2_Click(Index As Integer)

Dim ODialog As New clsCDEx

Load Dialog_Frame
   With ODialog
   
   Select Case Index
    Case 0
         .Filename = OutputTXT
         .DialogTitle = "Save a 'CAS/LST' X-07 Virtual tape file as ..."
         .Filter = "CAS files (*.cas;*.lst)|*.cas;*.lst|Binary BAS files (*.bas)|*.BAS|All files (*.*)|*.*"

    End Select
        
     .CancelError = True
     .SelDir = App.path & "\result"
     .InitDir = App.path & "\result"
     .hOwner = Dialog_Frame.hwnd

     .ShowSave
 End With
Unload Dialog_Frame



  If ODialog.Filename = "" Then Set ODialog = Nothing: Exit Sub

OutputTXT = ODialog.Filename

Set ODialog = Nothing
End Sub
Private Function Cuint(Val As Long) As Uint
Cuint.bHig = (Val And &HFF00) \ &H100
Cuint.bLow = Val And &HFF
End Function

Private Function Cuint3(Val As Long) As Uint3
Cuint3.bHig = (Val And &HFF0000) \ &H10000
Cuint3.bMed = (Val And &HFF00) \ &H100
Cuint3.bLow = Val And &HFF
End Function

Private Function CRC16(Datas() As Byte, Ret As Uint)
Dim TmpCRC16 As Long, Cnt As Long
TmpCRC16 = 0
Ret.bHig = 0
Ret.bLow = 0
For Cnt = 0 To UBound(Datas)
TmpCRC16 = TmpCRC16 + Datas(Cnt)
Next

Ret.bHig = (TmpCRC16 And &HFF00) \ &H100
Ret.bLow = TmpCRC16 And &HFF

End Function

Function GetCpCName(PCName As String) As String

'
' Convert ANSI CHAR CODES.
'

Dim TmpName As String
Dim Cnt As Integer
Dim Ch As String * 1
TmpName = ""
If PCName = "" Then Exit Function
For Cnt = 1 To Len(PCName)
Ch = Mid(PCName, Cnt, 1)
Select Case Asc(Ch)
Case Is < &H20
TmpName = TmpName + "-"

Case &H7F To &HBF, &H5B To &H60
TmpName = TmpName + "-"

Case &HC0 To &HC6, &HE9 To &HE6
TmpName = TmpName + "A"

Case &HC7, &HE7
TmpName = TmpName + "C"

Case &HC8 To &HCB, &HE8 To &HEB
TmpName = TmpName + "E"

Case &HCC To &HCF, &HEC To &HEF
TmpName = TmpName + "I"

Case &HD0
TmpName = TmpName + "D"

Case &HD1
TmpName = TmpName + "N"

Case &HD2 To &HD6, &HF0, &HF2 To &HF6
TmpName = TmpName + "O"

Case &HD9 To &HDC, &HF9 To &HFC
TmpName = TmpName + "U"


Case &HDD, &HFD, &HFF
TmpName = TmpName + "Y"

Case Else
TmpName = TmpName + UCase(Ch)
End Select
Next
GetCpCName = TmpName
End Function

Private Sub Picture5_Click()
Dim ODialog As New clsCDEx

 Load Dialog_Frame
   With ODialog
     .CancelError = True
     .DialogTitle = "Load a Text file..."
     .Filename = ""
     .InitDir = App.path & "\text"
     .hOwner = Dialog_Frame.hwnd
     .Filter = "Text files (*.TXT;*.BAS)|*.txt;*.bas|Text files (*.TXT)|*.txt|Basic files (*.BAS)|*.bas|All files (*.*)|*.*"
     .SelDir = App.path & "\text"
     .ShowOpen
 End With
Unload Dialog_Frame



  If ODialog.Filename = "" Then Set ODialog = Nothing: Exit Sub
InputTXT = ODialog.Filename
BTname = ODialog.Filename
OutputTXT = App.path & "\result\" & Trim(Cut_Name(Cut_attr(ODialog.Filename))) & ".CAS"
BINname = App.path & "\result\" & Trim(Cut_Name(Cut_attr(ODialog.Filename))) & ".BIN"
frmMain.Status = ""
Set ODialog = Nothing
End Sub

Private Sub toTXT_Click()
Dim ODialog As New clsCDEx

 Load Dialog_Frame
   With ODialog
     .CancelError = True
     .DialogTitle = "Load a Text file..."
     .Filename = TZXName
     .InitDir = App.path & "\text"
     .hOwner = Dialog_Frame.hwnd
     .Filter = "Text files (*.TXT;*.BAS)|*.txt;*.bas|Text files (*.TXT)|*.txt|Basic files (*.BAS)|*.bas|All files (*.*)|*.*"
     .SelDir = App.path & "\text"
     .ShowOpen
 End With
Unload Dialog_Frame



  If ODialog.Filename = "" Then Set ODialog = Nothing: Exit Sub
TZXName = ODialog.Filename

frmMain.Status = ""
Set ODialog = Nothing
End Sub

