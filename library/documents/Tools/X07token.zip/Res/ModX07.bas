Attribute VB_Name = "ModX07"
Option Explicit

Type TAP_Header
FHeader(3) As Byte
FTAG1 As Uint ' hFFFF /h0000
FTAG2 As Uint ' h0000
FEndAddr As Uint ' Last memory used.
FSarAddr As Uint ' Start Address (&h501)
FTAG5 As Byte ' hFF/h00
End Type
' NAME + CHR(0) +?CRC?

Type Line_Header
TAG1 As Byte ' h05
LTAg As Uint ' Line index.
End Type

Type Line_Footer
TAG1 As Byte ' h00
LCRC As Byte ' Line index.
End Type

Type K7_Header
Htag As Byte ' h05
A1 As Uint 'h20FF / h2870
nc1 As Byte ' h00
A2 As Uint 'h20FF / h28FF
nc2 As Byte ' h01/h10
nc3 As Byte ' h70/70
End Type

Type Line_tag
Ladd As Uint ' h7010 + line lenght(n)
Lnum As Uint ' hxxxx
End Type

Function Getx07rName(PCName As String) As String

'
' Convert ANSI CHAR CODES.
'

Dim TmpName As String
Dim X07Name As String * 6
Dim Cnt As Integer
Dim Ch As String * 1
TmpName = ""
If PCName = "" Then Exit Function
For Cnt = 1 To Len(PCName)
Ch = Mid(PCName, Cnt, 1)
Select Case Asc(Ch)
Case Is < &H20
Exit For
Case &H7F To &HBF, &H5B To &H60
Exit For
Case &HC0 To &HC6, &HE9 To &HE6
TmpName = TmpName + "A"

Case &HC7, &HE7
TmpName = TmpName + "C"

Case &HC8 To &HCB, &HE8 To &HEB
TmpName = TmpName + "E"

Case &HCC To &HCF, &HEC To &HEF
TmpName = TmpName + "I"

Case &HD0
TmpName = TmpName + "D"

Case &HD1
TmpName = TmpName + "N"

Case &HD2 To &HD6, &HF0, &HF2 To &HF6
TmpName = TmpName + "O"

Case &HD9 To &HDC, &HF9 To &HFC
TmpName = TmpName + "U"


Case &HDD, &HFD, &HFF
TmpName = TmpName + "Y"

Case Else
TmpName = TmpName + UCase(Ch)
End Select
Next
If InStr(1, TmpName, "[") > 1 Then TmpName = Left(TmpName, InStr(1, TmpName, "[") - 1)
If InStr(1, TmpName, "_") > 1 Then TmpName = Left(TmpName, InStr(1, TmpName, "_") - 1)
If InStr(1, TmpName, "-") > 1 Then TmpName = Left(TmpName, InStr(1, TmpName, "-") - 1)
X07Name = Trim(TmpName)
Getx07rName = X07Name
End Function


