Attribute VB_Name = "Modtoken"

'**********************************************
'           X O 7    T O K E N
'**********************************************
'
'  *    *  ***  *****
'   *  *  *   *    *
'    **   *   *   *
'   *  *  *   *  *
'  *    *  ***  *    Tools -= XavSnap =-
'
'http://dskcenter.free.fr/X07
'**********************************************

Public Const PVersion = "07/03/2013"

' Originals codes.


Option Explicit ' Declare all variables. (to avoid redundant public/private declaration)

Public Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (lpvDest As Any, lpvSource As Any, ByVal cbCopy As Long)
Public Declare Sub CopyMemoryStr Lib "kernel32" Alias "RtlMoveMemory" (lpvDest As Any, ByVal lpvSource As String, ByVal cbCopy As Long)
Public Declare Sub CopyMemoryToStr Lib "kernel32" Alias "RtlMoveMemory" (ByVal lpvDest As String, pvSource As Any, ByVal cbCopy As Long)
Public Declare Sub ClrMemory Lib "kernel32" Alias "RtlZeroMemory" (Destination As Any, ByVal length As Long)

'// Tokenizer.
Public ZXbuffer() As Byte
Public ZxOffset As Long ' ZxBuffer pointer.
Public bASM As Boolean
Public bBin As Boolean
Public VarsBuffer() As Byte
Public VarsOffset As Long
Public hFile As Integer
Public GRAPHIC_MODE As Boolean

Public CurNBLn As Long
Public FncString As String * 6
Public Cmp_Decay As Long
Public LastLINE As Long

Public FrtLine As Long
Public ErrIndex As Long
Public InputLine As Long
Public Lines() As Long
Public lineCtr As Long
Public NewWord As Boolean
Public Prt_Trg As Boolean
Public bNum As Boolean
Public bHex As Boolean
Public bREM As Boolean
Public bSave As Boolean
Public bBas As Boolean
Public tLng As Byte ' Language trigger 1=EN 2=FR 3=DE
Public ComputerType As Byte ' Computer type 0=464,1=664,2=6128
Public cmp As Long
Public TAPcmp As Long

Public ASM_Buff() As Byte
Public Asm_OFF() As Long
Public ASM_lng() As Long
Public ASM_Add() As Long
Public ASM_Name() As String
Public ASM_cnt As Long
Public gAsmCNT As Long
Public gettag As Byte

Public Var_Array() As String

' CPC floating point number.
Type CPC_Long
        Exp As Integer ' - Exponent
        man As String ' - Mantissa
End Type

Type CPC2_Long 'GOSUB function
        Exp As Integer ' - Exponent
        man As String ' - Mantissa
End Type

Type Uint
bLow As Byte
bHig As Byte
End Type

Type Uint3
bLow As Byte
bMed As Byte
bHig As Byte
End Type

Type CPCheader ' Basic files header 128 bytes
Cpc_FileFlag As Byte
Cpc_Name As String * 8
Cpc_ATTR As String * 3
CPC_SPC1(5) As Byte
Cpc_Ftype As Byte ' 0=Basic files / 2=Binary files.
Cpc_BasLen As Uint
Cpc_OFFset As Uint3
Cpc_Flenght1 As Uint

CPC_SPC2(37) As Byte
Cpc_Flenght2 As Uint
CPC_SPC3(0) As Byte
Cpc_CRCheader As Uint

' Copy last line
'CPC_LSTline(26) As Byte
'CPC_LSTtag  As Byte
CPC_SPC4(58) As Byte
End Type

' CP/m 2.x Specification (Catalog header)
Type DirEntry
'00         user number (0 , possible values 0-15)
    User As Byte ' user 0-15
    
'01 - 0F    filename+extension (possibly filled with 0)
    root As String * 8
    ext As String * 3
    Attribut_1 As Byte
    Attribut_2 As Byte
    Attribut_3 As Byte
    Attribut_4 As Byte
    
'10         block Pointer (16)
    Block_pointer(15) As Byte

End Type
Const OFFSET_4 = 4294967296#
Const MAXINT_4 = 2147483647

Sub DecodeLine(CurLine As String)
Dim LOffset As Long
Dim TmpStr As String

LOffset = 1

CurLine = Remove_tabs(CurLine)
If InStr(1, UCase(CurLine), "[ASM") > 0 Or InStr(1, UCase(CurLine), "[ ASM") > 0 Then bASM = True Else bASM = False


Do
 Do While Left(CurLine, 1) = " "
          CurLine = Right(CurLine, Len(CurLine) - 1)
 Loop

'Decode the line number
If Not bASM Then
    If InStr(1, CurLine, " ") = 0 Then
    TmpStr = CurLine
    Else
    TmpStr = Left(CurLine, InStr(1, CurLine, " ") - 1)
    End If
    If TmpStr = "" Then LOffset = LOffset - 1: GoTo Continue
Else
    GoTo Continue2
    'LOffset = LOffset - 1
End If

If LOffset = 1 Then
    If Left(Trim(TmpStr), 2) = "##" Then Exit Sub

    If Asc(Left(TmpStr, 1)) < &H2F Or Asc(Left(TmpStr, 1)) > &H3A Then Disp_Err 8
    CurNBLn = Val(TmpStr)
    If FrtLine < 0 Then FrtLine = CurNBLn
    End If

Continue:

CurLine = Right(CurLine, Len(CurLine) - InStr(1, CurLine, " "))

If Left(CurLine, 1) = " " Then GoTo Continue

Continue2:

If LOffset = 1 Then
If Not bASM Then
    LastLINE = ZxOffset
    ZxOffset = ZxOffset + 2
End If
NewWord = True
Conv_SPGr (CurLine)
End If

If bASM Then CurLine = "": bASM = False
LOffset = LOffset + 1
Loop Until InStr(1, CurLine, " ") = 0

End Sub



Sub Conv_SPGr(text As String)
Dim GrStr As String * 2
Dim RetByte As Byte
Dim Result As Long
Dim Cnt As Long
Dim car_tmp As String * 1
Dim FunctTag As Boolean
Dim FFTag As Boolean
Dim bDEFINT As Boolean
Dim bIF As Boolean
Dim bOn As Boolean
Dim bCommand As Boolean
Dim bConsole As Boolean

Dim ASCchar As Byte
Dim CommTag As Byte
Dim bDATA As Boolean
Dim TMPNum As String
Dim Get_V As Byte
  
Prt_Trg = False
TMPNum = ""
CommTag = 0
bNum = False
bHex = False
bREM = False
NewWord = True
bCommand = True

Do While text <> ""

  car_tmp = text
  
  If car_tmp = vbTab Then car_tmp = " "
  
  
  If car_tmp = Chr(34) Then Prt_Trg = Not Prt_Trg
  
 ' If bREM And car_tmp = ":" Then bREM = False:    bCommand = True

  
  ' REM ' Symbol.
  If car_tmp = "'" And bCommand = True Then
  bREM = True
  ZxOffset = ZxOffset + 2
    ReDim Preserve ZXbuffer(ZxOffset)
    ZXbuffer(ZxOffset - 2) = &H3A
    ZXbuffer(ZxOffset - 1) = &H8E
    ZXbuffer(ZxOffset) = &HFF
    Cmp_Decay = 1
    bCommand = False
    GoTo Nxt_Word
  End If
  
  
  If (car_tmp = " " Or car_tmp = ":") And Not (Prt_Trg Or bREM) Then
       NewWord = True:    bCommand = True
  End If

Select Case car_tmp

Case "\"

'GRAPH KEY Characters.
     Cmp_Decay = 2
     GrStr = Mid(text, 2, 1)
     RetByte = GraphKey(GrStr)
    
    ReDim Preserve ZXbuffer(ZxOffset)
    ZXbuffer(ZxOffset) = RetByte
    ZxOffset = ZxOffset + 1
    text = Right(text, Len(text) - Cmp_Decay)
    Cmp_Decay = 0
  
Case "�"

  Cmp_Decay = 3
  GrStr = Mid(text, 2, 2)
  
'Specials Characters.
     RetByte = Val("&h" & GrStr)
    
    ReDim Preserve ZXbuffer(ZxOffset)
    ZXbuffer(ZxOffset) = RetByte
    ZxOffset = ZxOffset + 1
    text = Right(text, Len(text) - Cmp_Decay)
    Cmp_Decay = 0


 Case "[" 'ASM Codes!.
 
 If Not (bREM Or Prt_Trg) And bCommand Then
      text = Right(text, Len(text) - 1)
     text = Get_ASM(Right(text, Len(text) - 3))
     car_tmp = ""
     If bASM Then Exit Sub
  Else
  ' Ignore this character and print the ASCII code.
    ReDim Preserve ZXbuffer(ZxOffset)
    ZXbuffer(ZxOffset) = Asc(car_tmp)
    ZxOffset = ZxOffset + 1
    text = Right(text, Len(text) - 1)
 End If

Case Else


Cmp_Decay = 1



If text = "" Then GoTo Exit_Scan

' Get COMMANDS AND FUNCTIONS ---------------------------------------------------------------------------

        If (Not Prt_Trg) And (Not bREM) And Not ((ZxOffset - 1)) Then NewWord = True

Result = -1
FunctTag = False
Result = GetFunc(Left(text, 7))

       
        If Result <> -1 And (Prt_Trg Or bREM) And Result <> 142 Then
        Result = -1: Cmp_Decay = 1
        End If
        
 ' REM
        If Result = 142 Then bREM = True
        
 ' CONSOLE BUG : 1 CONSOLE 3,1
 ' Create the next ligne destrution !
 If Result = 165 Then bConsole = True
                
If (Prt_Trg Or bREM Or bDATA) Then gettag = 0

'Select Case gettag

'Case 1
'" TO "
''  ZxOffset = ZxOffset + 2
'    ReDim Preserve ZXbuffer(ZxOffset)
'    ZXbuffer(ZxOffset - 2) = 32
 '   ZXbuffer(ZxOffset - 1) = Result
 '   ZXbuffer(ZxOffset) = 32
 '   gettag = 0
 '   DecOff = 1
 '   bCommand = False
 '   GoTo Nxt_Word
    
'Case 2
' ="_"1234 > =1234
'    bCommand = False
'End Select

      
        If Left(text, 1) = ":" And Not Prt_Trg And Not bREM Then
            'Cmp_Decay = 1: Result = 1
            NewWord = True
            bDATA = False
            bCommand = True
            bConsole = False
        End If
        
     
'ELSE
If Result = 144 Then
  ZxOffset = ZxOffset + 1
    ReDim Preserve ZXbuffer(ZxOffset)
    ZXbuffer(ZxOffset - 1) = &H3A
    bCommand = True
End If

'Force functions to chars in REMs
If bREM And Result <> 142 Then
    NewWord = False: Cmp_Decay = 1: Result = -1
End If

'Force functions to chars in DATAs& PRINTs
If bDATA Or Prt_Trg Then
    NewWord = False: Cmp_Decay = 1: Result = -1
End If

' &H83 : DATA
If Result = 131 Then bDATA = True


If (Result = -1 Or Prt_Trg) Then

    'Cmp_Decay = 1
            
     ReDim Preserve ZXbuffer(ZxOffset)
     
     
     If Result <> -1 Then ZXbuffer(ZxOffset) = Result: NewWord = True Else ZXbuffer(ZxOffset) = CByte(Asc(car_tmp))
     

' Numeric or string values -----------------------------------------------------------------------

 
If (Not bNum And Not Prt_Trg And Not bREM And Not bDATA) And Result = -1 Then
      


      If (Not Is_ASCII(car_tmp) Or car_tmp = " ") Then


           
       ReDim Preserve ZXbuffer(ZxOffset)
       
       If Result = -1 Then
       ZXbuffer(ZxOffset) = CByte(Asc(car_tmp))
              Else
       ZXbuffer(ZxOffset) = Result
       End If
       If car_tmp = " " Then ZxOffset = ZxOffset - 1
       End If
      
Else


' REM or PRINT printed characters. (french rom set)
   If Prt_Trg Or bREM Or bDATA Then '>>

     ASCchar = CByte(Asc(car_tmp))
   Select Case car_tmp
 ' &H5C : Y=
   Case Chr(&HA5)
        ASCchar = 92
        
 Case Else
 ASCchar = Asc(PutSpChars(ASCchar))
        
          End Select
            Debug.Print text
            Debug.Print Len(text), ASCchar
         ZXbuffer(ZxOffset) = ASCchar
  End If ' Rem / PRINT / DATA <<
  
End If

       ReDim Preserve ZXbuffer(ZxOffset)

          
      ZxOffset = ZxOffset + 1
    

    text = Right(text, Len(text) - Cmp_Decay)
    
    If Not (Prt_Trg Or bREM Or bDATA) Then
    Do While Left(text, 1) = " "
      text = Right(text, Len(text) - 1)
      NewWord = True
    Loop
    End If
    


' ------------------------------------------------
 
Else
       
    ReDim Preserve ZXbuffer(ZxOffset)
    ZXbuffer(ZxOffset) = CByte(Result)

    
   
Nxt_Word:

    ' The next word can't be a command.
    If Len(text) >= Cmp_Decay Then
    If bCommand And Len(Trim(text)) > Cmp_Decay And InStr(Right(text, Len(text) - Cmp_Decay), ":") <> 1 Then
    End If
    
  '   ZxOffset = ZxOffset + 1
  '  ReDim Preserve ZXbuffer(ZxOffset)
  '   ZXbuffer(ZxOffset) = 32
    bCommand = False

    End If
    
    ZxOffset = ZxOffset + 1
    


' Jump to the next word -----------------------------------------------------------------

    If Cmp_Decay <> 0 Then
        Do While Mid(text, Cmp_Decay, 1) = " "
            Cmp_Decay = Cmp_Decay + 1
        Loop
    End If
    
   
    If text = "'" Then GoTo Exit_Scan
    If Cmp_Decay > Len(text) Then Cmp_Decay = Len(text)
    text = Right(text, Len(text) - Cmp_Decay)
    
    If Not (Prt_Trg Or bREM) Then
        Do While Left(text, 1) = " "
          text = Right(text, Len(text) - 1)
        Loop
    End If
    
    If (InStr(1, text, "[") <> 0) Then
    ' ASM
        Do While Left(text, 1) = " "
          text = Right(text, Len(text) - 1)
        Loop

    End If
    
End If
 
End Select

         
' Next word ---------------------------------------------------------------------------
Loop


Exit_Scan:

If Result = bConsole Then
'  ZxOffset = ZxOffset + 1
'    ReDim Preserve ZXbuffer(ZxOffset)
'    ZXbuffer(ZxOffset - 1) = &H3A
'    bConsole = False
End If

bConsole = False

       If (Not Prt_Trg) And (Not bREM) And Not bNum Then ClrSpc (CommTag)
     
     
If (Not Prt_Trg) And (Not bREM) Then

  If Result <> -1 Then
       'ReDim Preserve ZXbuffer(ZxOffset)
       
       '  ZXbuffer(ZxOffset) = Result
  End If
       
            'ZxOffset = ZxOffset + 1
              
End If
       
    
    ' End Of Line
    ' Line header ---------------------------------------------------------------------------
    ZxOffset = ZxOffset + 2
    
     ReDim Preserve ZXbuffer(ZxOffset)
    
    ' Write current line infos in the line header saved in the LastLINE variable ------------
    'ZXbuffer(LastLINE) = ((ZxOffset - LastLINE + 1) And &HFF)
    'ZXbuffer(LastLINE + 1) = ((ZxOffset - LastLINE + 1) And &HFF00) / 256
       

    'Line number
    If CurNBLn > 65535 Then Disp_Err 8, Str(CurNBLn) & "(UP TO 65535)": CurNBLn = CurNBLn And 65535
    ZXbuffer(LastLINE) = (CurNBLn And &HFF)
    ZXbuffer(LastLINE + 1) = CLng(CurNBLn And &HFF00) / 256
    
    'Line Footer
    'EOF
    ZXbuffer(ZxOffset) = 0
    
    'Line index
    TAPcmp = TAPcmp + (ZxOffset - LastLINE) - 1
    
    'TAP INDEX
    ZXbuffer(ZxOffset) = CByte(TAPcmp \ 256)
    ZXbuffer(ZxOffset - 1) = CByte(TAPcmp And 255)
    
    
    ' Line too big.
    If (ZxOffset - LastLINE - 3) > 79 Then
    Disp_Err 22, " (" + Trim(Str(ZxOffset - LastLINE - 3)) + " chars)"
    End If
        
    Prt_Trg = False
    TMPNum = ""
    bNum = False
    bHex = False
    bDEFINT = False
    bDATA = False

        
   
        ZxOffset = ZxOffset + 1


    
    lineCtr = lineCtr + 1
    ReDim Preserve Lines(lineCtr)
    Lines(UBound(Lines)) = CurNBLn
    

End Sub



Sub Disp_Err(ErrNumb As Byte, Optional Comment As String = "")

If Len(frmMain.Status) >= 27585 Then Exit Sub

Dim ErrStr As String
Dim ErrID As String
If ErrNumb <> 0 And ErrNumb <> 20 Then
ErrIndex = ErrIndex + 1
ErrID = "Error#" + Format(ErrIndex, "####") + ":"
If Len(frmMain.Status) <= (27585 - 17) Then frmMain.Status = frmMain.Status & ErrID
'FrmMain.Comments = FrmMain.Comments + "Error#" + Format(ErrIndex, "####") + ":"
End If

Select Case ErrNumb
Case 0
ErrStr = "Started." + vbCrLf
Case 1
ErrStr = "Label start line must be in the range 0 to 9999." + vbCrLf

Case 2
ErrStr = "Label line incr. must be in the range 1 to 9990." + vbCrLf

Case 3
ErrStr = "line " & InputLine & ": invalid block graphics. (Basic line " + Str(CurNBLn) + ")" + vbCrLf

Case 4
ErrStr = "line " & InputLine & ": Non-mappable character in input (Basic line " + Str(CurNBLn) + ")" + vbCrLf

Case 5
ErrStr = "Could not open input file." & vbCrLf

Case 6
ErrStr = "line " & InputLine & ": missing line number [" & Comment & "]" + vbCrLf

Case 7
ErrStr = "line " & InputLine & ": line #.[" & Comment & "] not greater than previous one" + vbCrLf

Case 8
ErrStr = "line " & InputLine & ": line #.[" & Comment & "] Line out of Basic range" + vbCrLf

Case 9
ErrStr = "line " & InputLine & ": line #. [" & Comment & "] already exists." + vbCrLf

Case 10
ErrStr = "Basic program too big ...(Up to 41700 Bytes) [" & Comment & " b.]" + vbCrLf + "(You had to trim your Basic program !... But, dont forget to reserve roms to the variable buffer !)" + vbCrLf

Case 11
ErrStr = "line " & InputLine & ": CPC Double convertion error [" & Comment & "] in Output (Basic line " + Str(CurNBLn) + ")" + vbCrLf

Case 12
ErrStr = "Basic line " & Comment & ": Command code missing !" + vbCrLf

Case 20
ErrStr = "BASIC program length:" & Comment & vbCrLf & "Success." & vbCrLf

Case 21
ErrStr = "Failed : File error, can't open this file." + vbCrLf

Case 22
ErrStr = "line " & InputLine & ": [Basic line #" & Str(CurNBLn) & "] Line Excide 79 characters !!!" + Comment + vbCrLf

End Select
If (Len(frmMain.Status & ErrStr) >= 27585 And Len(frmMain.Status) < 27585) Then frmMain.Status = frmMain.Status & "Too many errors !" & vbCrLf
If Len(frmMain.Status & ErrStr) < 27585 Then frmMain.Status = frmMain.Status & ErrStr
'FrmMain.Comments = FrmMain.Comments + ErrStr
End Sub



Private Function Get_ASM(text As String) As String
Dim tmpchar As String
Dim TmpVal As Long
Dim ScanChar As String * 1
Dim BaseFlag As Byte
Dim JoChar As String * 1


' ASM_Buff() Main Byte buffer.
' Asm_OFF() Location in ASM_BUFFER.
' ASM_Add() Address where the buffer bloc is.
' ASM_lng() Lenght of bloc
' ASM_cnt Asm counter (0-xx)
' gAsmCNT Global asm counter.


If Trim(UCase(Left(text, 4))) = "ORG" Then
 text = Right(text, Len(text) - InStr(1, text, "("))
 
  tmpchar = Left(text, InStr(1, text, ")") - 1)
  text = Right(text, Len(text) - InStr(1, text, ")"))

 ReDim Preserve ASM_Add(ASM_cnt)
 If InStr(1, UCase(tmpchar), "H") > 0 Then
  If UCase(Right(tmpchar, 1)) = "H" Then
  tmpchar = Left(tmpchar, InStr(1, UCase(tmpchar), "H") - 1)
  Else
  tmpchar = Right(tmpchar, Len(tmpchar) - InStr(1, UCase(tmpchar), "H"))
  End If
  
  
  ASM_Add(ASM_cnt) = ASChex(tmpchar)
  
  Else
   ASM_Add(ASM_cnt) = Val(tmpchar)
  End If
  
 ReDim Preserve Asm_OFF(ASM_cnt)
 Asm_OFF(ASM_cnt) = gAsmCNT
 ReDim Preserve ASM_lng(ASM_cnt)
End If



'Retriev Base Specs.
   tmpchar = ""
   ScanChar = text
   Do While ScanChar = ";" Or ScanChar = "," Or ScanChar = ":" Or ScanChar = "/" Or ScanChar = "-" Or ScanChar = " "
      text = Right(text, Len(text) - 1)
      If ScanChar = "]" Or Trim(text) = "" Then GoTo endscan1:
      ScanChar = text
   Loop
   
 ReDim Preserve ASM_Name(ASM_cnt)
  If InStr(1, text, "X07NAME:") Then
        text = Right(text, Len(text) - 8)
        
        If Left(text, 1) = Chr(34) Then text = Right(text, Len(text) - 1)
        
        If InStr(1, text, Chr(34)) > 6 Or InStr(1, text, Chr(34)) = 0 Then

        ASM_Name(ASM_cnt) = Left(text, InStr(1, text, " ") - 1)
        text = Right(text, Len(text) - InStr(1, text, " ") + 1)
        Else
        ASM_Name(ASM_cnt) = Left(text, InStr(1, text, Chr(34)) - 1)
        text = Right(text, Len(text) - InStr(1, text, Chr(34)))
 End If
 If Len(ASM_Name(ASM_cnt)) > 6 Then ASM_Name(ASM_cnt) = Left(ASM_Name(ASM_cnt), 6)
        
            
   'Retriev Base Specs.
   tmpchar = ""
   ScanChar = text
   Do While ScanChar = ";" Or ScanChar = "," Or ScanChar = ":" Or ScanChar = "/" Or ScanChar = "-" Or ScanChar = " "
      text = Right(text, Len(text) - 1)
      If ScanChar = "]" Or Trim(text) = "" Then GoTo endscan1:
      ScanChar = text
   Loop

  End If
   
Select Case UCase(Left(text, 3))
    Case "HEX"
        BaseFlag = 1
    Case "DEC"
        BaseFlag = 2
    Case "BIN"
        BaseFlag = 3
    Case Else
        ErrIndex = ErrIndex + 1
        frmMain.Status = frmMain.Status & "Error#" & Format(ErrIndex, "####") & ":"
        frmMain.Status = frmMain.Status & "line " & InputLine & ": [" & UCase(Left(text, 3)) & "] invalid Base (BIN,HEX or DEC)." + vbCrLf
        Exit Function
End Select

    text = Right(text, Len(text) - 3)
    
Do Until Trim(text) = "" Or ScanChar = "]"
   tmpchar = ""
   ScanChar = text
   Do While ScanChar = ";" Or ScanChar = "," Or ScanChar = ":" Or ScanChar = " " Or ScanChar = " "
      text = Right(text, Len(text) - 1)
      ScanChar = text
   Loop
         If ScanChar = "]" Then GoTo endscan1:

   Do
   
Select Case BaseFlag
   Case 1
     If Not Is_HEX(Asc(ScanChar)) Then
      ErrIndex = ErrIndex + 1
      frmMain.Status = frmMain.Status & "Error#" & Format(ErrIndex, "####") & ":"
      frmMain.Status = frmMain.Status & "line " & InputLine & ": [" & ScanChar & "] invalid hexadecimal character." + vbCrLf
     Else
      tmpchar = tmpchar + ScanChar
     End If
    Case 2
      If Not Is_DEC(Asc(ScanChar)) Then
      ErrIndex = ErrIndex + 1
      frmMain.Status = frmMain.Status & "Error#" & Format(ErrIndex, "####") & ":"
      frmMain.Status = frmMain.Status & "line " & InputLine & ": [" & ScanChar & "] invalid decimal character." + vbCrLf
     Else
      tmpchar = tmpchar + ScanChar
     End If
    Case 3
      If Not Is_BIN(Asc(ScanChar)) Then
      ErrIndex = ErrIndex + 1
      frmMain.Status = frmMain.Status & "Error#" & Format(ErrIndex, "####") & ":"
      frmMain.Status = frmMain.Status & "line " & InputLine & ": [" & ScanChar & "] invalid binary character." + vbCrLf
     Else
      tmpchar = tmpchar + ScanChar
     End If
End Select

   text = Right(text, Len(text) - 1)
        ScanChar = text
   Loop Until ScanChar = ";" Or ScanChar = "," Or ScanChar = ":" Or ScanChar = " " Or ScanChar = "]"
      

   tmpchar = Trim(tmpchar)
   
   Select Case BaseFlag
   Case 1
   TmpVal = ASChex(tmpchar)
   Case 2
   TmpVal = Val(tmpchar)
   Case 3
   TmpVal = BinToDbl(tmpchar)
   End Select
   
   If TmpVal > 255 Then
    ErrIndex = ErrIndex + 1
      frmMain.Status = frmMain.Status & "Error#" + Format(ErrIndex, "####") & ":"
      frmMain.Status = frmMain.Status & "line " & InputLine & ": [" & tmpchar & "] too big." + vbCrLf
   Else
   
         ReDim Preserve ASM_Buff(gAsmCNT)
          ASM_Buff(gAsmCNT) = CByte(TmpVal)
          gAsmCNT = gAsmCNT + 1
          ASM_lng(ASM_cnt) = ASM_lng(ASM_cnt) + 1
          
         
   End If
   ScanChar = text
   If ScanChar = "]" Then
  
   End If
Loop

endscan1:

     If ScanChar = "]" Then text = Right(text, Len(text) - 1)
     
 'Asm_OFF(ASM_cnt) = ASM_lng(ASM_cnt) + ASM_lng(ASM_cnt - 1)
 
Get_ASM = text
ASM_cnt = ASM_cnt + 1

End Function





'Convert Zx byte chars codes to ZxText2P string.

Private Function Conv_SPGrByte(ZxBYTE As Byte) As String

Dim Conv_str As String
Conv_str = ""

  Select Case ZxBYTE
    Case &HC0
    Conv_str = "\" & Chr(&H22)
'    Case &H0
'    Conv_str = "\  "
    Case &H1
    Conv_str = "\' "
    Case &H2
    Conv_str = "\ '"
    Case &H3
    Conv_str = "\''"
    Case &H4
    Conv_str = "\. "
    Case &H5
    Conv_str = "\: "
    Case &H6
    Conv_str = "\.'"
    Case &H7
    Conv_str = "\:'"
    Case &H8
    Conv_str = "\##"
    Case &H9
    Conv_str = "\,,"
    Case &HA
    Conv_str = "\~~"
    Case &H80
    Conv_str = "\::"
    Case &H81
    Conv_str = "\.:"
    Case &H82
    Conv_str = "\:."
    Case &H83
    Conv_str = "\.."
    Case &H84
    Conv_str = "\':"
    Case &H85
    Conv_str = "\ :"
    Case &H86
    Conv_str = "\'."
    Case &H87
    Conv_str = "\ ."
    Case &H88
    Conv_str = "\@@"
    Case &H89
    Conv_str = "\;;"
    Case &H8A
    Conv_str = "\!!"
    Case Else
    Conv_str = ""
   End Select
   
   If ZxBYTE > 138 And ZxBYTE < 192 Then Conv_str = "%" & (ZxBYTE And 127)

       
Conv_SPGrByte = Conv_str


End Function



Function Remove_tabs(LineText As String) As String
Dim TmpLineText As String
Dim TabLoc As Long

TmpLineText = ""
TabLoc = 1

Do
TabLoc = InStr(TabLoc, LineText, vbTab)
If TabLoc = 0 Then Exit Do
If TabLoc <> 1 Then TmpLineText = TmpLineText & Left(LineText, TabLoc - 1) & " " Else TmpLineText = TmpLineText & " "
LineText = Right(LineText, Len(LineText) - TabLoc)
TabLoc = 1
Loop While TabLoc > 0
Remove_tabs = TmpLineText & LineText
End Function


Private Function GetFunc(TXT As String) As Long
 ' &H8B : RESTORE
 ' &HA5 : CONSOLE
 ' &HC0 : STRING$
 ' &H8D : RETURN
 ' &H93 : DEFSTR
 ' &H94 : DEFINT
 ' &H95 : DEFSNG
 ' &H96 : DEFDBL
 ' &H99 : RESUME
 ' &H9C : LPRINT
 ' &HA4 : CIRCLE
 ' &HA9 : LOCATE
 ' &HAB : PRESET
 ' &HAF : DELETE
 ' &HC2 : INKEY$
 ' &HC4 : VARPTR
 ' &HCA : START$
 ' &HCD : SCREEN
 ' &HF9 : RIGHT$
 ' &HFB : CSRLIN
 ' &H84 : INPUT
 ' &H8C : GOSUB
 ' &H92 : MOTOR
 ' &H98 : ERROR
 ' &H9D : DEFFN
 ' &H9F : PRINT
 ' &HA2 : LLIST
 ' &HA3 : CLEAR
 ' &HA7 : COLOR
 ' &HAD : SLEEP
 ' &HB1 : PAINT
 ' &HB5 : ERASE
 ' &HB7 : CLOAD
 ' &HB8 : CSAVE
 ' &HBD : USING
 ' &HC1 : INSTR
 ' &HC8 : DATE$
 ' &HC9 : TIME$
 ' &HCB : FONT$
 ' &HF8 : LEFT$
 ' &HFC : STICK
 ' &HFD : STRIG
 ' &HFE : POINT
 ' &H82 : NEXT
 ' &H83 : DATA
 ' &H86 : READ
 ' &H88 : GOTO
 ' &H8F : STOP
 ' &H90 : ELSE
 ' &H97 : LINE
 ' &H9E : POKE
 ' &HA0 : CONT
 ' &HA1 : LIST
 ' &HA8 : EXEC
 ' &HAA : PSET
 ' &HB0 : FSET
 ' &HB2 : LOAD
 ' &HB3 : SAVE
 ' &HB4 : INIT
 ' &HB6 : BEEP
 ' &HBA : TAB(
 ' &HC7 : ALM$
 ' &HCC : KEY$
 ' &HCE : THEN
 ' &HD0 : STEP
 ' &HEC : PEEK
 ' &HED : CINT
 ' &HEE : CSNG
 ' &HEF : CDBL
 ' &HF2 : HEX$
 ' &HF3 : STR$
 ' &HF6 : CHR$
 ' &HF7 : TKEY
 ' &HFA : MID$
 ' &H80 : END
 ' &H81 : FOR
 ' &H85 : DIM
 ' &H87 : LET
 ' &H89 : RUN
 ' &H8E : REM
 ' &H9A : OUT
 ' &HA6 : CLS
 ' &HAC : OFF
 ' &HAE : DIR
 ' &HB9 : NEW
 ' &HBE : ERL
 ' &HBF : ERR
 ' &HC3 : INP
 ' &HC5 : USR
 ' &HC6 : SNS
 ' &HCF : NOT
 ' &HD6 : AND
 ' &HD8 : XOR
 ' &HD9 : EQV
 ' &HDA : MOD
 ' &HDF : SGN
 ' &HE0 : INT
 ' &HE1 : ABS
 ' &HE2 : FRE
 ' &HE3 : POS
 ' &HE4 : SQR
 ' &HE5 : RND
 ' &HE6 : LOG
 ' &HE7 : EXP
 ' &HE8 : COS
 ' &HE9 : SIN
 ' &HEA : TAN
 ' &HEB : ATN
 ' &HF0 : FIX
 ' &HF1 : LEN
 ' &HF4 : VAL
 ' &HF5 : ASC
 ' &H8A : IF
 ' &H91 : TR
 ' &H9B : ON
 ' &HBB : TO
 ' &HBC : FN
 ' &HD7 : OR
 ' &HD1 : +
 ' &HD2 : -
 ' &HD3 : *
 ' &HD4 : /
 ' &HD5 : ^
 ' &HDB : \
 ' &HDC : >
 ' &HDD : =
 ' &HDE : <

Dim Txt2 As String * 1

GetFunc = -1
Txt2 = TXT
If Txt2 = Chr(20) Then NewWord = True
If NewWord = False Then Exit Function



Cmp_Decay = 7
TXT = UCase(Left(TXT, 7))

'7 characters.
Select Case TXT

 ' &H8B : RESTORE
   Case "RESTORE"
        GetFunc = 139
        gettag = 0


 ' &HA5 : CONSOLE
   Case "CONSOLE"
        GetFunc = 165
        gettag = 0


 ' &HC0 : STRING$
   Case "STRING$"
        GetFunc = 192
        gettag = 0

End Select

If GetFunc <> -1 Then Exit Function

Cmp_Decay = 6
TXT = UCase(Left(TXT, 6))

'6 characters.
Select Case TXT

 ' &H8D : RETURN
   Case "RETURN"
        GetFunc = 141
        gettag = 0


 ' &H93 : DEFSTR
   Case "DEFSTR"
        GetFunc = 147
        gettag = 0


 ' &H94 : DEFINT
   Case "DEFINT"
        GetFunc = 148
        gettag = 0


 ' &H95 : DEFSNG
   Case "DEFSNG"
        GetFunc = 149
        gettag = 0


 ' &H96 : DEFDBL
   Case "DEFDBL"
        GetFunc = 150
        gettag = 0


 ' &H99 : RESUME
   Case "RESUME"
        GetFunc = 153
        gettag = 0


 ' &H9C : LPRINT
   Case "LPRINT"
        GetFunc = 156
        gettag = 0


 ' &HA4 : CIRCLE
   Case "CIRCLE"
        GetFunc = 164
        gettag = 0


 ' &HA9 : LOCATE
   Case "LOCATE"
        GetFunc = 169
        gettag = 0


 ' &HAB : PRESET
   Case "PRESET"
        GetFunc = 171
        gettag = 0


 ' &HAF : DELETE
   Case "DELETE"
        GetFunc = 175
        gettag = 0


 ' &HC2 : INKEY$
   Case "INKEY$"
        GetFunc = 194
        gettag = 0


 ' &HC4 : VARPTR
   Case "VARPTR"
        GetFunc = 196
        gettag = 0


 ' &HCA : START$
   Case "START$"
        GetFunc = 202
        gettag = 0


 ' &HCD : SCREEN
   Case "SCREEN"
        GetFunc = 205
        gettag = 0


 ' &HF9 : RIGHT$
   Case "RIGHT$"
        GetFunc = 249
        gettag = 0


 ' &HFB : CSRLIN
   Case "CSRLIN"
        GetFunc = 251
        gettag = 0

End Select

If GetFunc <> -1 Then Exit Function


Cmp_Decay = 5
TXT = UCase(Left(TXT, 5))

'5 characters.
Select Case TXT

 ' &H84 : INPUT
   Case "INPUT"
        GetFunc = 132
        gettag = 0


 ' &H8C : GOSUB
   Case "GOSUB"
        GetFunc = 140
        gettag = 0


 ' &H92 : MOTOR
   Case "MOTOR"
        GetFunc = 146
        gettag = 0


 ' &H98 : ERROR
   Case "ERROR"
        GetFunc = 152
        gettag = 0


 ' &H9D : DEFFN
   Case "DEFFN"
        GetFunc = 157
        gettag = 0


 ' &H9F : PRINT
   Case "PRINT"
        GetFunc = 159
        gettag = 0


 ' &HA2 : LLIST
   Case "LLIST"
        GetFunc = 162
        gettag = 0


 ' &HA3 : CLEAR
   Case "CLEAR"
        GetFunc = 163
        gettag = 0


 ' &HA7 : COLOR
   Case "COLOR"
        GetFunc = 167
        gettag = 0


 ' &HAD : SLEEP
   Case "SLEEP"
        GetFunc = 173
        gettag = 0


 ' &HB1 : PAINT
   Case "PAINT"
        GetFunc = 177
        gettag = 0


 ' &HB5 : ERASE
   Case "ERASE"
        GetFunc = 181
        gettag = 0


 ' &HB7 : CLOAD
   Case "CLOAD"
        GetFunc = 183
        gettag = 0


 ' &HB8 : CSAVE
   Case "CSAVE"
        GetFunc = 184
        gettag = 0


 ' &HBD : USING
   Case "USING"
        GetFunc = 189
        gettag = 0


 ' &HC1 : INSTR
   Case "INSTR"
        GetFunc = 193
        gettag = 0


 ' &HC8 : DATE$
   Case "DATE$"
        GetFunc = 200
        gettag = 0


 ' &HC9 : TIME$
   Case "TIME$"
        GetFunc = 201
        gettag = 0


 ' &HCB : FONT$
   Case "FONT$"
        GetFunc = 203
        gettag = 0


 ' &HF8 : LEFT$
   Case "LEFT$"
        GetFunc = 248
        gettag = 0


 ' &HFC : STICK
   Case "STICK"
        GetFunc = 252
        gettag = 0


 ' &HFD : STRIG
   Case "STRIG"
        GetFunc = 253
        gettag = 0


 ' &HFE : POINT
   Case "POINT"
        GetFunc = 254
        gettag = 0

End Select

If GetFunc <> -1 Then Exit Function


Cmp_Decay = 4
TXT = UCase(Left(TXT, 4))

'4 characters.
Select Case TXT

 ' &H82 : NEXT
   Case "NEXT"
        GetFunc = 130
        gettag = 0


 ' &H83 : DATA
   Case "DATA"
        GetFunc = 131
        gettag = 0


 ' &H86 : READ
   Case "READ"
        GetFunc = 134
        gettag = 0


 ' &H88 : GOTO
   Case "GOTO"
        GetFunc = 136
        gettag = 0


 ' &H8F : STOP
   Case "STOP"
        GetFunc = 143
        gettag = 0


 ' &H90 : ELSE
   Case "ELSE"
        GetFunc = 144
        gettag = 0


 ' &H97 : LINE
   Case "LINE"
        GetFunc = 151
        gettag = 0


 ' &H9E : POKE
   Case "POKE"
        GetFunc = 158
        gettag = 0


 ' &HA0 : CONT
   Case "CONT"
        GetFunc = 160
        gettag = 0


 ' &HA1 : LIST
   Case "LIST"
        GetFunc = 161
        gettag = 0


 ' &HA8 : EXEC
   Case "EXEC"
        GetFunc = 168
        gettag = 0


 ' &HAA : PSET
   Case "PSET"
        GetFunc = 170
        gettag = 0


 ' &HB0 : FSET
   Case "FSET"
        GetFunc = 176
        gettag = 0


 ' &HB2 : LOAD
   Case "LOAD"
        GetFunc = 178
        gettag = 0


 ' &HB3 : SAVE
   Case "SAVE"
        GetFunc = 179
        gettag = 0


 ' &HB4 : INIT
   Case "INIT"
        GetFunc = 180
        gettag = 0


 ' &HB6 : BEEP
   Case "BEEP"
        GetFunc = 182
        gettag = 0


 ' &HBA : TAB(
   Case "TAB("
        GetFunc = 186
        gettag = 0


 ' &HC7 : ALM$
   Case "ALM$"
        GetFunc = 199
        gettag = 0


 ' &HCC : KEY$
   Case "KEY$"
        GetFunc = 204
        gettag = 0


 ' &HCE : THEN
   Case "THEN"
        GetFunc = 206
        gettag = 0


 ' &HD0 : STEP
   Case "STEP"
        GetFunc = 208
        gettag = 1


 ' &HEC : PEEK
   Case "PEEK"
        GetFunc = 236
        gettag = 0


 ' &HED : CINT
   Case "CINT"
        GetFunc = 237
        gettag = 0


 ' &HEE : CSNG
   Case "CSNG"
        GetFunc = 238
        gettag = 0


 ' &HEF : CDBL
   Case "CDBL"
        GetFunc = 239
        gettag = 0


 ' &HF2 : HEX$
   Case "HEX$"
        GetFunc = 242
        gettag = 0


 ' &HF3 : STR$
   Case "STR$"
        GetFunc = 243
        gettag = 0


 ' &HF6 : CHR$
   Case "CHR$"
        GetFunc = 246
        gettag = 0


 ' &HF7 : TKEY
   Case "TKEY"
        GetFunc = 247
        gettag = 0


 ' &HFA : MID$
   Case "MID$"
        GetFunc = 250
        gettag = 0


End Select

If GetFunc <> -1 Then Exit Function

Cmp_Decay = 3
TXT = UCase(Left(TXT, 3))

'3 characters.
Select Case TXT

 ' &H80 : END
   Case "END"
        GetFunc = 128
        gettag = 0


 ' &H81 : FOR
   Case "FOR"
        GetFunc = 129
        gettag = 0


 ' &H85 : DIM
   Case "DIM"
        GetFunc = 133
        gettag = 0


 ' &H87 : LET
   Case "LET"
        GetFunc = 135
        gettag = 0


 ' &H89 : RUN
   Case "RUN"
        GetFunc = 137
        gettag = 0


 ' &H8E : REM
   Case "REM"
        GetFunc = 142
        gettag = 0


 ' &H9A : OUT
   Case "OUT"
        GetFunc = 154
        gettag = 0


 ' &HA6 : CLS
   Case "CLS"
        GetFunc = 166
        gettag = 0


 ' &HAC : OFF
   Case "OFF"
        GetFunc = 172
        gettag = 0


 ' &HAE : DIR
   Case "DIR"
        GetFunc = 174
        gettag = 0


 ' &HB9 : NEW
   Case "NEW"
        GetFunc = 185
        gettag = 0


 ' &HBE : ERL
   Case "ERL"
        GetFunc = 190
        gettag = 0


 ' &HBF : ERR
   Case "ERR"
        GetFunc = 191
        gettag = 0


 ' &HC3 : INP
   Case "INP"
        GetFunc = 195
        gettag = 0


 ' &HC5 : USR
   Case "USR"
        GetFunc = 197
        gettag = 0


 ' &HC6 : SNS
   Case "SNS"
        GetFunc = 198
        gettag = 0


 ' &HCF : NOT
   Case "NOT"
        GetFunc = 207
        gettag = 0


 ' &HD6 : AND
   Case "AND"
        GetFunc = 214
        gettag = 0


 ' &HD8 : XOR
   Case "XOR"
        GetFunc = 216
        gettag = 0


 ' &HD9 : EQV
   Case "EQV"
        GetFunc = 217
        gettag = 0


 ' &HDA : MOD
   Case "MOD"
        GetFunc = 218
        gettag = 0


 ' &HDF : SGN
   Case "SGN"
        GetFunc = 223
        gettag = 0


 ' &HE0 : INT
   Case "INT"
        GetFunc = 224
        gettag = 0


 ' &HE1 : ABS
   Case "ABS"
        GetFunc = 225
        gettag = 0


 ' &HE2 : FRE
   Case "FRE"
        GetFunc = 226
        gettag = 0


 ' &HE3 : POS
   Case "POS"
        GetFunc = 227
        gettag = 0


 ' &HE4 : SQR
   Case "SQR"
        GetFunc = 228
        gettag = 0


 ' &HE5 : RND
   Case "RND"
        GetFunc = 229
        gettag = 0


 ' &HE6 : LOG
   Case "LOG"
        GetFunc = 230
        gettag = 0


 ' &HE7 : EXP
   Case "EXP"
        GetFunc = 231
        gettag = 0


 ' &HE8 : COS
   Case "COS"
        GetFunc = 232
        gettag = 0


 ' &HE9 : SIN
   Case "SIN"
        GetFunc = 233
        gettag = 0


 ' &HEA : TAN
   Case "TAN"
        GetFunc = 234
        gettag = 0


 ' &HEB : ATN
   Case "ATN"
        GetFunc = 235
        gettag = 0


 ' &HF0 : FIX
   Case "FIX"
        GetFunc = 240
        gettag = 0


 ' &HF1 : LEN
   Case "LEN"
        GetFunc = 241
        gettag = 0


 ' &HF4 : VAL
   Case "VAL"
        GetFunc = 244
        gettag = 0


 ' &HF5 : ASC
   Case "ASC"
        GetFunc = 245
        gettag = 0

End Select

If GetFunc <> -1 Then Exit Function


Cmp_Decay = 2
TXT = UCase(Left(TXT, 2))

'2 characters.
Select Case TXT

 ' &H8A : IF
   Case "IF"
        GetFunc = 138
        gettag = 0


 ' &H91 : TR
   Case "TR"
        GetFunc = 145
        gettag = 0


 ' &H9B : ON
   Case "ON"
        GetFunc = 155
        gettag = 0


 ' &HBB : TO
   Case "TO"
        GetFunc = 187
        gettag = 1


 ' &HBC : FN
   Case "FN"
        GetFunc = 188
        gettag = 0


 ' &HD7 : OR
   Case "OR"
        GetFunc = 215
        gettag = 0


End Select

If GetFunc <> -1 Then Exit Function


Cmp_Decay = 1
TXT = UCase(Left(TXT, 1))

'1 characters.
Select Case TXT

 ' &HD1 : +
   Case "+"
        GetFunc = 209
        gettag = 0


 ' &HD2 : -
   Case "-"
        GetFunc = 210
        gettag = 0


 ' &HD3 : *
   Case "*"
        GetFunc = 211
        gettag = 0


 ' &HD4 : /
   Case "/"
        GetFunc = 212
        gettag = 0


 ' &HD5 : ^
   Case "^"
        GetFunc = 213
        gettag = 0


 ' &HDB : \
   Case "\"
        GetFunc = 219
        gettag = 0


 ' &HDC : >
   Case ">"
        GetFunc = 220
        gettag = 0


 ' &HDD : =
   Case "="
        GetFunc = 221
        gettag = 2


 ' &HDE : <
   Case "<"
        GetFunc = 222
        gettag = 0
        
        
 ' &H5C : Y=
   Case "�"
        GetFunc = 92
        gettag = 0
        
 ' &H** : e
   Case "�", "�", "�"
        GetFunc = &H65
        gettag = 0
        
' &H** : a
   Case "�", "�"
        GetFunc = &H61
        gettag = 0
        
' &H69 : i
   Case "�", "�"
        GetFunc = &H69
        gettag = 0
        
' &H6F : o
   Case "�", "�"
        GetFunc = &H6F
        gettag = 0
        
 ' &H8E : REM
 ' Case "'"
 '       GetFunc = 142
 '      gettag = 0
End Select

'If TXT = Chr(20) Then NewWord = True Else NewWord = False

End Function



' Internal function cut attributes "disk.TXT" = "disk"
Public Function Cut_attr(Char As String) As String
Cut_attr = Char
For cmp = Len(Char) To 1 Step -1
If Mid(Char, cmp, 1) = "." Then Cut_attr = Mid(Char, 1, cmp - 1): Exit For
If Mid(Char, cmp, 1) = "\" Then Cut_attr = Char: Exit For
Next cmp
End Function
' Internal function cut Name "c:\a\b\disk.TXT" = "disk.txt"
Public Function Cut_Name(Char As String) As String

Cut_Name = ""
For cmp = Len(Char) To 1 Step -1
If Mid(Char, cmp, 1) = "\" Then Exit For
Next cmp
Cut_Name = Right(Char, Len(Char) - cmp)
End Function


Function Is_DEC(Key As Integer) As Boolean
Is_DEC = True
If Key = vbKeyReturn Or Key = vbKeyLeft Or Key = vbKeyRight Or Key = vbKeyBack Or Key = vbKeyDelete Or Key = vbKeyInsert Then Exit Function
If (Key < &H30 Or Key > &H39) Then Is_DEC = False
End Function

Function Is_HEX(Key As Integer) As Boolean
Is_HEX = True
If Key = vbKeyReturn Or Key = vbKeyLeft Or Key = vbKeyRight Or Key = vbKeyBack Or Key = vbKeyDelete Or Key = vbKeyInsert Then Exit Function
If Not (Asc(UCase(Chr(Key))) > &H40 And Asc(UCase(Chr(Key))) < &H47) _
And Not (Key > &H2F And Key < &H3A) Then Is_HEX = False: GoTo Key_is_ok
Key_is_ok:
End Function

Function Is_BIN(Key As Integer) As Boolean
Is_BIN = True
If Key = vbKeyReturn Or Key = vbKeyLeft Or Key = vbKeyRight Or Key = vbKeyBack Or Key = vbKeyDelete Or Key = vbKeyInsert Then Exit Function
If Not (Key = vbKey0 Or Key = vbKey1 Or Key = vbKeyNumpad0 Or Key = vbKeyNumpad1) Then Is_BIN = False
End Function

Function ASChex(Strhex As String) As Long
If Len(Strhex) >= 8 Then ASChex = &HFFFF: Exit Function

Dim multi As String
Dim a As Integer
multi = 0
ASChex = 0
If Strhex = "" Then Exit Function

For a = Len(Strhex) To 1 Step -1
ASChex = ASChex + (Val("&h" & Mid(Strhex, a, 1)) * (16 ^ multi))
multi = multi + 1
Next

End Function

Function BinToDbl(Value As String) As Double
    'Convertir cha�ne binaire en entier long
    '  Value$ - cha�ne binaire , par exemple "0110101"
    '  Dez#   - Entier long (Type Double)
    Dim Dezimal As Double
    Dim MaxLen As Integer
    Dim b As Integer, X As Integer
  
    MaxLen = Len(Value)
    For X = 1 To MaxLen
        b = Val(Mid$(Value, X, 1))
        Dezimal = Dezimal + b * 2 ^ (MaxLen - X)
    Next
    BinToDbl = Dezimal
End Function

Function Is_ChrHEX(Key As String) As Boolean
Is_ChrHEX = True
' Is A-F and 0-9
If Not (Asc(UCase(Key)) > &H40 And Asc(UCase(Key)) < &H47) _
And Not (Asc(UCase(Key)) > &H2F And Asc(UCase(Key)) < &H3A) Then Is_ChrHEX = False

End Function

Function Is_AfHEX(Key As String) As Boolean
' Is A-F
Is_AfHEX = True
If Not (Asc(UCase(Key)) > &H40 And Asc(UCase(Key)) < &H47) Then Is_AfHEX = False
End Function

Function Is_ASCII(Key As String) As Boolean
Is_ASCII = True

If Not (Asc(UCase(Key)) > &H40 And Asc(UCase(Key)) < &H5B) _
And Not (Asc(Key) > &H2F And Asc(Key) < &H3A) Then Is_ASCII = False

End Function



Function DBL2Chars(Dblvalues As CPC_Long) As String
'(1) 1F=Double tag
'(2) : GetVals.man (Byte 4)
'(3) : GetVals.man (Byte 3)
'(4) : GetVals.man (Byte 2)
'(5) : GetVals.man (Byte 1)
'(6) : (GetVals.Exp+1) (integer)
Dim i
DBL2Chars = ""
For i = 7 To 1 Step -2
DBL2Chars = DBL2Chars + Chr(Val("&H" & Mid(Dblvalues.man, i, 2)))
Next
DBL2Chars = DBL2Chars & Chr(Dblvalues.Exp)
End Function


Sub ClrSpc(CommTag As Byte)

' Remove Spaces.
Select Case CommTag
Case 170, 168
ZxOffset = ZxOffset - 1
Case Is > 239
ZxOffset = ZxOffset - 1
Case Else
End Select

End Sub


Public Function UnsignedToLong(Value As Double) As Long
    If Value < 0 Or Value >= OFFSET_4 Then Error 6
    
    If Value <= MAXINT_4 Then
        UnsignedToLong = Value
    Else
        UnsignedToLong = Value - OFFSET_4
    End If
End Function

Function Hex16(Value As Long) As String
If Value >= &H10000 Then Hex16 = "FFFF": Exit Function
If Value < &H10 Then
   Hex16 = "000" & Hex(Value): Exit Function
ElseIf Value < &H100 Then
   Hex16 = "00" & Hex(Value): Exit Function
ElseIf Value < &H1000 Then
   Hex16 = "0" & Hex(Value): Exit Function
End If
Hex16 = Hex8(Value \ &H100) & Hex8(Value - (Value \ &H100) * &H100)
End Function

Function Hex8(Value As Long) As String
If Value >= &H100 Then Hex8 = "FF": Exit Function
If Value < &H10 Then Hex8 = "0" & Hex(Value) Else Hex8 = Hex(Value)
End Function

Function ADD_String(VarString As String, Offset As Byte)
Dim Is_Here As Boolean
Dim Cnt As Integer
Dim TmpOFF As Long

Is_Here = False
For Cnt = 0 To UBound(Var_Array)
If VarString = Var_Array(Cnt) Then Is_Here = True: Exit For
Next

If Not Is_Here Then
Var_Array(Cnt - 1) = VarString: ReDim Preserve Var_Array(UBound(Var_Array) + 1)
Else
Cnt = Cnt + 1
End If

TmpOFF = IIf(Cnt > 1, (Cnt - 2) * 9, 0) + IIf(Cnt > 1, 5, 0)
On Error Resume Next
Offset = ((TmpOFF& And &HFF00) \ &H100) + (TmpOFF And &HFF)

Debug.Print VarString, Offset

End Function

Public Function Get_Path(Fname As String) As String
' Internal function cut Name "c:\a\b\disk.TXT" = "disk.txt"
If Fname = "" Then Get_Path = "": Exit Function

Get_Path = ""
For cmp = Len(Fname) To 1 Step -1
If Mid(Fname, cmp, 1) = "\" Then Exit For
Next cmp
Get_Path = Left(Fname, cmp)
End Function



Sub Main()
Dim Comd As Variant, Cnt As Integer
Dim bBas As Boolean
Dim StrName() As String
Dim InName As String
Dim OutName As String
Dim Cntname As Integer

Cntname = 0
Comd = GetCommandLine


If UBound(Comd) = 0 Then ReDim Comd(1): Comd(1) = ""

If Comd(1) = "" Then
Load frmMain
frmMain.Show
Else

For Cnt = 1 To UBound(Comd)
Select Case Left(UCase(Comd(Cnt)), 4)

Case Else
ReDim Preserve StrName(Cntname)
StrName(Cntname) = Comd(Cnt)
Cntname = Cntname + 1
End Select
Next Cnt
Cntname = Cntname - 1

If Cntname = -1 Then
MsgBox "Text file not found.", vbCritical, "Wrong text file name:"
        GoTo comm_err
End If

    If UBound(StrName) > 1 Then
        MsgBox "Wrong name.", vbCritical, "Command arguments error:"
        GoTo comm_err
    End If
    
InName = StrName(0)

If Cntname = 0 Then
If bBas Then
OutName = StrName(0) & ".cas"
End If
Else

If bBas Then
If InStr(1, UCase(StrName(Cntname)), ".cas") = 0 Then
OutName = StrName(Cntname) & ".cas"
Else
OutName = StrName(Cntname)
End If
End If

End If

If Dir(StrName(0)) = "" Then
        MsgBox "Text file not found.", vbCritical, "Wrong text file name:"
        GoTo comm_err
End If

gAsmCNT = 0
ASM_cnt = 0

ReDim ASM_Buff(0)
ASM_Buff(0) = 0

ReDim Asm_OFF(0)
Asm_OFF(0) = 0


ReDim ASM_lng(0)
ASM_lng(0) = 0

ReDim ASM_Add(0)
ASM_Add(0) = 0


ReDim Var_Array(0)

frmMain.MousePointer = 11
frmMain.InputTXT = InName


frmMain.Open_TextFile InName
frmMain.MousePointer = 0

Unload frmMain
End If
comm_err:
End Sub


' VB5 HELP example.
Function GetCommandLine(Optional MaxArgs)

    'D�clare les variables.
    Dim C, CmdLine, CmdLnLen, InArg, i, NumArgs, Getcar As String * 1
    'V�rifie si MaxArgs a �t� sp�cifi�.
    If IsMissing(MaxArgs) Then MaxArgs = 10
    'D�finit un tableau au format appropri�.
    ReDim ArgArray(MaxArgs)
    NumArgs = 0: InArg = False
    
       
    'R�cup�re les arguments de ligne de commande.
    CmdLine = ""
    For i = 1 To Len(Command())
    Getcar = Mid(Command(), i, 1)
    If Getcar <> Chr(34) Then CmdLine = CmdLine + Getcar Else CmdLine = CmdLine + " "
    Next
    

    CmdLnLen = Len(CmdLine)
    'Analyse de la ligne de commande caract�re
    ' par caract�re.
    For i = 1 To CmdLnLen

C = Mid(CmdLine, i, 1)
        'Analyse de caract�res d�espacement ou
        'de tabulations.
        If (C <> " " And C <> vbTab) Then
            'Ni espace ni tabulation.
            'V�rifie une �ventuelle pr�sence
            'dans l�argument.
            If Not InArg Then
            'Le nouvel argument commence.
            'V�rifie si  les arguments ne sont pas
            'trop nombreux.
                If NumArgs = MaxArgs Then Exit For
                    NumArgs = NumArgs + 1
                    InArg = True

End If
            'Ajoute un caract�re � l�argument courant.
            ArgArray(NumArgs) = ArgArray(NumArgs) + C
        Else
            'Recherche un espace ou une tabulation.
            'InArg flag prend la valeur False.
            InArg = False
        End If
    Next i
    'Redimensionne le tableau pour qu�il puisse
    'contenir les arguments.
    ReDim Preserve ArgArray(NumArgs)
    'Renvoie le tableau dans le nom de fonction.
    GetCommandLine = ArgArray()
End Function



Sub Save_textfile(Filename As String, NewFile As String)
Dim hFile As Integer, hFile2  As Integer
Dim OutLine As String
Dim ByteBuff() As Byte
Dim a
Dim bPrint
Dim bOK As Boolean
Dim bCasLST As Boolean
Dim decLST As Integer

'Open File
hFile = FreeFile
Open Filename For Binary As #hFile
ReDim ByteBuff(LOF(hFile) - 1)
Get #hFile, 1, ByteBuff
Close #hFile

bOK = True: bCasLST = False
For a = 0 To 9
If ByteBuff(a) <> &HD3 Then bOK = False
Next

If bOK Then bCasLST = True

'Not a 'Cas' file.
    If Not bOK Then
    bOK = True
    For a = UBound(ByteBuff) - 9 To UBound(ByteBuff)
    If ByteBuff(a) <> 0 Then bOK = False
    Next
    If Not bOK Then
    frmMain.Status.text = "Not a legal CAS/LST file": Reset: Exit Sub
        Else
    decLST = 0: a = -1
        Do
        a = a + 1
        Loop Until ByteBuff(a) <> 0
        decLST = a
    End If
    If bOK Then bCasLST = False
    End If

Dim Cnt As Long, TAPEName As String, TmpStr As String
TAPEName = ""
If Dir(NewFile) <> "" Then
Kill (NewFile)
End If

 hFile2 = FreeFile
Open NewFile For Output As #hFile2

If bCasLST Then
TAPEName = ""
For Cnt = 10 To 15
    If ByteBuff(Cnt) <> 0 Then TAPEName = TAPEName + Chr(ByteBuff(Cnt)) Else Exit For
Next Cnt
Else
TAPEName = ""
End If


Print #hFile2, "## X-07 BASIC FILE."
Print #hFile2, "##"
If TAPEName <> "" Then
Print #hFile2, "## NAME: "; TAPEName
Else
Print #hFile2, "## NAME: "; Getx07rName(Cut_Name(Cut_attr(NewFile)))
End If

Print #hFile2, "##"

Dim Clustoff As Integer '256 bytes per bloc.

'If (UBound(ByteBuff) - 46) > 256 Then
'For Clustoff = 1 To ((UBound(ByteBuff) - 46) \ 257)
'CopyMemory ByteBuff((Clustoff * 256) + 46), ByteBuff((Clustoff * 256) + 47), UBound(ByteBuff) - ((Clustoff * 256) + 45)
'Next
'End If

Dim OutLinei As Long

Cnt = IIf(bCasLST, 18, 2 + decLST)

Do

If Cnt >= UBound(ByteBuff) Then Exit Do
bPrint = False
OutLinei = CLng(ByteBuff(Cnt))
Cnt = Cnt + 1
OutLinei = OutLinei + Str(CLng(ByteBuff(Cnt)) * 256)
Cnt = Cnt + 1
OutLine = Str(OutLinei) & " "

    Do While Not (Format(ByteBuff(Cnt)) = 0)
    If ByteBuff(Cnt) = 58 And ByteBuff(Cnt + 1) = 142 And ByteBuff(Cnt + 2) = 255 Then
        TmpStr = "'"
        Cnt = Cnt + 2
    Else
        If bPrint Then TmpStr = "" Else TmpStr = PutFunc(ByteBuff(Cnt))
        If ByteBuff(Cnt) = 34 Then bPrint = Not bPrint

    End If
        
        If ByteBuff(Cnt - 1) <> 32 Then
        If ByteBuff(Cnt) = &HC3 Or ByteBuff(Cnt) = &HC8 Or ByteBuff(Cnt) = &HC9 Or ByteBuff(Cnt) = &HCB Then
          OutLine = OutLine + " "
        End If
        End If
          
        If TmpStr <> "" Then
            OutLine = OutLine + TmpStr
        Else

        OutLine = OutLine + GetSpChars(ByteBuff(Cnt))
           ' OutLine = OutLine + IIf(ByteBuff(Cnt) >= 128, Chr(ByteBuff(Cnt) - 128), Chr(ByteBuff(Cnt)))
        End If
        
        If Not bPrint And ByteBuff(Cnt + 1) <> 32 And ByteBuff(Cnt + 1) <> &H3A Then
        If ByteBuff(Cnt) = &HC3 Or ByteBuff(Cnt) = &HC8 Or ByteBuff(Cnt) = &HC9 Or ByteBuff(Cnt) = &HCB Then
          OutLine = OutLine + " "
        End If
        
        If ByteBuff(Cnt) = &H87 Or (ByteBuff(Cnt) > &H8A And ByteBuff(Cnt) < &H94) Or (ByteBuff(Cnt) > &H94 And ByteBuff(Cnt) < &HB3) Or (ByteBuff(Cnt) > &HB8 And ByteBuff(Cnt) < &HC1) Then
          OutLine = OutLine + " "
        End If
        End If
        

     Cnt = Cnt + 1
     
     
     
    Loop
Print #hFile2, OutLine
    
Cnt = Cnt + 3
If Cnt >= UBound(ByteBuff) - 5 Then Exit Do
OutLine = ""
Loop Until ByteBuff(Cnt - 1) = 0 And ByteBuff(Cnt) = 0 And ByteBuff(Cnt + 1) = &H0
Close #hFile2
frmMain.Status.text = "'" & NewFile & "' created." & vbCrLf:

End Sub

Private Function PutFunc(Token As Byte) As String

' Commands List.
' -------------
'

Select Case Token

 ' &H8B : RESTORE
   Case 139
        PutFunc = "RESTORE"
        Exit Function


 ' &HA5 : CONSOLE
   Case 165
        PutFunc = "CONSOLE"
        Exit Function


 ' &HC0 : STRING$
   Case 192
        PutFunc = "STRING$"
        Exit Function
        

 ' &H8D : RETURN
   Case 141
        PutFunc = "RETURN"
        Exit Function


 ' &H93 : DEFSTR
   Case 147
        PutFunc = "DEFSTR"
        Exit Function


 ' &H94 : DEFINT
   Case 148
        PutFunc = "DEFINT"
        Exit Function


 ' &H95 : DEFSNG
   Case 149
        PutFunc = "DEFSNG"
        Exit Function


 ' &H96 : DEFDBL
   Case 150
        PutFunc = "DEFDBL"
        Exit Function


 ' &H99 : RESUME
   Case 153
        PutFunc = "RESUME"
        Exit Function


 ' &H9C : LPRINT
   Case 156
        PutFunc = "LPRINT"
        Exit Function


 ' &HA4 : CIRCLE
   Case 164
        PutFunc = "CIRCLE"
        Exit Function


 ' &HA9 : LOCATE
   Case 169
        PutFunc = "LOCATE"
        Exit Function


 ' &HAB : PRESET
   Case 171
        PutFunc = "PRESET"
        Exit Function


 ' &HAF : DELETE
   Case 175
        PutFunc = "DELETE"
        Exit Function


 ' &HC2 : INKEY$
   Case 194
        PutFunc = "INKEY$"
        Exit Function


 ' &HC4 : VARPTR
   Case 196
        PutFunc = "VARPTR"
        Exit Function


 ' &HCA : START$
   Case 202
        PutFunc = "START$"
        Exit Function


 ' &HCD : SCREEN
   Case 205
        PutFunc = "SCREEN"
        Exit Function


 ' &HF9 : RIGHT$
   Case 249
        PutFunc = "RIGHT$"
        Exit Function


 ' &HFB : CSRLIN
   Case 251
        PutFunc = "CSRLIN"
        Exit Function


 ' &H84 : INPUT
   Case 132
        PutFunc = "INPUT"
        Exit Function


 ' &H8C : GOSUB
   Case 140
        PutFunc = "GOSUB"
        Exit Function


 ' &H92 : MOTOR
   Case 146
        PutFunc = "MOTOR"
        Exit Function


 ' &H98 : ERROR
   Case 152
        PutFunc = "ERROR"
        Exit Function


 ' &H9D : DEFFN
   Case 157
        PutFunc = "DEFFN"
        Exit Function


 ' &H9F : PRINT
   Case 159
        PutFunc = "PRINT"
        Exit Function


 ' &HA2 : LLIST
   Case 162
        PutFunc = "LLIST"
        Exit Function


 ' &HA3 : CLEAR
   Case 163
        PutFunc = "CLEAR"
        Exit Function


 ' &HA7 : COLOR
   Case 167
        PutFunc = "COLOR"
        Exit Function


 ' &HAD : SLEEP
   Case 173
        PutFunc = "SLEEP"
        Exit Function


 ' &HB1 : PAINT
   Case 177
        PutFunc = "PAINT"
        Exit Function


 ' &HB5 : ERASE
   Case 181
        PutFunc = "ERASE"
        Exit Function


 ' &HB7 : CLOAD
   Case 183
        PutFunc = "CLOAD"
        Exit Function


 ' &HB8 : CSAVE
   Case 184
        PutFunc = "CSAVE"
        Exit Function


 ' &HBD : USING
   Case 189
        PutFunc = "USING"
        Exit Function


 ' &HC1 : INSTR
   Case 193
        PutFunc = "INSTR"
        Exit Function


 ' &HC8 : DATE$
   Case 200
        PutFunc = "DATE$"
        Exit Function


 ' &HC9 : TIME$
   Case 201
        PutFunc = "TIME$"
        Exit Function


 ' &HCB : FONT$
   Case 203
        PutFunc = "FONT$"
        Exit Function


 ' &HF8 : LEFT$
   Case 248
        PutFunc = "LEFT$"
        Exit Function


 ' &HFC : STICK
   Case 252
        PutFunc = "STICK"
        Exit Function


 ' &HFD : STRIG
   Case 253
        PutFunc = "STRIG"
        Exit Function


 ' &HFE : POINT
   Case 254
        PutFunc = "POINT"
        Exit Function


 ' &H82 : NEXT
   Case 130
        PutFunc = "NEXT"
        Exit Function


 ' &H83 : DATA
   Case 131
        PutFunc = "DATA"
        Exit Function


 ' &H86 : READ
   Case 134
        PutFunc = "READ"
        Exit Function


 ' &H88 : GOTO
   Case 136
        PutFunc = "GOTO"
        Exit Function


 ' &H8F : STOP
   Case 143
        PutFunc = "STOP"
        Exit Function


 ' &H90 : ELSE
   Case 144
        PutFunc = "ELSE"
        Exit Function


 ' &H97 : LINE
   Case 151
        PutFunc = "LINE"
        Exit Function


 ' &H9E : POKE
   Case 158
        PutFunc = "POKE"
        Exit Function


 ' &HA0 : CONT
   Case 160
        PutFunc = "CONT"
        Exit Function


 ' &HA1 : LIST
   Case 161
        PutFunc = "LIST"
        Exit Function


 ' &HA8 : EXEC
   Case 168
        PutFunc = "EXEC"
        Exit Function


 ' &HAA : PSET
   Case 170
        PutFunc = "PSET"
        Exit Function


 ' &HB0 : FSET
   Case 176
        PutFunc = "FSET"
        Exit Function


 ' &HB2 : LOAD
   Case 178
        PutFunc = "LOAD"
        Exit Function


 ' &HB3 : SAVE
   Case 179
        PutFunc = "SAVE"
        Exit Function


 ' &HB4 : INIT
   Case 180
        PutFunc = "INIT"
        Exit Function


 ' &HB6 : BEEP
   Case 182
        PutFunc = "BEEP"
        Exit Function


 ' &HBA : TAB(
   Case 186
        PutFunc = "TAB("
        Exit Function


 ' &HC7 : ALM$
   Case 199
        PutFunc = "ALM$"
        Exit Function


 ' &HCC : KEY$
   Case 204
        PutFunc = "KEY$"
        Exit Function


 ' &HCE : THEN
   Case 206
        PutFunc = "THEN"
        Exit Function


 ' &HD0 : STEP
   Case 208
        PutFunc = "STEP"
        Exit Function


 ' &HEC : PEEK
   Case 236
        PutFunc = "PEEK"
        Exit Function


 ' &HED : CINT
   Case 237
        PutFunc = "CINT"
        Exit Function


 ' &HEE : CSNG
   Case 238
        PutFunc = "CSNG"
        Exit Function


 ' &HEF : CDBL
   Case 239
        PutFunc = "CDBL"
        Exit Function


 ' &HF2 : HEX$
   Case 242
        PutFunc = "HEX$"
        Exit Function


 ' &HF3 : STR$
   Case 243
        PutFunc = "STR$"
        Exit Function


 ' &HF6 : CHR$
   Case 246
        PutFunc = "CHR$"
        Exit Function


 ' &HF7 : TKEY
   Case 247
        PutFunc = "TKEY"
        Exit Function


 ' &HFA : MID$
   Case 250
        PutFunc = "MID$"
        Exit Function


 ' &H80 : END
   Case 128
        PutFunc = "END"
        Exit Function


 ' &H81 : FOR
   Case 129
        PutFunc = "FOR"
        Exit Function


 ' &H85 : DIM
   Case 133
        PutFunc = "DIM"
        Exit Function


 ' &H87 : LET
   Case 135
        PutFunc = "LET"
        Exit Function


 ' &H89 : RUN
   Case 137
        PutFunc = "RUN"
        Exit Function


 ' &H8E : REM
   Case 142
        PutFunc = "REM"
        Exit Function


 ' &H9A : OUT
   Case 154
        PutFunc = "OUT"
        Exit Function


 ' &HA6 : CLS
   Case 166
        PutFunc = "CLS"
        Exit Function


 ' &HAC : OFF
   Case 172
        PutFunc = "OFF"
        Exit Function


 ' &HAE : DIR
   Case 174
        PutFunc = "DIR"
        Exit Function


 ' &HB9 : NEW
   Case 185
        PutFunc = "NEW"
        Exit Function


 ' &HBE : ERL
   Case 190
        PutFunc = "ERL"
        Exit Function


 ' &HBF : ERR
   Case 191
        PutFunc = "ERR"
        Exit Function


 ' &HC3 : INP
   Case 195
        PutFunc = "INP"
        Exit Function


 ' &HC5 : USR
   Case 197
        PutFunc = "USR"
        Exit Function


 ' &HC6 : SNS
   Case 198
        PutFunc = "SNS"
        Exit Function


 ' &HCF : NOT
   Case 207
        PutFunc = "NOT"
        Exit Function


 ' &HD6 : AND
   Case 214
        PutFunc = "AND"
        Exit Function


 ' &HD8 : XOR
   Case 216
        PutFunc = "XOR"
        Exit Function


 ' &HD9 : EQV
   Case 217
        PutFunc = "EQV"
        Exit Function


 ' &HDA : MOD
   Case 218
        PutFunc = "MOD"
        Exit Function


 ' &HDF : SGN
   Case 223
        PutFunc = "SGN"
        Exit Function


 ' &HE0 : INT
   Case 224
        PutFunc = "INT"
        Exit Function


 ' &HE1 : ABS
   Case 225
        PutFunc = "ABS"
        Exit Function


 ' &HE2 : FRE
   Case 226
        PutFunc = "FRE"
        Exit Function


 ' &HE3 : POS
   Case 227
        PutFunc = "POS"
        Exit Function


 ' &HE4 : SQR
   Case 228
        PutFunc = "SQR"
        Exit Function


 ' &HE5 : RND
   Case 229
        PutFunc = "RND"
        Exit Function


 ' &HE6 : LOG
   Case 230
        PutFunc = "LOG"
        Exit Function


 ' &HE7 : EXP
   Case 231
        PutFunc = "EXP"
        Exit Function


 ' &HE8 : COS
   Case 232
        PutFunc = "COS"
        Exit Function


 ' &HE9 : SIN
   Case 233
        PutFunc = "SIN"
        Exit Function


 ' &HEA : TAN
   Case 234
        PutFunc = "TAN"
        Exit Function


 ' &HEB : ATN
   Case 235
        PutFunc = "ATN"
        Exit Function


 ' &HF0 : FIX
   Case 240
        PutFunc = "FIX"
        Exit Function


 ' &HF1 : LEN
   Case 241
        PutFunc = "LEN"
        Exit Function


 ' &HF4 : VAL
   Case 244
        PutFunc = "VAL"
        Exit Function


 ' &HF5 : ASC
   Case 245
        PutFunc = "ASC"
        Exit Function


 ' &H8A : IF
   Case 138
        PutFunc = "IF"
        Exit Function


 ' &H91 : TR
   Case 145
        PutFunc = "TR"
        Exit Function


 ' &H9B : ON
   Case 155
        PutFunc = "ON"
        Exit Function


 ' &HBB : TO
   Case 187
        PutFunc = "TO"
        Exit Function


 ' &HBC : FN
   Case 188
        PutFunc = "FN"
        Exit Function


 ' &HD7 : OR
   Case 215
        PutFunc = "OR"
        Exit Function


 ' &HD1 : +
   Case 209
        PutFunc = "+"
        Exit Function


 ' &HD2 : -
   Case 210
        PutFunc = "-"
        Exit Function


 ' &HD3 : *
   Case 211
        PutFunc = "*"
        Exit Function


 ' &HD4 : /
   Case 212
        PutFunc = "/"
        Exit Function


 ' &HD5 : ^
   Case 213
        PutFunc = "^"
        Exit Function


 ' &HDB : \
   Case 219
        PutFunc = "\"
        Exit Function


 ' &HDC : >
   Case 220
        PutFunc = ">"
        Exit Function


 ' &HDD : =
   Case 221
        PutFunc = "="
        Exit Function


 ' &HDE : <
   Case 222
        PutFunc = "<"
        Exit Function


Case Else
    PutFunc = ""
End Select

End Function

Function GetSpChars(Spchar As Byte) As String
' ASCII X07 to Ascii PC
Select Case Spchar
Case 134
GetSpChars = Chr(&HC4)
Case 135
GetSpChars = Chr(&HC5)
Case 136
GetSpChars = Chr(&HE4)
Case 137
GetSpChars = Chr(&HE0)
Case 138
GetSpChars = Chr(&HE2)
Case 139
GetSpChars = Chr(&HE1)
Case 140
GetSpChars = Chr(&HE5)
Case 141
GetSpChars = Chr(&H61)
Case 142
GetSpChars = Chr(&HCF)
Case 143
GetSpChars = Chr(&HEF)
Case 144
GetSpChars = Chr(&HEC)
Case 145
GetSpChars = Chr(&HEE)
Case 146
GetSpChars = Chr(&HED)
Case 147
GetSpChars = Chr(&HDC)
Case 148
GetSpChars = Chr(&HFC)
Case 149
GetSpChars = Chr(&HF9)
Case 150
GetSpChars = Chr(&HFB)
Case 151
GetSpChars = Chr(&HFA)
Case 152
GetSpChars = Chr(&HC9)
Case 153
GetSpChars = Chr(&HEB)
Case 154
GetSpChars = Chr(&HE8)
Case 155
GetSpChars = Chr(&HEA)
Case 156
GetSpChars = Chr(&HE9)
Case 157
GetSpChars = Chr(&HF6)
Case 224
GetSpChars = Chr(&HF4)
Case 225
GetSpChars = Chr(&HF3)
Case 226
GetSpChars = Chr(&H6F)
Case 227
GetSpChars = Chr(&HFF)
Case 228
GetSpChars = Chr(&HC7)
Case 229
GetSpChars = Chr(&HE7)
Case 230
GetSpChars = Chr(&HD1)
Case 231
GetSpChars = Chr(&HF1)
Case 92
GetSpChars = Chr(&HA5)
Case 253 ' �
GetSpChars = Chr(&HA3)
Case 92 ' Yen
GetSpChars = Chr(&HA5)
Case Else
If Spchar > &H7E Then GetSpChars = "�" & Hex8(CLng(Spchar)) Else GetSpChars = Chr(Spchar)
End Select
End Function
Function PutSpChars(Spchar As Byte) As String
' Ascii PC to ASCII X07
Select Case Spchar
Case &HC4
PutSpChars = Chr(134)
Case &HC5
PutSpChars = Chr(135)
Case &HE4
PutSpChars = Chr(136)
Case &HE0
PutSpChars = Chr(137)
Case &HE2
PutSpChars = Chr(138)
Case &HE1
PutSpChars = Chr(139)
Case &HE5
PutSpChars = Chr(140)
'Case &H61
'PutSpChars = Chr(141)
Case &HCF
PutSpChars = Chr(142)
Case &HEF
PutSpChars = Chr(143)
Case &HEC
PutSpChars = Chr(144)
Case &HEE
PutSpChars = Chr(145)
Case &HED
PutSpChars = Chr(146)
Case &HDC
PutSpChars = Chr(147)
Case &HFC
PutSpChars = Chr(148)
Case &HF9
PutSpChars = Chr(149)
Case &HFB
PutSpChars = Chr(150)
Case &HFA
PutSpChars = Chr(151)
Case &HC9
PutSpChars = Chr(152)
Case &HEB
PutSpChars = Chr(153)
Case &HE8
PutSpChars = Chr(154)
Case &HEA
PutSpChars = Chr(155)
Case &HE9
PutSpChars = Chr(156)
Case &HF6
PutSpChars = Chr(157)
Case &HF4
PutSpChars = Chr(224)
Case &HF3
PutSpChars = Chr(225)
'Case &H6F
'PutSpChars = Chr(226)
Case &HFF
PutSpChars = Chr(227)
Case &HC7
PutSpChars = Chr(228)
Case &HE7
PutSpChars = Chr(229)
Case &HD1
PutSpChars = Chr(230)
Case &HF1
PutSpChars = Chr(231)
Case &HA3 ' �
PutSpChars = Chr(253)
Case &HA5, &H5C ' Yen
PutSpChars = Chr(92)
Case Else
 PutSpChars = Chr(Spchar)
End Select
End Function

Function GraphKey(Key As String) As Byte

Dim Ret As Byte


Key = UCase(Left(Key, 1))

Select Case Key
      Case "1"
        Ret = 233
      Case "2"
        Ret = 144
      Case "3"
        Ret = 145
      Case "4"
        Ret = 146
      Case "5"
        Ret = 147
      Case "6"
        Ret = 236
      Case "7"
        Ret = 224
      Case "8"
        Ret = 242
      Case "9"
        Ret = 241
      Case "0"
        Ret = 138
      Case "-"
        Ret = 240
      Case "^"
        Ret = 252
      Case "Q"
        Ret = 139
      Case "W"
        Ret = 251
      Case "E"
        Ret = 143
      Case "R"
        Ret = 246
      Case "T"
        Ret = 151
      Case "Y"
        Ret = 150
      Case "U"
        Ret = 148
      Case "I"
        Ret = 249
      Case "O"
        Ret = 158
      Case "P"
        Ret = 247
      Case "@"
        Ret = 251
      Case "["
        Ret = 132
      Case "A"
        Ret = 136
      Case "S"
        Ret = 159
      Case "D"
        Ret = 239
      Case "F"
        Ret = 253
      Case "G"
        Ret = 157
      Case "H"
        Ret = 254
      Case "J"
        Ret = 229
      Case "K"
        Ret = 155
      Case "L"
        Ret = 244
      Case ";"
        Ret = 130
      Case ":"
        Ret = 129
      Case "]"
        Ret = 133
      Case "Z"
        Ret = 225
      Case "X"
        Ret = 152
      Case "C"
        Ret = 228
      Case "V"
        Ret = 149
      Case "B"
        Ret = 237
      Case "N"
        Ret = 137
      Case "M"
        Ret = 245
      Case ","
        Ret = 156
      Case "."
        Ret = 154
      Case "/"
        Ret = 128
      Case "?"
        Ret = 131
      End Select
      GraphKey = Ret
End Function




