<#
.SYNOPSIS
    Computes the points of Delahaye's Oiseau-Poisson and generates
    the M/D command sequence for the Canon X‑710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program from the book:
        "Dessins géométriques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined figure parameters,
      - computes the star coordinates (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, K, H, R, etc.) are defined internally.

.NOTES
    Author   : VincentD
    Project  : Canon X‑07 / X‑710 reconstruction and preservation
    File     : Generate-X710_Stars.ps1
#>



# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------
$NP = 480

# --------------------------------------------------------------------
# DATA
# --------------------------------------------------------------------
$commands = @(
    "M 0,0",
    "D 2,0, 4,1, 4,2, 3,2, 2,3, 4,5, 4,6, 2,5, 2,6, -1,5, -2,3",
    "D -1,2, -2,2, -3,3, -4,3, -5,2, -4,2, 0,0",
    "M -5,2",
    "D -5,1, -7,-1, -6,-2, -5,-2, -5,-3, -2,-2, -2,-3, 0,-2",
    "D 1,-1, 2,-1, 3,-2, 4,-2, 3,-1, 4,1",
    "M 2,5",
    "D 0,4, 0,2",
    "M -2,1",
    "D -5,1, -4,-1, -3,0, -3,-1, -4,-1, -5,-2, 0,-2",
    "M -7,-1",
    "D -6,-1",
    "M -4,2.4",
    "D -4,2.7, -4.3,2.7, -4.3,2.4, -4,2.4"
    "M -5,0",
    "D -5.5,0, -5.5,0.5, -5,0.5, -5,0"
)

# Old Data - y=y-0.1 line 1070 of basic programme (adjust bird eye)
#    "M -4,2.5",
#    "D -4,2.8, -4.3,2.8, -4.3,2.5, -4,2.5",


# --------------------------------------------------------------------
# Compute Oiseau-Poisson points
# --------------------------------------------------------------------

function Transform-46 {
    param(
        [string[]]$commands,
        [scriptblock]$transformX = { param($A) [int]($NP * ($A + 10) / 15) },
        [scriptblock]$transformY = { param($B) [int]($NP * ($B + 10) / 15) }
    )
    
    $transformedCommands = @()
    
    foreach ($cmd in $commands) {
        if ([string]::IsNullOrWhiteSpace($cmd)) { continue }
        
        $parts = $cmd -split '\s+', 2
        $commandType = $parts[0]  # M ou D
        $coordsString = $parts[1]
        
        # Parser les coordonnées
        $coordPairs = $coordsString -split ',\s*'
        $transformedCoords = @()
        
        for ($i = 0; $i -lt $coordPairs.Count; $i += 2) {
            if ($i + 1 -lt $coordPairs.Count) {
                $x = [double]$coordPairs[$i]
                $y = [double]$coordPairs[$i + 1]
                
                # Appliquer la transformation
                $newX = & $transformX $x
                $newY = & $transformY $y
                
                $transformedCoords += "$newX,$newY"
            }
        }
        
        # Reconstruire la commande
        $newCmd = "$commandType " + ($transformedCoords -join ", ")
        $transformedCommands += $newCmd
    }
    
    return $transformedCommands
}


# --------------------------------------------------------------------
# Compute x16 time
# --------------------------------------------------------------------

function Transform-47 {
    param(
        [string[]]$commands
    )
    
    $transformedCommands = @()
    
    # Boucles imbriquées I=1 to 4, J=1 to 4
    for ($I = 1; $I -le 4; $I++) {
        for ($J = 1; $J -le 4; $J++) {
            foreach ($cmd in $commands) {
                if ([string]::IsNullOrWhiteSpace($cmd)) { continue }
                
                $parts = $cmd -split '\s+', 2
                $commandType = $parts[0]  # M ou D
                $coordsString = $parts[1]
                
                # Parser les coordonnées
                $coordPairs = $coordsString -split ',\s*'
                $transformedCoords = @()
                
                for ($idx = 0; $idx -lt $coordPairs.Count; $idx += 2) {
                    if ($idx + 1 -lt $coordPairs.Count) {
                        $A = [double]$coordPairs[$idx]
                        $B = [double]$coordPairs[$idx + 1]
                        
                        $newX = [int]($NP * ($B + 4*$I + 4*$J) / 45)
                        $newY = [int]($NP * ($A + 15 - 5*$I + 9*$J) / 45)
                        
                        $transformedCoords += "$newX,$newY"
                    }
                }
                
                # Reconstruire la commande
                $newCmd = "$commandType " + ($transformedCoords -join ", ")
                $transformedCommands += $newCmd
            }
        }
    }
    
    return $transformedCommands
}

# --------------------------------------------------------------------
# Choose by comment
# --------------------------------------------------------------------

#$result = Transform-46 -commands $commands
$result = Transform-47 -commands $commands

# --------------------------------------------------------------------
# Show results
# --------------------------------------------------------------------
$result | ForEach-Object { Write-Host $_ }

# --------------------------------------------------------------------
# Build .plt
# --------------------------------------------------------------------
# TODO


# -----[eos]----------------------------------------------------------