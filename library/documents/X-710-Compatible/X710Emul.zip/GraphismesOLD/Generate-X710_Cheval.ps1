<#
.SYNOPSIS
    Computes the points of Delahaye's Oiseau-Poisson and generates
    the M/D command sequence for the Canon X‑710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program from the book:
        "Dessins géométriques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined figure parameters,
      - computes the star coordinates (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, K, H, R, etc.) are defined internally.

.NOTES
    Author   : VincentD
    Project  : Canon X‑07 / X‑710 reconstruction and preservation
    File     : Generate-X710_Stars.ps1
#>



# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------
$NP = 480
$PI = [math]::Atan(1) * 4

# --------------------------------------------------------------------
# DATA
# --------------------------------------------------------------------
$commands = @(
    "M 10,10"
    "D 8,12, 9,16, 12,17, 13,18, 14,20"
    "M 13,18"
    "D 12,19, 9,21, 9,20, 10,19, 9,17, 7,20, 8,22, 12,22"
    "M 12,20"
    "D 12,22, 13,26, 16,31, 18,31, 19,32"
    "M 16,31"
    "D 14,31, 14,32"
    "M 14,31"
    "D 10,30, 12,31, 10,32, 10,34, 11,34, 11,33, 10,33"
    "M 12,32"
    "D 13,31"
    "M 10,34"
    "D 16,36"
    "M 16,35"
    "D 16,37, 18,35, 17,34"
    "M 17,36"
    "D 20,36, 22,32, 19,26"
    "M 20,36"
    "D 22,36, 22,34, 24,32, 24,30, 19,26, 18,23, 21,22, 21,24"
    "D 30,30, 34,31, 36,31, 33,26, 32,22, 28,22, 27,20, 29,17, 30,19, 29,20"
    "D 29,21, 32,19, 33,18, 32,17, 29,16, 28,12, 30,10, 21,4, 21,2 "
    "D 18,3, 19,6, 24,10, 24,12, 22,14, 22,16, 23,17"
    "M 22,16"
    "D 17,16, 16,17, 17,18"
    "M 16,17"
    "D 16,16, 10,14, 10,12, 12,11, 10,10"
    "M 21,21"
    "D 22,24, 30,30"
    "M 24,24"
    "D 34,28"
    "M 25,23"
    "D 33,26"
    "M 25,21"
    "D 27,20"
    "M 23,21"
    "D 24,19"
    "M 27,20"
    "D 22,19, 22,21"
    "M 22,19"
    "D 21,20"
    "M 13,34"
    "D 15,35, 16,34, 16,33"
    "M 15,35"
    "D 15,34, 16,34, 15,34, 15,35"
    "M 24,12"
    "D 26,10, 19,5, 19,3"
    "M 28,22"
    "D 25,22"
)


# --------------------------------------------------------------------
# Compute Cheval
# --------------------------------------------------------------------

function Dessin-34 {
    param(
        [string[]]$commands,
        [scriptblock]$transformX = { param($A) [int]($NP * ($A / 40) ) },
        [scriptblock]$transformY = { param($B) [int]($NP * ($B / 40) ) }
    )
    
    $transformedCommands = @()
    
    foreach ($cmd in $commands) {
        if ([string]::IsNullOrWhiteSpace($cmd)) { continue }
        
        $parts = $cmd -split '\s+', 2
        $commandType = $parts[0]  # M ou D
        $coordsString = $parts[1]
        
        # Parser les coordonnées
        $coordPairs = $coordsString -split ',\s*'
        $transformedCoords = @()
        
        for ($i = 0; $i -lt $coordPairs.Count; $i += 2) {
            if ($i + 1 -lt $coordPairs.Count) {
                $x = [double]$coordPairs[$i]
                $y = [double]$coordPairs[$i + 1]
                
                # Appliquer la transformation
                $newX = & $transformX $x
                $newY = & $transformY $y
                
                $transformedCoords += "$newX,$newY"
            }
        }
        
        # Reconstruire la commande
        $newCmd = "$commandType " + ($transformedCoords -join ", ")
        $transformedCommands += $newCmd
    }
    
    return $transformedCommands
}




# --------------------------------------------------------------------
# Choose by comment
# --------------------------------------------------------------------

$result = Dessin-34 -commands $commands

# --------------------------------------------------------------------
# Show results
# --------------------------------------------------------------------
$result | ForEach-Object { Write-Host $_ }

# --------------------------------------------------------------------
# Build .plt
# --------------------------------------------------------------------
# TODO


# -----[eos]----------------------------------------------------------