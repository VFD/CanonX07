/**
 * ------------------------------------------------------------
 *  Project : X Printer simulator
 *  File    : XPrinter.js
 *  Author  : VincentD
 *  Date    : 2026-04-07
 *  License : CC BY-NC 4.0 International
 * ------------------------------------------------------------
 *  Description:
 *		- X Printer simulator (standard commands only)
 *
 *  Notes:
 *		- ...
 *		- Work in progress
 * ------------------------------------------------------------
 */

(function () {

	let serialPort = null;
	let reader = null;
	let isConnected = false;

	// --------------------------------------------------
	// Save to file function
	// --------------------------------------------------
	function saveToFile() {
		const printName = document.getElementById('printName').value;
		const printArea = document.getElementById('printArea').value;
		const fileName = printName + '.txt';

		// Create a blob with the content
		const blob = new Blob([printArea], { type: 'text/plain;charset=utf-8' });

		// Create a temporary URL
		const url = URL.createObjectURL(blob);

		// Create a download link and trigger it
		const link = document.createElement('a');
		link.href = url;
		link.download = fileName;
		document.body.appendChild(link);
		link.click();

		// Cleanup
		document.body.removeChild(link);
		URL.revokeObjectURL(url);
	}

	// --------------------------------------------------
	// Scan available COM ports
	// --------------------------------------------------
	async function scanComPorts() {
		const comPortSelect = document.getElementById('comPort');
		
		// Clear existing options except the first one
		while (comPortSelect.options.length > 1) {
			comPortSelect.remove(1);
		}
		
		try {
			// Get available serial ports
			const ports = await navigator.serial.getPorts();
			
			if (ports.length === 0) {
				const option = document.createElement('option');
				option.value = '';
				option.textContent = '-- No ports available --';
				comPortSelect.appendChild(option);
				return;
			}
			
			// Add each available port
			ports.forEach((port, index) => {
				const portInfo = port.getInfo();
				const portName = `COM${index + 1}`;
				
				const option = document.createElement('option');
				option.value = index;
				option.textContent = portName;
				option.dataset.port = JSON.stringify(port);
				comPortSelect.appendChild(option);
			});
			
		} catch (error) {
			console.error('Error scanning COM ports:', error);
			const option = document.createElement('option');
			option.value = '';
			option.textContent = '-- Error scanning ports --';
			comPortSelect.appendChild(option);
		}
	}

	// --------------------------------------------------
	// Connect to COM port
	// --------------------------------------------------
	async function connectComPort() {
		try {
			const comPortSelect = document.getElementById('comPort');
			const selectedIndex = comPortSelect.value;
			
			if (selectedIndex === '') {
				alert('Please select a COM port');
				return;
			}
			
			// Get available ports and select the one
			const ports = await navigator.serial.getPorts();
			serialPort = ports[selectedIndex];
			
			// Get configuration values
			const baudRate = parseInt(document.getElementById('baudRate').value);
			const dataBits = parseInt(document.getElementById('dataBits').value);
			const stopBits = parseFloat(document.getElementById('stopBits').value);
			const parity = document.getElementById('parity').value;
			const dtrEnable = document.getElementById('dtrEnable').checked;
			const rtsEnable = document.getElementById('rtsEnable').checked;
			
			// Open the port
			await serialPort.open({
				baudRate: baudRate,
				dataBits: dataBits,
				stopBits: stopBits,
				parity: parity,
				flowControl: 'none',
				bufferSize: 255
			});
			
			// Set control signals
			if (dtrEnable) {
				await serialPort.setSignals({ dataTerminalReady: true });
			}
			if (rtsEnable) {
				await serialPort.setSignals({ requestToSend: true });
			}
			
			isConnected = true;
			updateConnectionStatus('Connected', true);
			document.getElementById('btnConnect').disabled = true;
			document.getElementById('btnDisconnect').disabled = false;
			document.getElementById('comPort').disabled = true;
			
			// Start reading data
			readSerialData();
			
		} catch (error) {
			console.error('Error connecting to COM port:', error);
			updateConnectionStatus('Connection failed: ' + error.message, false);
		}
	}

	// --------------------------------------------------
	// Disconnect from COM port
	// --------------------------------------------------
	async function disconnectComPort() {
		try {
			if (serialPort && serialPort.readable) {
				await serialPort.close();
			}
			
			isConnected = false;
			serialPort = null;
			reader = null;
			
			updateConnectionStatus('Disconnected', false);
			document.getElementById('btnConnect').disabled = false;
			document.getElementById('btnDisconnect').disabled = true;
			document.getElementById('comPort').disabled = false;
			
		} catch (error) {
			console.error('Error disconnecting from COM port:', error);
			updateConnectionStatus('Disconnection error: ' + error.message, false);
		}
	}

	// --------------------------------------------------
	// Read data from serial port
	// --------------------------------------------------
	async function readSerialData() {
		try {
			const printArea = document.getElementById('printArea');
			reader = serialPort.readable.getReader();
			
			while (isConnected) {
				const { value, done } = await reader.read();
				
				if (done) {
					break;
				}
				
				// Convert bytes to ASCII characters and handle line breaks
				if (value) {
					let text = '';
					for (let i = 0; i < value.length; i++) {
						const byte = value[i];
						
						// Handle CR (Carriage Return - 13) and LF (Line Feed - 10)
						if (byte === 13) {
							text += '\r';
						} else if (byte === 10) {
							text += '\n';
						} else {
							// Convert other bytes to ASCII characters
							text += String.fromCharCode(byte);
						}
					}
					
					printArea.value += text;
				}
			}
			
		} catch (error) {
			if (error.name !== 'AbortError') {
				console.error('Error reading serial data:', error);
				updateConnectionStatus('Read error: ' + error.message, false);
			}
		} finally {
			if (reader) {
				reader.releaseLock();
			}
		}
	}

	// --------------------------------------------------
	// Update connection status display
	// --------------------------------------------------
	function updateConnectionStatus(message, connected) {
		const statusDiv = document.getElementById('connectionStatus');
		const statusText = document.getElementById('statusText');
		
		statusDiv.style.display = 'block';
		statusText.textContent = message;
		statusDiv.style.borderColor = connected ? '#00aa00' : '#aa0000';
		statusDiv.style.backgroundColor = connected ? '#f0fff0' : '#fff0f0';
	}

	// --------------------------------------------------
	// After load run
	// --------------------------------------------------
	window.addEventListener('DOMContentLoaded', () => {
		// Scan ports on page load
		scanComPorts();
		
		// Add event listener for save button
		const btnSaveCommands = document.getElementById('btnSaveCommands');
		btnSaveCommands.addEventListener('click', saveToFile);
		
		// Add event listener for refresh ports button
		const btnRefreshPorts = document.getElementById('btnRefreshPorts');
		if (btnRefreshPorts) {
			btnRefreshPorts.addEventListener('click', scanComPorts);
		}
		
		// Add event listeners for connect/disconnect buttons
		const btnConnect = document.getElementById('btnConnect');
		const btnDisconnect = document.getElementById('btnDisconnect');
		
		if (btnConnect) {
			btnConnect.addEventListener('click', connectComPort);
		}
		if (btnDisconnect) {
			btnDisconnect.addEventListener('click', disconnectComPort);
		}
	});

})();

// -------------------- EOF --------------------