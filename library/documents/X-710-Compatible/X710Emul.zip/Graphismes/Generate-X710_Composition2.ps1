﻿<#
.SYNOPSIS
    Computes the points of Delahaye's REGULAR STARS and generates
    the M/D command sequence for the Canon X‑710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program "ETOILES REGULIERES"
    from the book:
        "Dessins géométriques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined figure parameters,
      - computes the star coordinates (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, K, H, R, etc.) are defined internally.

.NOTES
    Author   : VincentD
    Project  : Canon X‑07 / X‑710 reconstruction and preservation
    File     : Generate-X710_Stars.ps1
#>

# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------

$NP = 480
$PI = [math]::Atan(1) * 4
$DX = $NP / 2
$DY = $NP / 2

$Author = "Delahaye"
$Year = "1985"
$Title = "Composition 2"

# --------------------------------------------------------------------
# Select the figure to generate
# --------------------------------------------------------------------
# Change this line to select another figure

$Name = "Figure 25"

# --------------------------------------------------------------------
# Predefined figures
# --------------------------------------------------------------------

$Figures = @{
    "Figure 20" = @{ N=32;  K1=8;   K=16;  H=5;   R1=0.36;  R=0.14;  RR=0.9;    A1=0;  AD=0 }
    "Figure 21" = @{ N=30;  K1=10;  K=8;   H=3;   R1=0.35;  R=0.15;  RR=0.85;   A1=0;  AD=0 }
    "Figure 22" = @{ N=10;  K1=10;  K=18;  H=7;   R1=0.0;   R=0.5;   RR=0.80;   A1=0;  AD=0 }
    "Figure 23" = @{ N=10;  K1=10;  K=21;  H=10;  R1=0.0;   R=0.5;   RR=0.75;   A1=0;  AD=0 }
    "Figure 24" = @{ N=56;  K1=28;  K=7;   H=3;   R1=0.15;  R=0.35;  RR=0.95;   A1=0;  AD=0 }
    "Figure 25" = @{ N=60;  K1=20;  K=8;   H=1;   R1=0.05;  R=0.45;  RR=0.945;  A1=0;  AD=0 }
}



$Params = $Figures[$Name]

$N  = $Params.N
$K1  = $Params.K1
$K  = $Params.K
$H  = $Params.H
$R1 = $NP * $Params.R1
$R  = $NP * $Params.R
$RR = $Params.RR
$A1 = $Params.A1
$AD = $Params.AD

# --------------------------------------------------------------------
# Compute points
# --------------------------------------------------------------------

$points = @()


for ($i1 = 0; $i1 -le $N ; $i1++) {

    $R2 = $R1 * [Math]::Pow($RR, $i1)
    $R3 = $R *  [Math]::Pow($RR, $i1)

    $angle = (2 * $PI * $i1 / $K1) + $A1
    
    $CX = $DX + $R2 * [math]::Cos($angle)
    $CY = $DY + $R2 * [math]::Sin($angle)

	for ($i = 0; $i -le $K; $i++) {

		$angle = (2 * $i * $H * $PI / $K) + $AD

		$x = [math]::Floor($CX + $R3 * [math]::Cos($angle))
		$y = [math]::Floor($CY + $R3 * [math]::Sin($angle))

		$points += [PSCustomObject]@{
			I = $i
			X = $x
			Y = $y
		}
	}
}

# --------------------------------------------------------------------
# Display point table
# --------------------------------------------------------------------

$points | Format-Table -AutoSize

# --------------------------------------------------------------------
# Generate X‑710 sequence (console output)
# --------------------------------------------------------------------

Write-Host "`n--- Canon X-710 Sequence ---`n"

Write-Host "; $Title"
Write-Host "; $Author"
Write-Host "; $Year"
Write-Host ";"
Write-Host "; $Name"
Write-Host ";"
Write-Host 'CHR$(18)'
Write-Host "M0,-500"
Write-Host "I"

for ($i = 0; $i -lt $points.Count; $i++) {
    $p = $points[$i]
    if ($i -eq 0) {
        Write-Host ("M{0},{1}" -f $p.X, $p.Y)
    } else {
        Write-Host ("D{0},{1}" -f $p.X, $p.Y)
    }
}

Write-Host ";"
Write-Host "; end"

# --------------------------------------------------------------------
# Export to .plt file
# --------------------------------------------------------------------

$FileName = ($Name.Replace(" ", "-")) + ".plt"
$Lines = @()

$Lines += "; $Title"
$Lines += "; $Author"
$Lines += "; $Year"
$Lines += ";"
$Lines += "; $Name"
$Lines += ";"
$Lines += 'CHR$(18)'
$Lines += "M0,-500"
$Lines += "I"

foreach ($p in $points) {
    if ($p.I -eq 0) {
        $Lines += "M$($p.X),$($p.Y)"
    } else {
        $Lines += "D$($p.X),$($p.Y)"
    }
}

$Lines += ";"
$Lines += "; end"

$Lines | Set-Content -Encoding ASCII $FileName

Write-Host "`nFile generated: $FileName"

$nombre = $N * $K
Write-Host "Compute $nombre pts"

# -----[EOS]----------------------------------------------------------