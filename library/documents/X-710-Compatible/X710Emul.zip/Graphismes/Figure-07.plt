; Star Graphic
; Delahaye
;
; Figure 7
;
CHR$(18)
M0,-500
I
M240,456
D366,65
D34,306
D445,306
D113,65
D239,456
;
; end
