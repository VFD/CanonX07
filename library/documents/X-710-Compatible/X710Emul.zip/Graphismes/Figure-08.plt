; Star Graphic
; Delahaye
;
; Figure 8
;
CHR$(18)
M0,-500
I
M240,456
D146,45
D408,374
D29,191
D450,191
D71,374
D333,45
D239,456
;
; end
