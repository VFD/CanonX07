; Regular Polygons
; Figure 2
; 1985
;
; Figure 2
;
CHR$(18)
M0,-500
I
M456,240
D132,427
D131,52
D456,240
;
; end
