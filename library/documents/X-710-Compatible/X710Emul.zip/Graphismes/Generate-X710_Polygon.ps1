﻿<#
.SYNOPSIS
    Computes the points of Delahaye's REGULAR POLYGON and generates
    the M/D command sequence for the Canon X‑710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program "POLYGONES"
    from the book:
        "Dessins géométriques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined figure parameters,
      - computes the polygon vertices (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, K, AD, R, etc.) are defined internally.

.NOTES
    Author   : VincentD
    Project  : Canon X‑07 / X‑710 reconstruction and preservation
    File     : Generate-X710_Polygon.ps1
#>

# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------

$NP = 480
$PI = [math]::Atan(1) * 4
$CX = $NP / 2
$CY = $NP / 2

$Author = "Delahaye"
$Year = "1985"
$Title = "Regular Polygons"

# --------------------------------------------------------------------
# Select the polygon to generate
# --------------------------------------------------------------------
# Change this line to select another polygon

$Name = "Nonagon"


# --------------------------------------------------------------------
# Predefined polygons (examples)
# --------------------------------------------------------------------

$Polygons = @{
    "Figure 01"   = @{ K=4;   R=0.45; AD=$PI/4 }
    "Figure 02"   = @{ K=3;   R=0.45; AD=0     }
    "Figure 03"   = @{ K=3;   R=0.45; AD=$PI/2 }
    "Figure 04"   = @{ K=5;   R=0.45; AD=$PI/2 }
    "Figure 05"   = @{ K=8;   R=0.5;  AD=$PI/8 }
    "Figure 06"   = @{ K=20;  R=0.45; AD=0     }
    "Hexagon"     = @{ K=6;   R=0.45; AD=$PI/2 }
    "Heptagon"    = @{ K=7;   R=0.45; AD=$PI/2 }
    "Octagon"     = @{ K=8;   R=0.45; AD=$PI/2 }
    "Nonagon"     = @{ K=9;   R=0.45; AD=$PI/2 }
    "Decagon"     = @{ K=10;  R=0.45; AD=$PI/2 }
    "Hendecagon"  = @{ K=11;  R=0.45; AD=$PI/2 }
    "Dodecagon"   = @{ K=12;  R=0.45; AD=$PI/2 }
    "Tridecagon"  = @{ K=13;  R=0.45; AD=$PI/2 }
    "Icosagon"    = @{ K=20;  R=0.45; AD=$PI/2 }
}

# Hexagon, Heptagon, Octagon, Decagon are added.

$Params = $Polygons[$Name]
$K  = $Params.K
$AD = $Params.AD
$R  = $NP * $Params.R

# --------------------------------------------------------------------
# Compute polygon vertices
# --------------------------------------------------------------------

$points = @()

for ($i = 0; $i -lt $K; $i++) {
    $angle = (2 * $PI * $i / $K) + $AD
    $x = [math]::Floor($CX + $R * [math]::Cos($angle))
    $y = [math]::Floor($CY + $R * [math]::Sin($angle))

    $points += [PSCustomObject]@{
        I = $i
        X = $x
        Y = $y
    }
}

# --------------------------------------------------------------------
# Display point table
# --------------------------------------------------------------------

$points | Format-Table -AutoSize

# --------------------------------------------------------------------
# Generate X‑710 sequence (console output)
# --------------------------------------------------------------------

Write-Host "`n--- Canon X-710 Sequence ---`n"

Write-Host "; $Title"
Write-Host "; $Author"
Write-Host "; $Year"
Write-Host ";"
Write-Host "; $Name"
Write-Host ";"
Write-Host 'CHR$(18)'
Write-Host "M0,-500"
Write-Host "I"

for ($i = 0; $i -lt $points.Count; $i++) {
    $p = $points[$i]
    if ($i -eq 0) {
        Write-Host ("M{0},{1}" -f $p.X, $p.Y)
    } else {
        Write-Host ("D{0},{1}" -f $p.X, $p.Y)
    }
}

# Close the polygon
$p0 = $points[0]
Write-Host ("D{0},{1}" -f $p0.X, $p0.Y)

Write-Host ";"
Write-Host "; end"

# --------------------------------------------------------------------
# Export to .plt file
# --------------------------------------------------------------------

$FileName = ($Name.Replace(" ", "-")) + ".plt"
$Lines = @()

$Lines += "; $Title"
$Lines += "; $Name"
$Lines += "; $Year"
$Lines += ";"
$Lines += "; $Name"
$Lines += ";"
$Lines += 'CHR$(18)'
$Lines += "M0,-500"
$Lines += "I"

foreach ($p in $points) {
    if ($p.I -eq 0) {
        $Lines += "M$($p.X),$($p.Y)"
    } else {
        $Lines += "D$($p.X),$($p.Y)"
    }
}

# Close polygon
$Lines += "D$($p0.X),$($p0.Y)"

$Lines += ";"
$Lines += "; end"

$Lines | Set-Content -Encoding ASCII $FileName

Write-Host "`nFile generated: $FileName"

# -----[EOS]----------------------------------------------------------