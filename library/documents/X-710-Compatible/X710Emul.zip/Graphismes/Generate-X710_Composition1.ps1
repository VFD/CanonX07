﻿<#
.SYNOPSIS
    Computes the points of Delahaye's REGULAR STARS and generates
    the M/D command sequence for the Canon X‑710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program "ETOILES REGULIERES"
    from the book:
        "Dessins géométriques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined figure parameters,
      - computes the star coordinates (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, K, H, R, etc.) are defined internally.

.NOTES
    Author   : VincentD
    Project  : Canon X‑07 / X‑710 reconstruction and preservation
    File     : Generate-X710_Stars.ps1
#>

# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------

$NP = 480
$PI = [math]::Atan(1) * 4
$DX = $NP / 2
$DY = $NP / 2

$Author = "Delahaye"
$Year = "1985"
$Title = "Composition 1"

# --------------------------------------------------------------------
# Select the figure to generate
# --------------------------------------------------------------------
# Change this line to select another figure

$Name = "Figure 13"

# --------------------------------------------------------------------
# Predefined figures
# --------------------------------------------------------------------

$Figures = @{
    "Figure 13" = @{ K1=5;   K=25;  H=12;  R1=0.27;  R=0.22;  A1=$PI/2;  AD=$PI/2 }
    "Figure 14" = @{ K1=6;   K=24;  H=11;  R1=0.2;   R=0.3;   A1=0;      AD=0     }
    "Figure 15" = @{ K1=40;  K=80;  H=1;   R1=0.25;  R=0.25;  A1=$PI/2;  AD=$PI/2 }
    "Figure 16" = @{ K1=10;  K=10;  H=3;   R1=0.35;  R=0.15;  A1=$PI/2;  AD=0     }
    "Figure 17" = @{ K1=63;  K=4;   H=1;   R1=0.15;  R=0.35;  A1=0;      AD=0     }
    "Figure 18" = @{ K1=25;  K=5;   H=2;   R1=0.1;   R=0.4;   A1=$PI/2;  AD=$PI/2 }
	"Figure 19" = @{ K1=99;  K=7;   H=3;   R1=0.25;  R=0.25;  A1=0;      AD=$PI/2 }
}



$Params = $Figures[$Name]
$K1  = $Params.K1
$K  = $Params.K
$H  = $Params.H
$R1 = $NP * $Params.R1
$R  = $NP * $Params.R
$A1 = $Params.A1
$AD = $Params.AD


# --------------------------------------------------------------------
# Compute points
# --------------------------------------------------------------------

$points = @()

for ($i1 = 0; $i1 -le ($K1 -1) ; $i1++) {
    $angle = (2 * $PI * $i1 * $H / $K1) + $A1
    $CX = [math]::Floor($DX + $R1 * [math]::Cos($angle))
    $CY = [math]::Floor($DY + $R1 * [math]::Sin($angle))

	for ($i = 0; $i -le $K; $i++) {
		$angle = (2 * $i * $H * $PI / $K) + $AD
		$x = [math]::Floor($CX + $R * [math]::Cos($angle))
		

        if ($Name -eq "Figure 19") {
            $y = [math]::Floor( [int](1.5 * ($CY + $R * [math]::Sin($angle)))  )
        } else {
            $y = [math]::Floor($CY + $R * [math]::Sin($angle))
        }


		$points += [PSCustomObject]@{
			I = $i
			X = $x
			Y = $y
		}
    }
}

# --------------------------------------------------------------------
# Display point table
# --------------------------------------------------------------------

$points | Format-Table -AutoSize

# --------------------------------------------------------------------
# Generate X‑710 sequence (console output)
# --------------------------------------------------------------------

Write-Host "`n--- Canon X-710 Sequence ---`n"

Write-Host "; $Title"
Write-Host "; $Author"
Write-Host "; $Year"
Write-Host ";"
Write-Host "; $Name"
Write-Host ";"
Write-Host 'CHR$(18)'

if ($Name -eq "Figure 19") {
    Write-Host "M0,-800"
} else {
    Write-Host "M0,-500"
}

Write-Host "I"

for ($i = 0; $i -lt $points.Count; $i++) {
    $p = $points[$i]
    if ($i -eq 0) {
        Write-Host ("M{0},{1}" -f $p.X, $p.Y)
    } else {
        Write-Host ("D{0},{1}" -f $p.X, $p.Y)
    }
}

Write-Host ";"
Write-Host "; end"

# --------------------------------------------------------------------
# Export to .plt file
# --------------------------------------------------------------------

$FileName = ($Name.Replace(" ", "-")) + ".plt"
$Lines = @()

$Lines += "; $Title"
$Lines += "; $Author"
$Lines += "; $Year"
$Lines += ";"
$Lines += "; $Name"
$Lines += ";"
$Lines += 'CHR$(18)'

if ($Name -eq "Figure 19") {
    $Lines += "M0,-800"
} else {
    $Lines += "M0,-500"
}

$Lines += "I"

foreach ($p in $points) {
    if ($p.I -eq 0) {
        $Lines += "M$($p.X),$($p.Y)"
    } else {
        $Lines += "D$($p.X),$($p.Y)"
    }
}

$Lines += ";"
$Lines += "; end"

$Lines | Set-Content -Encoding ASCII $FileName

Write-Host "`nFile generated: $FileName"

# -----[EOS]----------------------------------------------------------