; Regular Polygons
; Nonagon
; 1985
;
; Nonagon
;
CHR$(18)
M0,-500
I
M240,456
D101,405
D27,277
D52,132
D166,37
D313,37
D427,131
D452,277
D378,405
D240,456
;
; end
