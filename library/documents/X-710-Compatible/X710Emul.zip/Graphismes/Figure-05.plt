; Regular Polygons
; Figure 5
; 1985
;
; Figure 5
;
CHR$(18)
M0,-500
I
M461,331
D331,461
D148,461
D18,331
D18,148
D148,18
D331,18
D461,148
D461,331
;
; end
