; Regular Polygon
; Delahaye
;
; Triangle
;
CHR$(18)
M0,-500
I
M456,240
D132,427
D131,52
D456,240
;
; end
