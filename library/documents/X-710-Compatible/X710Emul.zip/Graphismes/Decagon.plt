; Regular Polygon
; Delahaye
;
; Decagon
;
CHR$(18)
M0,-500
I
M240,456
D113,414
D34,306
D34,173
D113,65
D239,24
D366,65
D445,173
D445,306
D366,414
D240,456
;
; end
