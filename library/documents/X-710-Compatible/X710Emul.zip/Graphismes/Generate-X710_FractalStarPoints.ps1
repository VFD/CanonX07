<#
.SYNOPSIS
    Computes the points of Delahaye's FRACTAL STARS and generates
    the M/D command sequence for the Canon X-710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program "ETOILES FRACTALES"
    from the book:
        "Dessins g�om�triques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined figure parameters,
      - computes the star coordinates (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, K, N, RA, etc.) are defined internally.

.NOTES
    Author   : VincentD
    Project  : Canon X-07 / X-710 reconstruction and preservation
    File     : Generate-X710_FractalStars.ps1
#>

# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------

$NP = 480
$PI = [math]::Atan(1) * 4

$Author = "Delahaye"
$Year = "1985"
$Title = "Fractal Stars"

# --------------------------------------------------------------------
# Select the figure to generate
# --------------------------------------------------------------------
# Change this line to select another figure

$Name = "Figure 65"

# --------------------------------------------------------------------
# Predefined fractal stars
# --------------------------------------------------------------------

$Figures = @{
    "Figure 65"  = @{ N=5;   K=5;   RA=0.35;   LL=$NP;        AA=4*$PI/5 }
    "Figure 66"  = @{ N=7;   K=4;   RA=0.32;   LL=$NP;        AA=6*$PI/7 }
    "Figure 67"  = @{ N=12;  K=3;   RA=0.5;    LL=$NP*11/48;  AA=2*$PI/12 }
    "Figure 68"  = @{ N=5;   K=2;   RA=0.5;    LL=$NP/2;      AA=2*$PI/5 }
    "Figure 69"  = @{ N=8;   K=2;   RA=0.5;    LL=$NP/3;      AA=$PI/4 }
    "Figure 70"  = @{ N=20;  K=2;   RA=0.5;    LL=$NP*13/96;  AA=$PI/10 }
    "Figure 71"  = @{ N=15;  K=2;   RA=0.9;    LL=$NP*43/48;  AA=14*$PI/15 }
    "Figure 72"  = @{ N=16;  K=3;   RA=0.27;   LL=$NP/6;      AA=$PI/8 }
    "Figure 73"  = @{ N=8;   K=4;   RA=0.5;    LL=$NP*17/48;  AA=$PI/4 }
    "Figure 74"  = @{ N=7;   K=5;   RA=0.383;  LL=$NP*7/12;   AA=2*$PI/5 }
    "Figure 75"  = @{ N=4;   K=8;   RA=0.47;   LL=$NP;        AA=$PI/2 }
    "Figure 76"  = @{ N=15;  K=3;   RA=0.3;    LL=$NP;        AA=14*$PI/15 }
    "Figure 77"  = @{ N=3;   K=11;  RA=0.62;   LL=$NP;        AA=2*$PI/3 }
}

$Params = $Figures[$Name]
$N  = $Params.N
$K  = $Params.K
$RA = $Params.RA
$LL = $Params.LL
$AA = $Params.AA

# Derived parameters
$X0 = ($NP - $LL) / 2
$Y0 = $NP / 4
$A0 = -$AA

# Total number of segments
$NN = $N * [math]::Pow($N - 1, $K - 1)

# --------------------------------------------------------------------
# Compute fractal star points
# --------------------------------------------------------------------

$points = @()

for ($i = 0; $i -le $NN; $i++) {
    $I1 = $i
    $H = 0

    # Determine fractal level
    while ( ( ($I1 % ($N - 1)) -eq 0 ) -and ( $H -lt ($K - 1) ) ) {
        $I1 = $I1 / ($N - 1)
        $H = $H + 1
    }

    # Calculate segment length at current level
    $L0 = $LL * [math]::Pow($RA, $K - 1 - $H)

    # Update angle
    $A0 = $A0 + $AA

    # Calculate coordinates
    $X0 = $X0 + $L0 * [math]::Cos($A0)
    $Y0 = $Y0 + $L0 * [math]::Sin($A0)

    # Apply INT() equivalent
    $Xi = [math]::Floor($X0)
    $Yi = [math]::Floor($Y0)

    $points += [PSCustomObject]@{
        I = $i
        X = $Xi
        Y = $Yi
        H = $H
    }
}

# --------------------------------------------------------------------
# Display point table
# --------------------------------------------------------------------

$points | Format-Table -AutoSize

# --------------------------------------------------------------------
# Generate X-710 sequence (console output)
# --------------------------------------------------------------------

Write-Host "`n--- Canon X-710 Sequence ---`n"

Write-Host "; $Title"
Write-Host "; $Author"
Write-Host "; $Year"
Write-Host ";"
Write-Host "; $Name (N=$N, K=$K, RA=$RA)"
Write-Host ";"
Write-Host 'CHR$(18)'

if ($Name -eq "Figure 74") {
    Write-Host "M0,-600"
} else {
    Write-Host "M0,-500"
}

Write-Host "I"

for ($i = 0; $i -lt $points.Count; $i++) {
    $p = $points[$i]
    if ($i -eq 0) {
        Write-Host ("M{0},{1}" -f $p.X, $p.Y)
    } else {
        Write-Host ("D{0},{1}" -f $p.X, $p.Y)
    }
}

Write-Host ";"
Write-Host "; end"

# --------------------------------------------------------------------
# Export to .plt file
# --------------------------------------------------------------------

$FileName = ($Name.Replace(" ", "-")) + ".plt"
$Lines = @()

$Lines += "; $Title"
$Lines += "; $Author"
$Lines += "; $Year"
$Lines += ";"
$Lines += "; $Name (N=$N, K=$K, RA=$RA)"
$Lines += ";"
$Lines += 'CHR$(18)'

if ($Name -eq "Figure 74") {
    $Lines += "M0,-600"
} else {
    $Lines += "M0,-500"
}

$Lines += "I"

foreach ($p in $points) {
    if ($p.I -eq 0) {
        $Lines += "M$($p.X),$($p.Y)"
    } else {
        $Lines += "D$($p.X),$($p.Y)"
    }
}

$Lines += ";"
$Lines += "; end"

$Lines | Set-Content -Encoding ASCII $FileName

Write-Host "`nFile generated: $FileName"

# -----[EOS]----------------------------------------------------------