; Regular Polygon
; Delahaye
;
; Square
;
CHR$(18)
M0,-500
I
M392,392
D87,392
D87,87
D392,87
D392,392
;
; end
