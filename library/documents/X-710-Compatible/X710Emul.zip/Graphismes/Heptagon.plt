; Regular Polygon
; Delahaye
;
; Heptagon
;
CHR$(18)
M0,-500
I
M240,456
D71,374
D29,191
D146,45
D333,45
D450,191
D408,374
D240,456
;
; end
