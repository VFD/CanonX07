; Regular Polygon
; Delahaye
;
; Hexagon
;
CHR$(18)
M0,-500
I
M240,456
D52,348
D52,132
D239,24
D427,131
D427,348
D240,456
;
; end
