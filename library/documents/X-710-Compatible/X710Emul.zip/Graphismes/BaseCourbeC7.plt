; ------------------------------
; X-710 plotter file Simulator
; ------------------------------
; Extract from :
; Trace de Courbe
; Club C7
;
CHR$(18)
I
; Color (variable in code), set to 0
C0
S2
; Draw contour area
J480,0,0,-950,-480,0,0,950
; Draw line
M0,-45
J480,0
; Draw line
M0,-785
J480,0
; Write text (variable in code)
M0,-40
P Hello Olipix!
;
; Draw axe x,y
;
M240,-65
J0,-700
;
M10,-415
J460,0
M240,-415
;
; Set origine axe x,y
;
I
; end