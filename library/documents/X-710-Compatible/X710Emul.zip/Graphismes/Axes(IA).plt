; ------------------------------
; X-710 plotter file Simulator
; ------------------------------
;
; via IA après apprentissage
;

; Positionne le stylet au centre du papier
M240,-240

; Définit ce point comme origine (0,0)
I

; Trace l'axe X (horizontal)
; Du point -200 à +200 sur l'axe X
D-200,0,200,0
; petite erreur ci-dessus de l'IA, vous l'avez vue ?


; Trace l'axe Y (vertical)
; Du point 0 à -200 et 0 à +200 sur l'axe Y
M0,-200
D0,-200,0,200

; Trace des petits traits de graduation sur l'axe X
M-100,0
D-100,-10
M-100,0

M-50,0
D-50,-10
M-50,0

M50,0
D50,-10
M50,0

M100,0
D100,-10
M100,0

; Trace des petits traits de graduation sur l'axe Y
M0,-100
D-10,-100
M0,-100

M0,-50
D-10,-50
M0,-50

M0,50
D-10,50
M0,50

M0,100
D-10,100
M0,100