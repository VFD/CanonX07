; Composition 1
; Delahaye
;
; Boat, p36
;
; Value x10
;
CHR$(18)
M0,-150
I
;
M20,40
D140,40
D130,20
D40,20
D20,40
;
M70,40
D70,130
D110,110
D140,50
D20,50
D70,130
;
; end