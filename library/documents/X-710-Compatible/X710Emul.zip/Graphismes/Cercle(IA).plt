; ------------------------------
; X-710 plotter file Simulator
; ------------------------------
;
; via IA après apprentissage
; Bug

; Positionne le stylet au centre du cercle
M240,-240

; Définit ce point comme origine
I

; Rayon = 100 pts, 30 segments pour approximer le cercle
; Angle par segment = 360/30 = 12 degrés

; Premier point du cercle (angle 0°)
M100,0

; Trace les 30 segments du cercle
D97,26,92,50,83,71,71,83,50,92,26,97,0,100,-26,97,-50,92,-71,83,-83,71,-92,50,-97,26,-100,0,-97,-26,-92,-50,-83,-71,-71,-83,-50,-92,-26,-97,0,-100,26,-97,50,-92,71,-83,83,-71,92,-50,97,-26,100,0