<#
.SYNOPSIS
    Computes the points of Delahaye's Oiseau-Poisson and generates
    the M/D command sequence for the Canon X‑710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program from the book:
        "Dessins géométriques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined figure parameters,
      - computes the star coordinates (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, K, H, R, etc.) are defined internally.

.NOTES
    Author   : VincentD
    Project  : Canon X‑07 / X‑710 reconstruction and preservation
    File     : Generate-X710_Stars.ps1
#>



# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------
$NP = 480
$PI = [math]::Atan(1) * 4

$Author = "Delahaye"
$Year = "1985"
$Title = "Lion"

# Select
$Name = "Figure-44"

# --------------------------------------------------------------------
# DATA
# --------------------------------------------------------------------
$commands = @(
	"M -2.5,0"
	"D -2,1, -1,2, 0,7, 1,7, 2,8, 2,11, 3,14, 3.5,13.5"
	"D 2.5,11, 2.5,9"
	"M 3.5,13.5"
	"D 4,13, 3,11, 3,9, 3,11, 4,13, 5,12, 3.5,11, 3.5,9"
	"D 3.5,11, 5,12, 5,11, 4,10, 4,9, 8,9, 7,11, 8,13, 10,14, 12,13, 13,11"
	"D 12,11, 11,10, 12,8, 13,7, 14,2,15,2, 16,1, 16,0, 12,0, 12,2, 11,5"
	"D 11.5,6, 11,5, 9,3, 9,2, 10,1, 10,0, 6,0, 7,2, 8,6, 7,2, 6,4, 4,5"
	"D 5,7, 4,8, 5,7, 4,5, 2,4, 1,2, 2,2, 3,1, 2.5,0, -2.5,0"
	"M 6,4"
	"D 7.5,3.5"
	"M 12,11"
	"D 10,10.5, 9,10.5"
	"M 12.5,12"
	"D 12,12, 11,11.5, 12,12, 12,12.5, 11.5,12.5, 10.5,13"
	"D 10,13, 10,13.5, 10.5,13.5, 10.5,13, 11.5,12.5, 12,12.5, 12,13"
	"M 7.5,12"
	"D 8.5,12, 8.5,11.5"
)


# --------------------------------------------------------------------
# Compute Lion
# --------------------------------------------------------------------

function Dessin-44 {
    param(
        [string[]]$commands,
        [scriptblock]$transformX = { param($A) [int]($NP * ($A +5) / 25 ) },
        [scriptblock]$transformY = { param($B) [int]($NP * ($B +5) / 25 ) }
    )
    
    $transformedCommands = @()
    
    foreach ($cmd in $commands) {
        if ([string]::IsNullOrWhiteSpace($cmd)) { continue }
        
        $parts = $cmd -split '\s+', 2
        $commandType = $parts[0]  # M ou D
        $coordsString = $parts[1]
        
        # Parser
        $coordPairs = $coordsString -split ',\s*'
        $transformedCoords = @()
        
        for ($i = 0; $i -lt $coordPairs.Count; $i += 2) {
            if ($i + 1 -lt $coordPairs.Count) {
                $x = [double]$coordPairs[$i]
                $y = [double]$coordPairs[$i + 1]
                
                # Appliquer la transformation
                $newX = & $transformX $x
                $newY = & $transformY $y
                
                $transformedCoords += "$newX,$newY"
            }
        }
        
        # Rebuild command
        $newCmd = "$commandType " + ($transformedCoords -join ", ")
        $transformedCommands += $newCmd
    }
    
    return $transformedCommands
}




# --------------------------------------------------------------------
# Choose by comment
# --------------------------------------------------------------------
# To do : all figure

$result = Dessin-44 -commands $commands



# --------------------------------------------------------------------
# Show results
# --------------------------------------------------------------------
$result | ForEach-Object { Write-Host $_ }

# --------------------------------------------------------------------
# Build .plt
# --------------------------------------------------------------------

$FileName = $Name + ".plt"
$Lines = @()

$Lines += "; $Title"
$Lines += "; $Author"
$Lines += "; $Year"
$Lines += ";"
$Lines += "; $Name"
$Lines += ";"
$Lines += 'CHR$(18)'

$Lines += "M0,-500"
$Lines += "I"

$result | ForEach-Object { $Lines += $_ }

$Lines += ";"
$Lines += "; end"

$Lines | Set-Content -Encoding ASCII $FileName

Write-Host "`nFile generated: $FileName"


# -----[eos]----------------------------------------------------------