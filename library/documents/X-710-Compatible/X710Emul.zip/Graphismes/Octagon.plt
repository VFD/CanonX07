; Regular Polygon
; Delahaye
;
; Octagon
;
CHR$(18)
M0,-500
I
M439,322
D322,439
D157,439
D40,322
D40,157
D157,40
D322,40
D439,157
D439,322
;
; end
