; Regular Polygons
; Figure 4
; 1985
;
; Figure 4
;
CHR$(18)
M0,-500
I
M240,456
D34,306
D113,65
D366,65
D445,306
D240,456
;
; end
