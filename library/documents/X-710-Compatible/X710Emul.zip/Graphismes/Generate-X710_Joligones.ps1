﻿<#
.SYNOPSIS
    Computes the points of Delahaye's JOLIGONES and generates
    the M/D command sequence for the Canon X‑710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program "ETOILES REGULIERES"
    from the book:
        "Dessins géométriques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined figure parameters,
      - computes the coordinates (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, K, H, R, etc.) are defined internally.

.NOTES
    Author   : VincentD
    Project  : Canon X‑07 / X‑710 reconstruction and preservation
    File     : Generate-X710_Stars.ps1
#>

# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------

$NP = 480
$PI = [math]::Atan(1) * 4

$Author = "Delahaye"
$Year = "1985"
$Title = "Joligones"

# --------------------------------------------------------------------
# Select the figure to generate
# --------------------------------------------------------------------
# Change this line to select another figure

$Name = "Figure 26"


# --------------------------------------------------------------------
# Predefined figures
# --------------------------------------------------------------------

$Figures = @{
    "Figure 26" = @{ K=200;   AN=15*$PI/31;     RA=0.98;  AA=0; RR=0.80  }
    "Figure 27" = @{ K=120;   AN=29*$PI/30;     RA=0.98;  AA=0; RR=0.80  }
    "Figure 28" = @{ K=200;   AN=$PI/4;         RA=0.98;  AA=0; RR=0.40  }
    "Figure 29" = @{ K=2000;  AN=$PI/20;        RA=0.998; AA=0; RR=0.065 }
    "Figure 30" = @{ K=200;   AN=4*$PI/5+0.02;  RA=0.99;  AA=0; RR=0.80  }
    "Figure 31" = @{ K=100;   AN=6*$PI/7;       RA=0.98;  AA=0; RR=0.80  }
    "Figure 32" = @{ K=300;   AN=2*$PI/5+0.01;  RA=0.993; AA=0; RR=0.60  }
    "Figure 33" = @{ K=400;   AN=19*$PI/60;     RA=0.996; AA=0; RR=0.40  }
}



$Params = $Figures[$Name]
$K  = $Params.K
$AN = $Params.AN
$RA = $Params.RA
$AA = $Params.AA
$RR = $NP * $Params.RR

Write-Host "$K $AN $RA $AA $RR"

# reset
$x = 0; $xi = 0
$y = 0; $yi = 0


# --------------------------------------------------------------------
# Compute star points
# --------------------------------------------------------------------

$points = @()

$x = [int]( ($NP - $RR) / 2 )
$y = 0

Write-Host "$x1 $y1"

$points += [PSCustomObject]@{
    I = 0
    X = $x
    Y = $y
}



for ($i = 0; $i -le $K; $i++) {

    $x = $x + $RR * [math]::Cos($AA)
    $xi = [int]$x

    $y = $y + $RR * [math]::Sin($AA)

    if ($Name -eq "Figure 33") {
        $yi = [int](1.7*$y)
    } else {
        $yi = [int]$y
    }
    

    $points += [PSCustomObject]@{
        I = 1
        X = $xi
        Y = $yi
    }

    $AA = $AA + $AN
    $RR = $RR * $RA

}

# --------------------------------------------------------------------
# Display point table
# --------------------------------------------------------------------

$points | Format-Table -AutoSize

# --------------------------------------------------------------------
# Generate X‑710 sequence (console output)
# --------------------------------------------------------------------

Write-Host "`n--- Canon X-710 Sequence ---`n"

Write-Host "; $Title"
Write-Host "; $Author"
Write-Host "; $Year"
Write-Host ";"
Write-Host "; $Name"
Write-Host ";"
Write-Host 'CHR$(18)'

if ($Name -eq "Figure 33") {
    Write-Host "M0,-800"
} else {
    Write-Host "M0,-500"
}

Write-Host "I"

for ($i = 0; $i -lt $points.Count; $i++) {
    $p = $points[$i]
    if ($i -eq 0) {
        Write-Host ("M{0},{1}" -f $p.X, $p.Y)
    } else {
        Write-Host ("D{0},{1}" -f $p.X, $p.Y)
    }
}

Write-Host ";"
Write-Host "; end"

# --------------------------------------------------------------------
# Export to .plt file
# --------------------------------------------------------------------

$FileName = ($Name.Replace(" ", "-")) + ".plt"
$Lines = @()

$Lines += "; $Title"
$Lines += "; $Author"
$Lines += "; $Year"
$Lines += ";"
$Lines += "; $Name"
$Lines += ";"
$Lines += 'CHR$(18)'

if ($Name -eq "Figure 33") {
    $Lines += "M0,-800"
} else {
    $Lines += "M0,-500"
}

$Lines += "I"

foreach ($p in $points) {
    if ($p.I -eq 0) {
        $Lines += "M$($p.X),$($p.Y)"
    } else {
        $Lines += "D$($p.X),$($p.Y)"
    }
}

$Lines += ";"
$Lines += "; end"

$Lines | Set-Content -Encoding ASCII $FileName

Write-Host "`nFile generated: $FileName"


# -----[EOS]----------------------------------------------------------