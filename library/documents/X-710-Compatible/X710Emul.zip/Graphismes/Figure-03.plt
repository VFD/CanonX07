; Regular Polygons
; Figure 3
; 1985
;
; Figure 3
;
CHR$(18)
M0,-500
I
M240,456
D52,132
D427,131
D240,456
;
; end
