; ------------------------------
; X-710 plotter file Simulator
; ------------------------------

; une maison

; Point de départ en bas à gauche
M0,-500

; Trace le carré de la maison (murs)
D200,-500,200,-350,0,-350,0,-500

; Trace le toit (triangle)
M0,-350
D100,-200,200,-350

; Change la couleur en bleu pour la porte
C1

; Positionne la porte
M50,-500

; Trace la porte (rectangle)
D 50,-450, 50,-400, 100,-400, 100,-500

; Change la couleur en vert
C2
; Positionne la fenêtre
M175,-450

; Trace la fenêtre (carré)
D 175,-400, 175,-450, 125,-450, 125,-400, 175,-400
