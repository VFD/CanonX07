; Décodage du code assembleur Z80 contenu dans les lignes REM du programme LFICHE via IA
; Créé par LOGI'STICK en 1984

; Ligne 1 - Début du code machine
        ORG     1394h       ; Adresse de début probable

; Routine de recherche de fichier (EXEC1394)
SEARCH: LD      HL,(1476h)  ; Adresse de début du fichier
        LD      DE,(1478h)  ; Adresse de fin du fichier
        LD      A,1         ; Marqueur de fichier
        CP      (HL)        ; Vérifier si c'est un fichier valide
        JP      Z,FOUND     ; Si oui, sauter à FOUND
        LD      A,1         ; Code d'erreur 1 (fichier inexistant)
        LD      (1464h),A   ; Stocker le code d'erreur
        RET                 ; Retour au BASIC

FOUND:  XOR     A           ; A = 0 (pas d'erreur)
        LD      (1464h),A   ; Stocker le code d'erreur
        RET                 ; Retour au BASIC

; Routine de gestion de la mémoire (EXEC1480)
MEMCPY: LD      HL,(1481h)  ; Adresse source
        LD      DE,(1484h)  ; Adresse destination
        LD      BC,(1486h)  ; Nombre d'octets à copier
        LDIR                ; Copier les octets
        RET                 ; Retour au BASIC

; Routine de déplacement de blocs mémoire (EXEC1504)
MEMMOV: LD      HL,(1505h)  ; Adresse source
        LD      DE,(1508h)  ; Adresse destination
        LD      BC,(1511h)  ; Nombre d'octets à déplacer
        PUSH    IX          ; Sauvegarder IX
        CCF                 ; Inverser le flag de retenue
        LD      SP,HL       ; SP = adresse source
        JP      MOVE        ; Sauter à MOVE

MOVE:   PUSH    IX          ; Sauvegarder IX
        CCF                 ; Inverser le flag de retenue
        LD      E,C         ; E = partie basse du compteur
        CCF                 ; Inverser le flag de retenue
        HALT                ; Pause
        LD      C,(IX+3Fh)  ; Charger C depuis IX+3F
        CCF                 ; Inverser le flag de retenue
        LD      A,0FFh      ; A = 255
        LD      A,B         ; A = B
        CP      D           ; Comparer avec D
        JP      NC,NEXT     ; Si A >= D, sauter à NEXT
        ADC     A,79h       ; Ajouter 79h + carry à A
        CP      E           ; Comparer avec E
        RET     NC          ; Retourner si A >= E
        JP      CONT        ; Sinon, continuer

CONT:   CCF                 ; Inverser le flag de retenue
        ADC     A,C         ; Ajouter C + carry à A
        CCF                 ; Inverser le flag de retenue
        LD      HL,3F58h    ; HL = 3F58h
        AND     E           ; A = A AND E
        INC     DE          ; Incrémenter DE
        LD      (HL),A      ; Stocker A à l'adresse HL
        LD      A,B         ; A = B
        CP      D           ; Comparer avec D
        JP      C,SKIP      ; Si A < D, sauter à SKIP
        CP      E           ; Comparer avec E
        JP      C,EXIT      ; Si A < E, sauter à EXIT

NEXT:   PUSH    IX          ; Sauvegarder IX
        LD      (HL),B      ; Stocker B à l'adresse HL
        CCF                 ; Inverser le flag de retenue
        CCF                 ; Inverser le flag de retenue
        LD      HL,2B3Fh    ; HL = 2B3Fh
        INC     DE          ; Incrémenter DE
        LD      (HL),A      ; Stocker A à l'adresse HL
        LD      A,B         ; A = B
        CP      D           ; Comparer avec D
        JP      NZ,SKIP2    ; Si A != D, sauter à SKIP2
        JP      NZ,EXIT2    ; Si A != D, sauter à EXIT2

SKIP:   CP      0CAh        ; Comparer A avec 0CAh
        AND     E           ; A = A AND E
        JP      DONE        ; Sauter à DONE

SKIP2:  CP      0CAh        ; Comparer A avec 0CAh
        LD      A,0FEh      ; A = 0FEh
        JP      Z,LOOP      ; Si égal, sauter à LOOP
        LD      (HL),A      ; Stocker A à l'adresse HL
        AND     E           ; A = A AND E
        JP      (HL)        ; Sauter à l'adresse contenue dans HL

EXIT:   PUSH    IX          ; Sauvegarder IX
        LD      E,IXh       ; E = partie haute de IX
        CCF                 ; Inverser le flag de retenue
        INC     DE          ; Incrémenter DE

EXIT2:  CP      0CAh        ; Comparer A avec 0CAh
        RST     20h         ; Appel à la routine système 20h
        JP      DONE        ; Sauter à DONE

LOOP:   INC     DE          ; Incrémenter DE
        INC     DE          ; Incrémenter DE
        CP      0CAh        ; Comparer A avec 0CAh
        OR      A           ; Mettre à jour les flags
        CP      0CAh        ; Comparer A avec 0CAh
        RET     NZ          ; Retourner si non égal

DONE:   JP      0FFFFh      ; Sauter à 0FFFFh (fin du programme)
        RST     38h         ; Appel à la routine système 38h
        INC     DE          ; Incrémenter DE

; Ligne 2 - Contient principalement des octets DD répétés (préfixes IX)
; Cette section semble être utilisée comme tampon ou zone de données

; Ligne 3 - Partie après GOTO10:REM
        JP      Z,0FE47h    ; Sauter à 0FE47h si le flag Z est actif
        JP      Z,0FE47h    ; Sauter à 0FE47h si le flag Z est actif
        RST     38h         ; Appel à la routine système 38h
        JP      Z,0C347h    ; Sauter à 0C347h si le flag Z est actif
        INC     (HL)        ; Incrémenter le contenu de l'adresse HL
        LD      C,IXl       ; C = partie basse de IX
        LD      C,C         ; C = C (opération sans effet)
        LD      D,E         ; D = E
        LD      B,L         ; B = L
        LD      B,C         ; B = C
        LD      D,L         ; D = L
        PUSH    IX          ; Sauvegarder IX
        PUSH    IX          ; Sauvegarder IX
        DEC     HL          ; Décrémenter HL
        LD      SP,HL       ; SP = HL
        LD      (0E8C5h),A  ; Stocker A à l'adresse 0E8C5h
        LD      (0C3C6h),A  ; Stocker A à l'adresse 0C3C6h
        AND     E           ; A = A AND E
        XOR     B           ; A = A XOR B
        CP      0C3h        ; Comparer A avec 0C3h
        AND     E           ; A = A AND E
        XOR     B           ; A = A XOR B
        CP      0FFh        ; Comparer A avec 0FFh
        JP      NEXT_INSTR  ; Sauter à l'instruction suivante

NEXT_INSTR:
        ; Suite du code...

; Autres routines appelées par EXEC
; Ces adresses sont référencées dans le programme BASIC

; EXEC1556 - Lecture de rubriques
; EXEC1615 - Lecture de fiches
; EXEC1666 - Initialisation
; EXEC1735 - Affichage d'informations sur le fichier
; EXEC1842 - Suppression de rubriques
; EXEC1897 - Manipulation de chaînes
; EXEC1915 - Recherche de rubriques
; EXEC1977 - Modification de rubriques
; EXEC2049 - Modification de contenu
; EXEC2107 - Destruction de rubriques
; EXEC2242 - Gestion de la mémoire
; EXEC2257 - Gestion de la mémoire
; EXEC2289 - Insertion de rubriques
; EXEC2330 - Insertion de données
; EXEC2375 - Insertion spéciale
; EXEC2402 - Insertion spéciale
; EXEC2441 - Insertion spéciale
; EXEC2472 - Lecture de données
; EXEC2534 - Opérations sur rubriques
; EXEC2569 - Vérification de rubriques
; EXEC&HC4D1 - Initialisation totale