
10 DIMA(9),B(8),C(9):FORI=1TO9:A(I)=1:NEXT
15 INPUT"Qui debute (X):X-07;(M):Vous";R$:IFR$="M"THEN50
20 B(1)=A(1)*A(2)*A(3):B(2)=A(4)*A(5)*A(6):B(3)=A(7)*A(8)*A(9)
25 B(4)=A(1)*A(4)*A(7):B(5)=A(2)*A(5)*A(8):B(6)=A(3)*A(6)*A(9)
27 B(7)=A(1)*A(5)*A(9):B(8)=A(3)*A(5)*A(7):C(1)=B(1)+B(4)+B(7)
28 C(2)=B(1)+B(5):C(3)=B(1)+B(6)+B(8):C(8)=B(3)+B(5):C(9)=B(3)+B(6)+B(7)
30 C(4)=B(2)+B(4):C(5)=B(2)+B(5)+B(7)+B(8):C(6)=B(2)+B(6):C(7)=B(3)+B(4)+B(8)
36 T=-99:FORI=1TO9:IFC(I)>TTHENIFA(I)=1THENT=C(I):K=I
40 NEXTI:A(K)=6:PRINT"Je joue";K
50 INPUT"Vous jouez ";K:A(K)=-4:GOTO20
