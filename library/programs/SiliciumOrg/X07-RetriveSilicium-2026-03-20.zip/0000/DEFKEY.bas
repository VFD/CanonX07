
10 KEY$(1)="iniINIT #1,"+CHR$(34)+"COM:"+CHR$(34)+CHR$(13)
20 KEY$(3)="l#1LIST #1"
