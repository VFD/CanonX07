10 ' ****************
20 ' *  programme   *
30 ' *    SPACE     *
40 ' ****************
50 ' * par JOUDRIER *
60 ' * JEAN MICHEL  *
70 ' ****************
80 ' *  (c)  1985   *
90 ' *     sur      *
100 '*  CANON x-07  *
110 '****************
120 '* d�finition   *
130 '* caract�res   *
140 '****************
150 FONT$(128)="&H20,&H20,&H70,&HF8,&HF8,&HD8,&H00,&H00"
160 FONT$(129)="&HFC,&HFC,&H78,&H78,&H48,&H00,&H00,&H00"
170 FONT$(130)="&H00,&H20,&H20,&H20,&H20,&H20,&H20,&H20"
180 FONT$(131)="&H00,&H18,&H7C,&HF8,&H7C,&H18,&H00,&H00"
190 FONT$(132)="&H20,&H10,&H20,&H10,&H20,&H10,&H20,&H10"
200 FONT$(133)="&H40,&H08,&H00,&H40,&H49,&H70,&HD8,&HFC"
210 FONT$(134)="&HA8,&H51,&HA8,&H51,&HA8,&H51,&HA8,&H51"
220 FONT$(135)="&H8C,&H74,&H7C,&H44,&H74,&H64,&H94,&HFC"
230 FONT$(136)="&H8C,&H74,&H74,&H04,&H74,&H74,&H74,&HFC"
240 FONT$(137)="&H74,&H74,&H34,&H54,&H64,&H74,&H74,&HFC"
250 FONT$(138)="&H04,&H7C,&H7C,&H0C,&H7C,&H7C,&H04,&HFC"
260 FONT$(139)="&HFC,&HFC,&HFC,&HFC,&HFC,&HFC,&HFC,&HFC"
270 CLS
280 '***************
290 '*   r�gles    *
291 '***************
292 CLS:PRINT "    JOUDRIER  JM          Pr�sente"
293 LOCATE 5,3
294 PRINT "S ";:FOR I=1 TO 50:NEXT:PRINT "P ";:PRINT "A ";:FOR I=1 TO 50:NEXT
295 PRINT "C ";:FOR I=1 TO 50:NEXT:PRINT "E ";:FOR I=1 TO 75:NEXT:PRINT CHR$(131);
296 FOR I=1 TO 100:FOR J=5 TO 1 STEP -1:BEEP J,1:IF INKEY$="" THEN NEXT J,I
297 CLS
310 PRINT "    Voulez-vous        Les r�gles (O-N)";
320 A$=INKEY$
330 IF A$="N" THEN 610
340 IF A$="O" THEN 360
350 GOTO 320
360 CLS
370 PRINT "\
Vous devez aller    \
 chercher un tr�sor \
      d�tenu par ...";
380 GOSUB 10000
390 CLS:PRINT "\
vos ennemis.        \
Il y a deux tableaux\
au premier il faut..";
400 GOSUB 10000
410 CLS:PRINT "\
d�truire le plus de \
vaisseaux possible  \
sans se faire tuer..";
420 GOSUB 10000
430 CLS:PRINT "\
par  leurs  rayons  \
laser.     Il faut  \
atteindre au moins..";
440 GOSUB 10000
450 CLS:PRINT "\
350 points en un    \
temps limit� pour   \
pouvoir passer...   ";
460 GOSUB 10000
470 CLS:PRINT "\
au tableau suivant  \
ou il faut �viter   \
les montagnes.      ";
480 GOSUB 10000
490 CLS:PRINT "\
Au 1er tableau on se\
d�place avec les    \
fl�ches droite ...  ";
500 GOSUB 10000
510 CLS:PRINT "\
et gauche du curseur\
et en tirant avec   \
la barre espace...  ";
520 GOSUB 10000
530 CLS:PRINT "\
au 2nd tableau on ne\
peut pas tirer mais \
on se d�place avec..";
540 GOSUB 10000
550 CLS:PRINT "\
les 4 fl�ches du    \
curseur en faisant  \
varier la vitesse...";
560 GOSUB 10000
570 CLS:PRINT "\
en appuyant plus-   \
ieurs fois sur les  \
fl�ches.            ";
580 GOSUB 10000
590 CLS:LOCATE 3,2:PRINT "BONNE CHANCE !";
600 GOSUB 10000
610 '****************
620 '* bruit du tir *
630 '****************
640 A=8500
650 RESTORE:FOR I=1 TO 19:READ A$
670 POKE A,VAL("&H"+A$):A=A+1:NEXT I
700 DATA 3E,FF,D3,F4,AF,D3
710 DATA F3,06,30,10,FE,D3,F2,3C
720 DATA 20,F7,D3,F4,C9
730 '***************
740 '* 1er tableau *
750 '***************
760 CLS:PRINT "�86�86�86SPACE INVADER�86�86�86";
780 '**************
790 ' ^ = grph / = �82
800 '**************
810 FOR I=1 TO 100:BEEP I,1:NEXT I
840 CLS:NB=75
860 CONSOLE ,,,0
870 UZ=RND(0)
880 C=10
890 '***************
900 '*boucle princ.*
910 '***************
920 A=INT(RND(1)*19)
930 IF A=20 OR A=0 THEN 920
940 LOCATE C2,3:PRINT " ";
950 IF SCREEN(C,3)=132 THEN BEEP 500,15:GOTO 1250
960 LOCATE C,3:PRINT CHR$(128);
970 LOCATE U,1:PRINT " ":LOCATE U,2:PRINT " ":LOCATE U,3:PRINT " ";
980 U=INT(RND(1)*19)
990 IF U=20 OR U=0 THEN 1060
1000 IF SCREEN(U,0)<>129 THEN 1060
1010 IF SCREEN(U,3)=128 THEN LOCATE U,1:PRINT CHR$(132);:BEEP 500,15:GOTO 1250
1020 LOCATE U,1:PRINT "�84":LOCATE U,2:PRINT "�84":LOCATE U,3:PRINT "�84";
1030 '**************
1040 '* - = GRPH [ =�84
1050 '**************
1060 D=STRIG(0)
1070 IF D=-1 THEN GOSUB 1350
1080 C2=C
1090 B=STICK(0)
1100 IF B=3 THEN C=C+1
1110 IF B=7 THEN C=C-1
1120 IF C<=0 THEN C=C+1
1130 IF C>=19 THEN C=C-1
1140 Z=Z+1:IF Z=2 THEN Z=0:GOTO 920
1150 Z2=Z2+1
1160 IF Z2>=NB THEN 1200
1170 LOCATE A,0:PRINT CHR$(129);
1180 BEEP 19,1
1190 GOTO 920
1200 CLS:LOCATE 5,1:PRINT "SCORE :";SC
1210 IF SC<350 THEN MISS=MISS+1:LOCATE 5,2:PRINT "MISS  :";MISS
1220 IF MISS>3 THEN 10080
1230 FOR I=1 TO 250:NEXT I
1240 IF STRIG(0)=0 THEN 1240 ELSE IF SC<350 THEN Z2=0:GOTO 10080 ELSE 1500
1250 LOCATE C,3:PRINT CHR$(133);:FOR I=1 TO 250:NEXT
1260 CLS:LOCATE 5,1:PRINT "SCORE :";SC
1270 MISS=MISS+1
1280 LOCATE 5,2:PRINT "MISS :";MISS
1290 IF MISS>3 THEN 10080
1300 FOR I=1 TO 300:NEXT
1310 IF INKEY$="" THEN 1310 ELSE CLS:GOTO 920
1320 '*************
1330 '*    tir    *
1340 '*************
1350 FOR I=1 TO 10:FOR T=1 TO 2:LOCATE C,3-T:PRINT "�82";:LOCATE C,3-T:PRINT " ";:NEXT T:NEXT I
1360 '**************
1370 '* o = GRPH ; =�82
1380 '**************
1390 EXEC 8500
1400 IF SCREEN(C,0)=129 THEN SC=SC+10 ELSE SC=SC-10
1410 LOCATE C,0:PRINT " ";:RETURN
1470 '**************
1480 '* 2e tableau *
1490 '**************
1500 CLS:PRINT " �8B�8B�8B�8B�8BFIREFOX�8B�8B�8B�8B�8B";
1510 '*************
1520 '*  = GRPH ?  =�8B
1530 '*************
1540 FOR I=1 TO 100:BEEP I,1:NEXT:CLS
1570 NB=0:X=18:Y=2:XA=7:YA=0:XB=7:YB=3
1640 LOCATE XC,YC:PRINT " ";
1642 BEEP 500,1
1644 FOR Q=XC TO X STEP -1
1645 IF SCREEN(Q,Y)=134 THEN GOTO 2200
1646 NEXT Q
1650 LOCATE X,Y:PRINT "�83";
1660 '*************
1670 '*  = GRPH ? *
1680 '*************
1690 LOCATE XD,YD:PRINT " ";
1695 FOR I=CD TO XA:IF SCREEN(I,YA)=131 THEN GOTO 2230:NEXT
1700 LOCATE XA,YA:PRINT CHR$(134);
1710 LOCATE XE,YE:PRINT " ";
1715 FOR I=XE TO XB:IF SCREEN(I,YB)=131 THEN GOTO 2230:NEXT
1720 LOCATE XB,YB:PRINT CHR$(134);
1723 FOR I=XF TO XG:IF SCREEN(I,YG)=131 THEN GOTO 2230:NEXT
1725 LOCATE XF,YF:PRINT " ";
1726 LOCATE XG,YG:PRINT CHR$(134);
1730 XC=X:YC=Y:XD=XA:YD=YA:XE=XB:YE=YB:XF=XG:YF=YG
1790 '**************
1800 '*d�placements*
1810 '**************
1820 '*  vaisseau  *
1830 '**************
1840 B=STICK(0)
1850 IF B=1 THEN Y=Y-1
1860 IF Y<0 THEN Y=3
1870 IF B=5 THEN Y=Y+1
1880 IF Y>3 THEN Y=0
1890 IF B=7 THEN VI=VI+1
1900 IF VI>3 THEN VI=3
1910 IF B=3 THEN VI=VI-1
1920 IF VI<1 THEN VI=1
1930 X=X-VI
1940 IF X>18 THEN X=18
1950 IF X<1 THEN X=18
1960 '**************
1970 '* 1 montagne *
1980 '**************
1990 XA=XA+3
2000 IF XA>18 THEN GOSUB 2070
2010 '**************
2020 '* 2 montagne *
2030 '**************
2040 XB=XB+1
2050 IF XB>15 THEN GOSUB 2120
2051 '**************
2052 '* 3 montagne *
2053 '**************
2054 XG=XG+2
2055 IF XG>17 THEN GOSUB 2161
2060 GOTO 1640
2070 NB=NB+1
2080 IF NB=30 THEN GOTO 2360
2090 YA=INT(RND(1)*4)
2100 XA=1
2110 RETURN
2120 NB=NB+1
2130 IF NB>30 THEN GOTO 2360
2140 YB=INT(RND(1)*4)
2150 XB=1
2160 RETURN
2161 NB=NB+1
2162 IF NB>30 THEN GOTO 2360
2163 XG=INT(RND(1)*4)
2164 XG=1
2165 RETURN
2200 '***************
2210 '*    perdu    *
2220 '***************
2230 LOCATE X,Y:PRINT CHR$(133);:BEEP 200,15
2240 FOR I=1 TO 250:NEXT I
2260 CLS:LOCATE 5,1:PRINT "SCORE :";SC
2280 MISS=MISS+1
2290 LOCATE 5,2:PRINT "MISS :";MISS
2300 GOSUB 10000
2310 IF MISS>3 THEN 10070
2320 CLS:GOTO 1640
2330 '*************
2340 '*   gagn�   *
2350 '*************
2360 CLS:LOCATE 7,1
2380 PRINT CHR$(135);CHR$(136);CHR$(135);CHR$(137);CHR$(138)
2390 LINE (41,15)-(41,8)
2400 LINE (41,7)-(71,7)
2410 LOCATE 0,3:PRINT " Vous �tes riche !";
2420 FOR I=1 TO 100:BEEP I,1:NEXT
2450 GOSUB 10000
2460 GOTO 10070
10000 '*************
10010 '*  attente  *
10020 '*************
10030 IF INKEY$="" THEN 10000 ELSE RETURN
10050 '*************
10060 '*  rejouez  *
10070 '*************
10080 CLS:PRINT:PRINT "Voulez-vous REJOUER       (O-N)   ";
10100 A$=INKEY$
10110 IF A$="O" THEN CLS:SC=0:Z2=0:MISS=0:GOTO  310
10120 IF A$="N" THEN CLS:PRINT "Alors au revoir  ":END
10130 GOTO 10100