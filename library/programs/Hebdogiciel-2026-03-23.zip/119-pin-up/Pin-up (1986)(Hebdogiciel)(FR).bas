1 REM *********** version 1 ************
2 REM ************ pin-up **************
3 REM ***** par DESMARTIN philippe *****
4 REM ********** (c) 1986 **************
10 CLS:INPUT "couleur (0-3)";C:IF C<0 OR C>3 THEN 10
20 LPRINT�5B1,C�5D
30 LPRINT "  qqqqqqq"
40 LPRINT " qqqxxx*qqq   qqqq"
50 LPRINT "qqqxxxxxx**qqqqxxx**q    qqqqqqqq"
60 LPRINT "xxx*$$$$$$*xxxxxxxxxxqqqqq..qqqqqqq"
70 LPRINT "xx$$******$$****xxxxxxxxxxxxxxx*qxxq"
80 LPRINT "x$$********x$x**xxxxxxxxxxxxxxx**qxxq"
90 LPRINT "**$$$*********$$xxxxxxxxxxxxxxxx**qxxq"
100 LPRINT "$***$**xqqxxxxxxxxxxxxxxxxxxxxxxxx*qxxq"
110 LPRINT "$**$xx*qmmmqq$qxxxxqqqq$$$qqqq*xxxqxxq"
120 LPRINT "$*$xxxq***/////***q*xxxxxxxxxx*qq*xxxxq"
130 LPRINT "*qxxxxxxxxx$.$xxq***///,,///***'qq$$qqq"
140 LPRINT "x$$xxq$***////,,,,,....**..*qxxxxxxxxxxq"
150 LPRINT "xx$xxxqq***//,,,,.*q$*'''*  //*qxxxxxxxq"
160 LPRINT "xx*xxxx$q**//,,l ;$q      .../*qxxxxxx*xq"
170 LPRINT "xxxxxxxq***/,... *$  .*qqqq$ .*qqxxx$*qxxq"
180 LPRINT "xxxxxxq  *.      . .q$q $''    .*qqxxx$*xqq"
190 LPRINT "xxxxxx$q$$$q.,    ,q  $q'   ./**qq$xx**xqq"
200 LPRINT "xxxxx$   .,.,..   1 ..      .,/**qxqx***x$"
210 LPRINT "xxxxq  . *q$''q..   ,,...      .,/qqx///xq"
220 LPRINT "xxx$   *'q$$*  ...   .,q,     ../qxq***xq    *"
230 LPRINT "xq   *q*qq'     ,,.   $q 1.      *xq**xq    $q"
240 LPRINT "*qq//,,..       *,q ..  *...     *qxx*xx    qxx"
250 LPRINT "*****//,.       *,q ..     ..*    *qxx*x    *qx$"
260 LPRINT "$xxq**/,        .    .*q$$***    .,$xxxx*   qxx*'"
270 LPRINT "&xxx'*&&&//    .   *q$$q*q$$*   .,*/qxxxxq  qxxxx*q"
280 LPRINT "xxxxxxq&&&&/, .,  q$q**q$$q*,..  &q&&$xxxxxxxxxxqxq"
290 LPRINT "xxxxxxx$&&&&//  ..q*$$$q*',.    &q&&&qxxxxxxxxxqxx$"
300 LPRINT "xxxxxxxx'q&&&&//,.    .,.     //*'&&/&$xxx*q*xxxxq"
310 LPRINT " qxxxxxxxxq&&&//,,l   ..    ,//q*&&//&qxmmm$$qq*-"
320 LPRINT "  q$*xxxxxx$&&///,,...... .//*$&&$&&///&&$x///////m$$$qqqq***-."
330 LPRINT "  qxxxwxxxxxx$*&//,,..,,///q$'&&&//.//&qm***&&&///,,*1,.../1$q*"
340 LPRINT " qxxxxxxxqxxxxx$qq*-**q$/'&&&&&//,,,/&qxqm**&&&,../dp/,..        ,pq*"
350 LPRINT "*xxxxxxxxqxxxxxxx$&&/,,//////&&//,,,/&&$xqm*&&&,.&pd&,.           ";
360 LPRINT "'$q"
370 LPRINT "xxxxxxxxq$xxxxxxxxq&///,..,//&&&//,,,/&'q**qmm//qd&,.          ";
380 LPRINT "    '$q"
390 LPRINT "xxpqxqxxxxxxxxxxxxxx$&///,.,/&q..,,,///&&&m*&&//,dd&/,..          ";
400 LPRINT "    ..$"
410 LPRINT "qq1$qxxxxxxxxxxxxxxxx'q&///,.,/q...,,,//&&&///q',oo&/,...     ";
420 LPRINT "         .,,8"
430 LPRINT "//&&&&qxxxxxxxxxxxxxxxq&///',/&q...,,,//&&q$..//po&/,.....     ";
440 LPRINT "     ..,///pq"
450 LPRINT "//ddddqqxxxxxxxxxxxxxxx*q$&&///&&q...,,,&q$..,,//qdq&&&///,,...  ";
460 LPRINT "..,///&&&&3q"
470 LPRINT "//dddd 1qxxxxxxxxxxxq$&&&q&&//.&q$../&q...,/////*o3mn&&&&////,,....";
480 LPRINT "..,,//&&33q"
490 LPRINT "/dddp$    '**qq$qx*q$&&//&&$q&//.&q..*q.,/////jjjn*$pmmmn&&&&&";
500 LPRINT "///,,,,///&&&&&33$"
510 LPRINT CHR$(11);
520 LPRINT "&&&&q         $&&///,,l,///&&q&&//..&&/////&&&nnnmmmq$qmmmmnn&&&";
530 LPRINT "&&&/////,,.../&&"
540 LPRINT CHR$(11);
550 LPRINT "&ddq        *q&&&///m/.,,///&&q&&///,,,/&&&&&&&&&&*&q$$*mmmmmnnn";
560 LPRINT "&&&&&&////,,.../"
570 LPRINT CHR$(11);
580 LPRINT "ddq        q*&&&&//nmn&&,///&&$&&//,,,//&&&&&&&&&&***jdd//ppjmmmnn";
590 LPRINT "&&&///,,..&&&&"
600 LPRINT CHR$(11);
610 LPRINT "d1q       q*&&&&//nmmn&&&&&&&qnnm&&&&&&&&&&&&&&&&&&&jfaaf//aa&&&";
620 LPRINT "&&&&aaa///,,,../"
630 LPRINT CHR$(11);
640 LPRINT "dq       q*jjnnmaqxxxxjmm&&&&&//////&&&&&&&&&&&&&&&&&&&//////jxx";
650 LPRINT "xxxj&&&////,,,,."
660 LPRINT CHR$(11);
670 LPRINT "q       q*jjnnmmqxqxj&mmm&&&&&&&&&&&&&&&///////&&/////&&&&&&////";
680 LPRINT "/,,,....,,,////,"
690 LPRINT CHR$(11);
700 LPRINT "       q*///jjmmqqmmnn&////&&&//////////&&&&&&&&&&/////***qq$q**";
710 LPRINT "&&&&&&&&&/////,,"
720 LPRINT CHR$(11);
730 LPRINT "     q*//nnnmmmm&*qqmnnn///&&&&&&&&&&&&&&&&&&&&&/////////*****q*";
740 LPRINT "&&&&&&&&&&////,,"
750 LPRINT CHR$(11);
760 LPRINT "    q*/////nnnmmm**qmnn///&&&&&&*********&&&&&&&/////////&&**$$q";
770 LPRINT "*&&&&&&&&&&////,"
780 LPRINT CHR$(11);
790 LPRINT "  q$&&&&///,,,,,,//qmmn,,,,//&&&&&&&&&&&//////,,,,,...,,/&&nmmmx";
800 LPRINT "*q&&&///&/,,,,,,"
810 LPRINT CHR$(11);
820 LPRINT " *$*&&&&&///,,,//&&$mmnn,,,///&&&nmn&&&&////,,,,,,....,/*�nnmmnn";
830 LPRINT "nnqz&&////&&/,,,"
840 LPRINT CHR$(11);
850 LPRINT "$*&&&&&///,,//&&&&&$mmn,,,,////&nmmn&&&////,..     .,/&&&nd&&&&&";
860 LPRINT "///q&&&////&&&//"
870 LPRINT CHR$(11);
880 LPRINT "$$&&&&&//,,//&&&&&&x$qn/,,,,///&nmmn&&//...         .,,/&&&&&///";
890 LPRINT "///&1q&&&////&&&"
900 LPRINT CHR$(11);
910 LPRINT "*&&&&//,,,//&&&&&&&nx$n&/,,,,,//nmn&&&//..           .,,&&&////";
920 LPRINT "///&&1q&&&////&&"
930 LPRINT CHR$(11);
940 LPRINT "&&&&//,,//&&&&&&&&nxx$n/,,,///&&n$q&/,,.             ..,,//////&";
950 LPRINT "&///&&&2q&&&////"
960 LPRINT CHR$(11);
970 LPRINT "&&//,,//&&&&&&&&nxxxqq&,,,///&&&q,,.          .*    ..,,////&&";
980 LPRINT "///&&&&1xq&&&///"
990 LPRINT CHR$(11);
1000 LPRINT "&//,,//&&&&&&&&&nxq $&/,,...//&&&q/,., .,.            ..,,///&&&";
1010 LPRINT "&///&&&&xxxq*&&/"
1020 LPRINT CHR$(11);
1030 LPRINT "/,,//&&&&&&&&&nxq  q/,,.     /&&&$/,..*qmq,.         ..,,///&&q&";
1040 LPRINT "&//&&&xx$q&&&///"
1050 LPRINT CHR$(11);
1060 LPRINT "/,//&&&&&&&&&&q   1q,.        /&&m/,.$....q..         ..,,//&&q&";
1070 LPRINT "&//,,,&&&&7x$ q&"
1080 LPRINT CHR$(11);
1090 LPRINT "///&&&&&&&&&q     $..        .//&m/.q......q..       ..,,//&&*&&";
1100 LPRINT "//,,,,/&&&xxq"
1110 LPRINT "//&&&&&&&&q      q,.        .,/&&$/,$.1$...$..     ...,,///&&q&&";
1120 LPRINT "///,,,,/&&&xq"
1130 LPRINT "/&&&&&&&q       **.         ..,/&q/,q.($...q..  ....//////&&$&//";
1140 LPRINT "//,,,,,/&&&$"
1150 LPRINT "&&&&&&q        q.$.         .,,*&*//,q....q,,...,,,,//&&&&&kq&&/";
1160 LPRINT "/,.,,,//&&&q"
1170 LPRINT "/&&&q'        )$..q.     ...,,,&*&*///$.*$'..,,,,,///&&&&kk$&&//";
1180 LPRINT "/..,,,///&8q"
1190 LPRINT "$$q           )$..$....,,,,,&&&**&&q*/////,,,,////&&&&&kkkq&&&//";
1200 LPRINT ",....,,,//h*"
1210 LPRINT "8              q,,q...,,,//&&&-kq&&&$&&&/////&&&&&&kkkkkk$&&&&//";
1220 LPRINT ",....,,,/&*"
1230 LPRINT "                $,q,&/,,.,,/&&kq$&&&&$k*&&&&&&&&&kkkkkkq$&&&&//,";
1240 LPRINT ".....,,,/&*"
1250 LPRINT "                 '$/&&&//&&&kq$&&///&&$kkkkkkkkkkkkkq$'&&&&//,..";
1260 LPRINT "...,,,//&4*"
1270 LPRINT "                    q&&&&/&&&kq$&&/,,//&&*$$qq$$qq$$*&&&&&&&&//.,";
1280 LPRINT ".....,,//&4"
1290 LPRINT "                      *$kkk&kq$&&//,,,//&&&&&hq$q*&&&&&&&&&///,,.";
1300 LPRINT ".....,//&$"
1310 LPRINT "                        '*q$q'q&//,,..../&&&&nnmmmnn&&&&&&///,,,.";
1320 LPRINT ".....,,/&q"
1330 LPRINT "                             q&//,,.....,&&&&&nmn&&&&&&////,,,...";
1340 LPRINT "....,,/&$"
1350 LPRINT "                             q//,,.......////'&&&'///////,,,.....";
1360 LPRINT "....,,,/q"
1370 LPRINT "                              $/,.,/,.........,,,,...............";
1380 LPRINT "..,,,//1$"
1390 LPRINT "                              q&//.,,/,......,,,,,,,............,";
1400 LPRINT ",,,,////."
1410 LPRINT "                              *&&/.,,.,..........,,,............,";
1420 LPRINT ",,,,///$"
1430 LPRINT "                              qq&&&////,,....................,,,,";
1440 LPRINT ",,,,///q"
1450 LPRINT "                             q&q&&&&----//,,,,,,,,,............,,";
1460 LPRINT ",,,/////q"
1470 LPRINT "                            $&q&&&&&&----///,,,,,,,,,,.......,,,,";
1480 LPRINT ",,,//*/$"
1490 LPRINT "                           q&&//&&&&&&&&&-----&-/////,,,,,..,,,,,";
1500 LPRINT ",/////q/."
2580 LPRINT "                    ''$/,..,/&&&*m&&&&////,,,,,....,,,,////&&&&&";
2590 LPRINT "&&$*"
2600 LPRINT "                      q/,,.,/&xx*&&&&////,,,,,.....,,,////&&&&&&";
2610 LPRINT "&*'/"
2620 LPRINT "                       'q//,,/&&xq&&&////,,,......,,,,////&&&&&&&$q"
2630 LPRINT "                        '$//,/&&x$&&/////,,... ..,,,,//////&&&&&&q"
2640 LPRINT "                         q&//&&x*&&////,,,......,,,,,///////&&&&q"
2650 LPRINT "                         '$&//&*q&////,,,......,,..,,,//////&&&$/"
2660 LPRINT "                          q/&xxq&//,,,.......,,,,//////&&&&&$$q'"
2670 LPRINT "                           q/&xxq&//,,,.......,,,,//////&&&&&q"
2680 LPRINT "                             $&xq&//,,,......,,,,//////&&&&&&q'"
2690 LPRINT "                              qx*'&/,,.....,,,,,/////&&&&&&&&$/"
2700 LPRINT "                              $*q&/,,......,,,,,/////&&&&&&&&q"
2710 LPRINT "                             'q$&&&.......,,,,,/////&&&&&&&&q*"
2720 LPRINT "                            .q$&&&.......,,,,,/////&&&&&&&&qmq."
2730 LPRINT "                            qq*&,.........,,,////&&&&&&&&&&mn$)"
2740 LPRINT "                           'q$&&,......,,,,////&&&&&&&&&&qmn//q"
2750 LPRINT "                           q$&&&,.......,,,/////&&&&&&&&qmn&//$."
2760 LPRINT "                           $$&&,........,,,////&&&&&&&&qmnn&//q"
2770 LPRINT "                          '$&&&,......,,,,/////&&&&&&&&mnn&////$"
2780 LPRINT "                          *$&&,.&/,...,,,,/////&&&&&&&qmmn&////$."
2790 LPRINT "                         ,$,..&&/....//,,/////&&&&&&&$mnn&//////q"
2800 LPRINT "                         ,$&,..&&/..00,,/////&&&&&&*$mnnn&//////$."
2810 LPRINT "                         $&,.,//&&/....,,,//&&&&&&&mnnn&///////,q"
2820 LPRINT "                        .q&..///&&&/....,,&&&&&&&&qmmnn&&/////,,$."
2830 LPRINT "                        (q&.../&x/....,,,,/&&&&&&mmnn&n&///////,,$."
2840 LPRINT "                        ($&../&&x/....,,,/&&&&&&&$mnnnn&&//////,,";
2850 LPRINT ",,$."
2860 LPRINT "                        '$&./&&xxx...,,,/&&&&*&&$mmnnnn&&/////,,,";
2870 LPRINT ",..$"
2880 LPRINT "                        *q&./&&x/...,,,/&&&&&*&$mmnnnn&&/////,,,,";
2890 LPRINT ",..'q"
2900 LPRINT "                        q$&../&&/....,,,/&&&&*&qmnnnnn&&//////,,,";
2910 LPRINT ",,..$'"
2920 LPRINT "                        q&.,,,//,,...,,/&&&&&&$mmnnnnn&&///////,,";
2930 LPRINT ",,,..q$"
2940 LPRINT "                        $&.,,///,,,..,,,/&&&&&qmmnnnnn&&////////,";
2950 LPRINT ",,,,,.$"
2960 LPRINT "                        q,,,&///,,,,,.,,//&&&&$ q*mnnn&&/////////";
2970 LPRINT ",,,,,,,..'q"
2980 LPRINT "                         $,,,&///,,,,,.,,//&&&&* 'qmnn&&/////////";
2990 LPRINT "/,,,,,,,...q"
3000 LPRINT "                         $,,,,&///,,,,,.,,/&&&&$   8&&&&&////////";
3010 LPRINT "//,,,,,,,...'q"
3020 LPRINT "                          $&&,,,,,//,,,,/////&&&*   qm&&&&///////";
3030 LPRINT "///,,,,,,,...$"
3040 LPRINT "                          '$&&,,,,,//,,,,/////&&$    *&&&&&//////";
3050 LPRINT "////,,,,,,,...$"
3060 LPRINT CHR$(11);
3070 LPRINT "                           q&&,,,,,//.,,,,/////&&q    q&&&&&&////";
3080 LPRINT "/////,,,,,,,..."
3090 LPRINT CHR$(11);
3100 LPRINT "                            $&&//,,,,.,,,,,////&&&q    q&&&&&////";
3110 LPRINT "//////,,,,,,,,."
3120 LPRINT CHR$(11);
3130 LPRINT "                             $&&&///,,,,///////&&&&q   q$&&&&////";
3140 LPRINT "//////,,,,,,,,,"
3150 LPRINT CHR$(11);
3160 LPRINT "                             'q&&&,///,,,,,////&&&&&q    q&&&&&//";
3170 LPRINT "///////,,,,,,,,"
3180 LPRINT CHR$(11);
3190 LPRINT "                              q&&,.,///,,,//,,///&&&*q    'q&&&&/";
3200 LPRINT "////////,,,,,,,"
3210 LPRINT CHR$(11);
3220 LPRINT "                               $&,. ,,/////,,.,,//&&&&q     q&&&&";
3230 LPRINT "////////,,,,,,,"
3240 LPRINT CHR$(11);
3250 LPRINT "                               $q,. ',,////,,. ',,//&&&$     $&&&";
3260 LPRINT "&///////,,,,,,,"
3270 LPRINT CHR$(11);
3280 LPRINT "                    q,. ',,,////,.  ,,//&&'q     q*&&";
3290 LPRINT "&//////,,,,,,,,"
3300 LPRINT CHR$(11);
3310 LPRINT "                    .$...  ,,,///,.   ',,//&&q     $&";
3320 LPRINT "&&&//////,,,,,,"
3330 LPRINT CHR$(11);
3340 LPRINT "                     *$,.. ',,,///..    ..//$&'     q";
3350 LPRINT "&&&////////,,.."
3360 LPRINT CHR$(11);
3370 LPRINT "                      q,... ',,////,.   '..//&q.     ";
3380 LPRINT "'$&&//////,,,.."
3390 LPRINT CHR$(11);
3400 LPRINT "                      '$,,.. ,,,////..    ,,//$*.    ";
3410 LPRINT " q&&//////,,..."
3420 LPRINT CHR$(11);
3430 LPRINT "                       *$,,.  ,,,////..   ',./&*q    ";
3440 LPRINT "  '$&/////...,,"
3450 LPRINT CHR$(11);
3460 LPRINT "                        q,,.. '...///,,    '//&$*,   ";
3470 LPRINT "    $&/////..,,"
3480 LPRINT CHR$(11);
3490 LPRINT "                        '$,,.. ,,,,///,.    //&&$q   ";
3500 LPRINT "    $/////.,,,,"
3510 LPRINT CHR$(11);
3520 LPRINT "                         q,,.. ,,,,,///.   '/&&&$*.  ";
3530 LPRINT "     $////.,,,,"
3540 LPRINT CHR$(11);
3550 LPRINT "                         '$,,..,,,,,,///,    //&&*q  ";
3560 LPRINT "      $///,,,,,"
3570 LPRINT CHR$(11);
3580 LPRINT "                         *$,,. ,,,,,///,.   '/&&$*.  ";
3590 LPRINT "       $//.,,,,"
3600 LPRINT CHR$(11);
3610 LPRINT "                         'q,,. ,,,,,///,.,   /&&&$'  ";
3620 LPRINT "        $/..,,,"
3630 LPRINT CHR$(11);
3640 LPRINT "                          '$.. ',,,,///,..   /&&&$*  ";
3650 LPRINT "        'q...,,"
3660 LPRINT CHR$(11);
3670 LPRINT "                           1.., ,,,,////,,...&&&&$*  ";
3680 LPRINT "          q...,"
3690 LPRINT CHR$(11);
3700 LPRINT "                           '$., ',,,/////,,..,&&$^* ";
3710 LPRINT "          q...,"
3720 LPRINT CHR$(11);
3730 LPRINT "                           q.,, ,,,,/////,,,..&&$1  ";
3740 LPRINT "          .q..."
3750 LPRINT CHR$(11);
3760 LPRINT "                           $q., ',,/////,,,..&&&$*  ";
3770 LPRINT "           q..."
3780 LPRINT CHR$(11);
3790 LPRINT "                           'q,,.,,,/////,,..&&&&q$  ";
3800 LPRINT "            8.."
3810 LPRINT CHR$(11);
3820 LPRINT "                            q,,. ,,,/////////,&&qq  ";
3830 LPRINT "            '.,"
3840 LPRINT CHR$(11);
3850 LPRINT "                            'q,,. ,,,///////,/&&1,  ";
3860 LPRINT "             $."
3870 LPRINT CHR$(11);
3880 LPRINT "                            '$,.. ,,,,//////,/&&1$  ";
3890 LPRINT "              $"
3900 LPRINT CHR$(11);
3910 LPRINT "                            'q,,. ,,,,,////,&&&1$q  ";
3920 LPRINT "             '"
3930 LPRINT CHR$(11);
3940 LPRINT "                             '$,,.',,,,////&/&&$$*"
3950 LPRINT "                              q,,,,.,,,,,////&&&qq"
3960 LPRINT "                              '*,,.',,,,////&&&c$*"
3970 LPRINT "                               q,,,.,,,,,///,/&c11"
3980 LPRINT "                               'q,,,,,,,,///,/&d$"
3990 LPRINT "                                $,,,,,////,,,/&dm."
4000 LPRINT "                                q,,,,,,////,,/&d$1"
4010 LPRINT "                                'q,,,,,////,,/&d$)"
4020 LPRINT "                                 q,,,/////,,,,&dq'"
4030 LPRINT "                                 '$,,////,,,,,&d&$'"
4040 LPRINT "                                  q,,,,///,,,,,&dq"
4050 LPRINT "                                  'q,,,//,,,,,,&d$."
4060 LPRINT "                                   $,,,//,,,,,,&ddq"
4070 LPRINT "                                   'q,,///,,,,,,&d$*"