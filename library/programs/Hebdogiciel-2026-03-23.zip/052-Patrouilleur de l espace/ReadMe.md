Patrouilleur de l'espace.

tir� du magazine Hebdogiciel N�52

	Le jeu se d�compose en six tableaux diff�rents. Le but du jeu est de d�truire la base d'une plan�te ennemie. Pour cela vous disposez � chaque partie de 5 vaisseaux de combat, d'un canon laser ainsi que d'un nombre illimit� de bombes. Vous devez tout d'abord affronter 5 escadrilles de 5 chasseaux ennemis, puis d�truire une montagne pour acc�der � un tunnel � l'aide d'une navette. Ensuite, dans le tunnel, il faut d�truire les futs de fuel afin de gagner du carburant, pour pouvoir continuer et �viter ou d�truire les fus�es qui vous menacent. Enfin, vous arriverez � la base, o� bien des pi�ges risquent de vous arr�ter avant de pouvoir la d�truire. Alors vous pourrez continuer vers la seconde base...

Mode d'emploi :
	D'abord, tapez le programme contenant les caract�res sp�ciaux. Faites RUN puis effacez le apr�s l'avoir enregistr�. Tapez ensuite le programme du jeu. Vous aurez s�rement quelques difficult�s � taper les lignes 1130, 1140, 1150, 1160. Pour cel� voici une explication : 
ligne 1130 : tapez 1130 AA=5:LOCATE 0,0:PRINT "puis appuyez sur la touche GRPH et tapez ZZZZZZZZZIRRR6RRRRRS. Revenez en mode normal en appuyant sur la touche GRPH et finissez la ligne avec ".
	Pour les autres lignes, la proc�dure est la m�me pour taper les caract�res entre parenth�ses.
ligne 1140 : "       ZZ    B     S"
ligne 1150 : "ZZ:Z  ZZ    2345UVZ"
ligne 1160 : "ZZZZZB 111111-98DLM"
	Le reste du programme ne pr�sente pas de difficult�s.
	Pour tirer utiliser la barre d'espacement, pour lancer les bombes utiliser la touche B et pour d�placer la navette dans la grotte, utiliser N.

T�l�charg� sur "Hebdogiciel, les listings..." (http://www.hebdogiciel.fr)


Cordialement,
Christian DUBROEUCQ.