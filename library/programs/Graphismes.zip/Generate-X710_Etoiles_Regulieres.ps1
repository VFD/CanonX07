﻿<#
.SYNOPSIS
    Computes the points of Delahaye's REGULAR STARS and generates
    the M/D command sequence for the Canon X‑710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program "ETOILES REGULIERES"
    from the book:
        "Dessins géométriques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined figure parameters,
      - computes the star coordinates (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, K, H, R, etc.) are defined internally.

.NOTES
    Author   : Vincent
    Project  : Canon X‑07 / X‑710 reconstruction and preservation
    File     : New-X710_EtoilesRegulieres.ps1
#>

# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------

$NP = 480
$PI = [math]::Atan(1) * 4
$CX = $NP / 2
$CY = $NP / 2

# --------------------------------------------------------------------
# Predefined figures from Delahaye (Chapter 1)
# --------------------------------------------------------------------

$Figures = @{
    "Figure 7"  = @{ K=5;  H=3;  AD=$PI/2; R=0.45 }
    "Figure 8"  = @{ K=7;  H=3;  AD=$PI/2; R=0.45 }
    "Figure 9"  = @{ K=20; H=9;  AD=$PI/2; R=0.45 }
    "Figure 10" = @{ K=20; H=7;  AD=$PI/2; R=0.45 }
    "Figure 11" = @{ K=51; H=20; AD=$PI/2; R=0.45 }
    "Figure 12" = @{ K=51; H=25; AD=$PI/2; R=0.45 }
}

# --------------------------------------------------------------------
# Select the figure to generate
# --------------------------------------------------------------------

$Name = "Figure 12"   # <<< Change this line to select another figure

$Params = $Figures[$Name]
$K  = $Params.K
$H  = $Params.H
$AD = $Params.AD
$R  = $NP * $Params.R

# --------------------------------------------------------------------
# Compute star points
# --------------------------------------------------------------------

$points = @()

for ($i = 0; $i -le $K; $i++) {
    $angle = $AD + (2 * $PI * $i * $H / $K)
    $x = [math]::Floor($CX + $R * [math]::Cos($angle))
    $y = [math]::Floor($CY + $R * [math]::Sin($angle))

    $points += [PSCustomObject]@{
        I = $i
        X = $x
        Y = $y
    }
}

# --------------------------------------------------------------------
# Display point table
# --------------------------------------------------------------------

$points | Format-Table -AutoSize

# --------------------------------------------------------------------
# Generate X‑710 sequence (console output)
# --------------------------------------------------------------------

Write-Host "`n--- Canon X-710 Sequence ---`n"

Write-Host "; Star Graphic"
Write-Host "; Delahaye"
Write-Host ";"
Write-Host "; $Name"
Write-Host ";"
Write-Host 'CHR$(18)'
Write-Host "M0,-500"
Write-Host "I"

for ($i = 0; $i -lt $points.Count; $i++) {
    $p = $points[$i]
    if ($i -eq 0) {
        Write-Host ("M{0},{1}" -f $p.X, $p.Y)
    } else {
        Write-Host ("D{0},{1}" -f $p.X, $p.Y)
    }
}

Write-Host ";"
Write-Host "; end"

# --------------------------------------------------------------------
# Export to .plt file
# --------------------------------------------------------------------

$FileName = ($Name.Replace(" ", "-")) + ".plt"
$Lines = @()

$Lines += "; Star Graphic"
$Lines += "; Delahaye"
$Lines += ";"
$Lines += "; $Name"
$Lines += ";"
$Lines += 'CHR$(18)'
$Lines += "M0,-500"
$Lines += "I"

foreach ($p in $points) {
    if ($p.I -eq 0) {
        $Lines += "M$($p.X),$($p.Y)"
    } else {
        $Lines += "D$($p.X),$($p.Y)"
    }
}

$Lines += ";"
$Lines += "; end"

$Lines | Set-Content -Encoding ASCII $FileName

Write-Host "`nFile generated: $FileName"
