﻿<#
.SYNOPSIS
    Computes regular polygons (Delahaye) and generates
    the M/D command sequence for the Canon X‑710 plotter.

.DESCRIPTION
    PowerShell reimplementation of the BASIC program "POLYGONES"
    from the book:
        "Dessins géométriques et artistiques avec votre micro-ordinateur"
        J.-P. Delahaye, Eyrolles, 1985.

    The script:
      - loads predefined polygon parameters,
      - computes the polygon vertices (X,Y),
      - applies BASIC's INT() equivalent,
      - displays the point table,
      - generates the Canon X‑710 M/D sequence,
      - exports the result to a .plt file.

.PARAMETER None
    All parameters (NP, N, AD, R, etc.) are defined internally.

.NOTES
    Author   : Vincent
    Project  : Canon X‑07 / X‑710 reconstruction and preservation
    File     : New-X710_Polygones.ps1
#>

# --------------------------------------------------------------------
# Global parameters
# --------------------------------------------------------------------

$NP = 480
$PI = [math]::Atan(1) * 4
$CX = $NP / 2
$CY = $NP / 2

# --------------------------------------------------------------------
# Predefined polygons (examples)
# --------------------------------------------------------------------

$Polygons = @{
    "Triangle"      = @{ N=3;  AD=0;       R=0.45 }
    "Square"        = @{ N=4;  AD=$PI/4;   R=0.45 }
    "Pentagon"      = @{ N=5;  AD=$PI/2;   R=0.45 }
    "Hexagon"       = @{ N=6;  AD=$PI/2;   R=0.45 }
    "Heptagon"      = @{ N=7;  AD=$PI/2;   R=0.45 }
    "Octagon"       = @{ N=8;  AD=$PI/8;   R=0.45 }
    "Decagon"       = @{ N=10; AD=$PI/2;   R=0.45 }
}

# --------------------------------------------------------------------
# Select the polygon to generate
# --------------------------------------------------------------------

$Name = "Octagon"   # <<< Change this line to select another polygon

$Params = $Polygons[$Name]
$N  = $Params.N
$AD = $Params.AD
$R  = $NP * $Params.R

# --------------------------------------------------------------------
# Compute polygon vertices
# --------------------------------------------------------------------

$points = @()

for ($i = 0; $i -lt $N; $i++) {
    $angle = $AD + (2 * $PI * $i / $N)
    $x = [math]::Floor($CX + $R * [math]::Cos($angle))
    $y = [math]::Floor($CY + $R * [math]::Sin($angle))

    $points += [PSCustomObject]@{
        I = $i
        X = $x
        Y = $y
    }
}

# --------------------------------------------------------------------
# Display point table
# --------------------------------------------------------------------

$points | Format-Table -AutoSize

# --------------------------------------------------------------------
# Generate X‑710 sequence (console output)
# --------------------------------------------------------------------

Write-Host "`n--- Canon X-710 Sequence ---`n"

Write-Host "; Regular Polygon"
Write-Host "; Delahaye"
Write-Host ";"
Write-Host "; $Name"
Write-Host ";"
Write-Host 'CHR$(18)'
Write-Host "M0,-500"
Write-Host "I"

for ($i = 0; $i -lt $points.Count; $i++) {
    $p = $points[$i]
    if ($i -eq 0) {
        Write-Host ("M{0},{1}" -f $p.X, $p.Y)
    } else {
        Write-Host ("D{0},{1}" -f $p.X, $p.Y)
    }
}

# Close the polygon
$p0 = $points[0]
Write-Host ("D{0},{1}" -f $p0.X, $p0.Y)

Write-Host ";"
Write-Host "; end"

# --------------------------------------------------------------------
# Export to .plt file
# --------------------------------------------------------------------

$FileName = ($Name.Replace(" ", "-")) + ".plt"
$Lines = @()

$Lines += "; Regular Polygon"
$Lines += "; Delahaye"
$Lines += ";"
$Lines += "; $Name"
$Lines += ";"
$Lines += 'CHR$(18)'
$Lines += "M0,-500"
$Lines += "I"

foreach ($p in $points) {
    if ($p.I -eq 0) {
        $Lines += "M$($p.X),$($p.Y)"
    } else {
        $Lines += "D$($p.X),$($p.Y)"
    }
}

# Close polygon
$Lines += "D$($p0.X),$($p0.Y)"

$Lines += ";"
$Lines += "; end"

$Lines | Set-Content -Encoding ASCII $FileName

Write-Host "`nFile generated: $FileName"
