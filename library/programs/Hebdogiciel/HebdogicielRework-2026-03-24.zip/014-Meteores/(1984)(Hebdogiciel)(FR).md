METEORES
Version originale pour Canon X-07 par Cyrille Danes
Adaptation pour MSX par Beno�t Delvaux

Saurez-vous trouver la sortie de ce champ de m�t�orites ? Attention aux rencontres inopportunes !

--------------------------------------------------------------------

METEORS
Original Canon X-07 version by Cyrille Danes
MSX adaptation by Beno�t Delvaux

Can you find the exit of this meteorites field ? Beware of inappropriate encounters !




