# Tour de Hanoi (1984)(Hebdogiciel)(FR)

___
## Introduction

Version originale pour Canon X-07 par Jean-Fran�ois Durix.

- Tour de Hanoi (1984)(Hebdogiciel)(FR).bas
- Tour de Hanoi (1984)(Hebdogiciel)(FR)[a].cas

Publi� dans le num�ro 16 (incomplet) puis remis dans le num�ro 19.

___
## Texte

Une l�gende orientale dit que Dieu est en train de jouer avec les tours de Hano� de 64 disques. Quand il aura termin�, ce sera la fin du monde ! Rassurez-vous, il lui faudra 355 milliards de si�cles pour finir son jeu !
Cela vous laisse � peine le temps de vous d�battre avec vos 19 disques.

Il faut, avec l'aide des touches 1, 2 et 3, faire bouger les disques sur les trois piquets en sachant qu'il est impossible de mettre un disque sur un autre disque plus petit.
L'ordinateur �met un son strident en cas de mauvaise manoeuvre. 


___