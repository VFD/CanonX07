#

___
## Introduction

- Calendrier (1983)(Hebdogiciel)(FR).bas
- Calendrier (1983)(Hebdogiciel)(FR).cas

Vérifier pour la X-710.

___
## Texte

Quel jour de la semaine êtes-vous né ?
Quel jour "tombe" le premier janvier 1985 et quels sont les jours fériés de l'année prochaine ?
Ne comptez plus sur vos doits, l'horloge en temps réel du X-07 et ce petit programme vont vous faciliter la tâche !


___