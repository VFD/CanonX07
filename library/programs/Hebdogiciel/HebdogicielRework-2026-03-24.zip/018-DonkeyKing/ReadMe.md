# Donkey King (1984)(Hebdogiciel)(FR)[a]

___
## Introduction

- Donkey King (1984)(Hebdogiciel)(FR)[b].bas - code source original bug ligne 45000
- Donkey King (1984)(Hebdogiciel)(FR)[f].bas - fix ligne 45000
- Donkey King (1984)(Hebdogiciel)(FR)[a].bas - 
- Donkey King (1984)(Hebdogiciel)(FR)[a].cas - 


NDR [b]: 
- Ligne 45000 : lecture de 14 data (B,A), il n'y en a que 8
- Rechercher si il ne manque pas une ligne data dans un errata 
- Utilisation de variable de 3 caractères (à corriger)

TO DO :
- Rendre le code lisible
- Faire les Fixes
- Optimiser le code (supression des " ", ...)

___
## Texte

Qui aurait pensé que KING-KONG puisse loger dans le petit X 07 ?
En tout cas, aidez-le à en sortir !

Pascal DESPLANCHES

### Mode d'emploi :

Après la page de présentation, appuyez sur n'importe quelle touche (sauf BREAK), pendant que le mén&ge défile.
Le jeu commence et vous dirigez le petit personnage à l'aide des flèches.
Pour sauter utiliser la barre d'espace.


___