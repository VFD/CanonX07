# Carré diabolique (1983-12-09)(Hebdogiciel](FR)

Hebdogiciel, 9 décembre 1983.

___
## Introduction

1er jeu pour Canon X07, il y en aura au moins 1 par numéro jusqu'à la fin.

- Carre Diabolique (1983-12-09)(Hebdogiciel)(FR)(1 of 2).bas - "caractères graphiques"
- Carre Diabolique (1983-12-09)(Hebdogiciel)(FR)(2 of 2).bas - "carré"
- Carre Diabolique (1983-12-09)(Hebdogiciel)(FR)[a].bas - "version [a] fusion et correctifs"

Ci-après le texte publié.

___
## Texte de l'hebdo

Plus dur qu'un simple casse-tête, plus difficile qu'un puzzle, plus fort que le rubik's cube :
un coup de canon dans les jeux de patience !\
Luc Lévy

Charger d'abord le programme "caractères graphiques",
faites RUN pour charger les caractères puis entrer ensuite le programme "carré" avec CLOAD,
vous économiserez ainsi de la place mémoire.
Vous avez le choix entre deux niveaux de difficulté et trois options :
l'option 5 vous permet de choisir les 9 caractères que vous désirez.
Les options 1 à 3 proposent 3 puzzles basés sur une tête d'écureuil avec 3 expressions différentes.
L'option 4 vous propose de reconstituer un carré.
Le nombre de coups est affiché ainsi que le temps passé depuis le début de la partie.\
Les touches utiles sont :

<pre>
			QWE
			ASD
			ZXC
</pre>

Si une touche d'angle est désignée, la lettre désignée et les 2 lettres contiguës tournent dans le sens des aiguilles d'une montre par exemple, en designant Q :

<pre>
			QW		devient		AQ
			A					W
</pre>

Par contre, si une touche de milieu est désignée, les 2 angles et le centre tournent dans le sens des aiguilles d'une montre, par exemple en désignant W :

<pre>
			QWE		devient		SWQ
			 S					 E
</pre>


Au niveau 2, le sens est inversé pour les lettres d'angles et pour les lettres de milieu,
non seulement le sens est inversé,
mais en plus le milieu désigné s'inverse avec son opposé
(par exemple avec W, X remplace W.

Diablement diabolique, non ?

Pour son entrée dans l'hebdo, le CANON X07 démarre fort :
un jeu avec 2 degrés de difficulté, 
une option graphique (voir dessin joint tiré sur le CANON),
une option carré haute résolution et avec une horloge qui minute le temps de jeu !\
Canoniers, continuer !


___